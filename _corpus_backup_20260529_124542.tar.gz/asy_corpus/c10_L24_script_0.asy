import graph;
size(6cm);
pair A,B,C,D;
A = (0,0);
B = (1,1);
C = (0.75,1.5);
D = (0.25,-0.5);
draw(A--C--B,black+1.5bp);
dot(A); dot(B); dot(C);
label("$(0,0)$",A,SW);
label("$(1,1)$",B,NE);
xaxis(); yaxis();