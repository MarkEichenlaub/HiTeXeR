// limit x->infty
import graph;
size(7cm);
real f(real x){return (1);}
xlimits( -0.5, 4);
ylimits( -1, 2);
fill(buildcycle((0,0)--(0, f(0)),graph(f,0,4),(4,f(4))--(4,0), (4,0)--(0,0)), rgb(.8,.8,.8));
draw(graph(f,-0.1,4),black+1bp);
xaxis(Label("$x$",position=EndPoint, align=SE), Arrow);
yaxis(Label("$y$",position=EndPoint, align=NW), Arrow);

label("$f(x) = e^{0x} = 1$", (2,2));
label("$\dots$", (4.5, 0.5));