pair A,B,C;

A = origin;
B = (1,0);
C = (2,1);

draw(A--B, Arrow(TeXHead));
draw(B--C, Arrow(TeXHead));
draw(A--C, Arrow(TeXHead));

label("$\mathbf{a}$", A--B, S);
label("$\mathbf{b}$", B--C, SE);
label("$\mathbf{a} + \mathbf{b}$", A--C, NW);