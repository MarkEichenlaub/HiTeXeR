// y=sin(x) with many lines at (pi/2, 1)

import graph;

size(7cm);

real f(real x){return (sin(x));}

real g1(real x){return (2x+1-2*pi/2);}

real g2(real x){return (-x+1+pi/2);}

real g3(real x){return (.9x+1-.9*pi/2);}

xlimits( -0.25, 2.5);

draw(graph(f,-0.25,2.5),black+1bp);

draw(graph(g1,-0.25,2.5),blue+1bp);

draw(graph(g2,-0.25,2.5),blue+1bp);

draw(graph(g3,-0.25,2.5),blue+1bp);

xaxis(Label("$x$",position=EndPoint, align=SE),NoTicks, Arrow);

yaxis(Label("$y$",position=EndPoint, align=NW), NoTicks, Arrow);

dot((pi/2,f(pi/2)));

label("$(\frac{\pi}{2}, 1)$",(pi/2,f(pi/2)),NW);

// end