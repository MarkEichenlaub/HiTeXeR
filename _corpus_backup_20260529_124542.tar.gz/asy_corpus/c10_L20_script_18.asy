real i, n, t;
pair P, O;
n=36; //number of points plotted as theta goes from 0 to pi
O=(0,0);
real r(real x) {return (2*Cos(3*x));} // polar function in degrees

// points
for(i=0; i<n/2; ++i) {
t=180*i/n; //theta in degrees
P=r(t)* dir(t); //point in rectangular coordinates
dot(P, blue);
if (i>n/3) {dot(P, red);}
}

//theta rays
for(i=15; i<360; i=i+15) {
draw(rotate(i)*((0,0)--(2,0)),black+0.5bp);
}
//radius unit circles
for(i=0;i<2.25;i=i+0.25) {
  draw(scale(i)*unitcircle,black+0.5bp);
}
xaxis(Arrow(2mm));
yaxis(Arrow(2mm));