import graph;
size(10cm);
real g(real x){return (3(x - .5)^2 - .5);}
xlimits( -0.5, 2);
ylimits(-1,2);
draw(graph(g,-0.5,1.75),black+1bp);
xaxis(Label("$x$",position=EndPoint, align=SE),Ticks("%"), Arrow);
yaxis(Label("$y$",position=EndPoint, align=NW),Ticks("%"), Arrow);
labelx(1,2S);
labely(1,2W);
label("\scriptsize $y = g'(x)$", (2.2,1));
dot("$r_1$", (.5 - 1/sqrt(6)), NE);
dot("$r_2$", (.5 + 1/sqrt(6)), NW);