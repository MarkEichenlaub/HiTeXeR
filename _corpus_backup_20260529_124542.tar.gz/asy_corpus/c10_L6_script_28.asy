// Rolle with tangent line drawn in, with x-axis moved
import graph;
size(8cm);
real a,b,c;
a = 1;
b = 4;
c = 2;
real f(real x){return (-(x-1)*(x-4)*exp(-x/2) + 1);}
xlimits(0, 5);
draw(graph(f,a,b),black+0.75bp);
//xaxis(Label("not actually the $x$-axis",position=EndPoint, align=SE),Arrow);
yaxis(Label("$y$",position=EndPoint, align=NW),Arrow);
dot((a,f(a)));
dot((b,f(b)));
draw((a,0)--(a,f(a)),black+dashed);
draw((b,0)--(b,f(b)),black+dashed);
draw((c,0)--(c,f(c)),black+dashed);
draw((0,f(a))--(b,f(b)),black+dashed);
label("$a$",(a,0),S);
label("$b$",(b,0),S);
label("$c$",(c,0),S);
draw((c,f(c))+(1,0)--(c,f(c))-(1,0),blue+1bp);
draw((-0.5,f(a))--(b+0.5, f(a)), Arrow);
label("$x$", (b+0.5, f(a)), S);
// end