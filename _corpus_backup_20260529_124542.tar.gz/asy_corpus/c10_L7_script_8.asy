import graph;
picture pic1;
real xsize=200, ysize=140;
size(pic1,xsize,ysize,IgnoreAspect);
real f(real x){return x^2;}
xlimits(pic1,  -2, 2);
ylimits(pic1, -3,4);
draw(pic1, graph(f,-2,2),black+1bp);
xaxis(pic1, Label("$x$",position=EndPoint, align=SE),Ticks("%"), Arrow);
yaxis(pic1, Label("$y$",position=EndPoint, align=NW),Ticks("%"), Arrow);
labelx(pic1, 1,2S);
labely(pic1, 1,2W);
label(pic1, "\scriptsize $y = x^2$", (1,2));
real margin = 5mm;
add(pic1.fit(),(0,0), margin*N);