unitsize(0.6 cm);

pair dx, dy, dz;

dx = (0,-1);
dy = 0.8*dir(20);
dz = 0.8*dir(160);

draw((0,0)--(5*dy));
draw((0,0)--(6*dz));
draw((0,0)--(-dx));
draw((0,0)--(-dy));
draw((0,0)--(-dz));
draw((-dx)--(-dx + 4*dy)--(-dx + 4*dy + 5*dz)--(-dx + 5*dz)--cycle);
draw((-dy)--(3*dx - dy)--(3*dx - dy + 5*dz)--(-dy + 5*dz)--cycle);
draw((-dz)--(3*dx - dz)--(3*dx + 4*dy - dz)--(4*dy - dz)--cycle);
draw((4*dy - dx)--(4*dy)--(4*dy - dz));
draw((5*dz - dx)--(5*dz)--(5*dz - dy));
draw(extension(4*dx + 4*dy, 3*dx + 4*dy, 3*dx - dz, 3*dx + 4*dy - dz)--(4*dx + 4*dy)--(4*dx)--(4*dx + 5*dz)--extension(4*dx + 5*dz, 3*dx + 5*dz, 3*dx - dy, 3*dx - dy + 5*dz));
draw((5*dy)--(5*dy + dz));
draw((6*dz)--(6*dz + dy));
draw((5*dy)--(5*dy + dx));
draw((6*dz)--(6*dz + dx));
draw((-dy)..(-dy/sqrt(2) - dz/sqrt(2))..(-dz));
draw((3*dx - dy)..(3*dx - dy/sqrt(2) - dz/sqrt(2))..(3*dx - dz));
draw((3*dx - dy/sqrt(2) - dz/sqrt(2))--(4*dx));