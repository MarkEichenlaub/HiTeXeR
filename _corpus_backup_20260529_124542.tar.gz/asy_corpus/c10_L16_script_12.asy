// "random" graph
import graph;
size(7cm);
real a,b;
a=1; b=3;
real f(real x){return (sin(x));}
real g(real x){return (x);}
draw(graph(f,0,3.5),black+1bp);
draw(graph(g,0,3),black+1bp);
xaxis(Label("$x$",position=EndPoint, align=SE),Arrow);
yaxis(Label("$y$",position=EndPoint, align=NW),Arrow);
label("$\pi$",(3.1,0),S);
label("$y=x$", (1,1.5));
label("$f(x) = \sin(x)$", (3,1));