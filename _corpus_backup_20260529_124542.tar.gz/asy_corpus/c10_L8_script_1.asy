import graph;
size(7cm);
ticks xticks=Ticks("%",Break(0.5,6.5),Size=2,n=1,begin=false);
ticks yticks=Ticks("%",Break(0.5,2.5),Size=2,n=1,begin=false);
real f(real x){return (x^(1/2));}
scale(Broken(0.5,7.5),Broken(0.5,2.5));
draw("$y=\sqrt{x}$",graph(f,8,10),black+1bp);
xaxis(Label("$x$",position=EndPoint, align=SE),xticks, Arrow);
yaxis(Label("$y$",position=EndPoint, align=NW),yticks, Arrow);
label("$8$",(ScaleX(8),0),S);
label("$9$",(ScaleX(9),0),S);
label("$10$",(ScaleX(10),0),S);
label("$3$",(0,ScaleY(3)),W);
label(rotate(90)*Break,(0.5,point(S).y));
label(Break,(point(W).x,0.5));