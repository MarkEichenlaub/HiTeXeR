// 1/(x-2)^4 graph
import graph;
size(5cm);
real f(real x){return (.5/(x-2)^4);}
fill(buildcycle((-2,0)--(-2,f(-2)), graph(f,-2,1.5),(1.5, f(1.5))--(2.5,f(2.5)),  graph(f, 2.5, 3), (3,f(3))--(3,0), (3,0)--(-2,0)),rgb(.8,.8,.8));
draw(graph(f,-2.2,1.5),black+1bp);
draw(graph(f,2.5,4),black+1bp);
draw((2,0)--(2,8), dashed);
xaxis(Label("$x$",position=EndPoint, align=SE),Arrow);
yaxis(Label("$y$",position=EndPoint, align=NW),Arrow);
label("$2$",(2,0),2S);
label("$-2$",(-2,0), 2S);
label("$3$", (3,0), 2S);
draw((3,0)--(3,f(3)), dashed);
label("$f(x) = \frac1{(x-2)^4}$", (5.5,6));