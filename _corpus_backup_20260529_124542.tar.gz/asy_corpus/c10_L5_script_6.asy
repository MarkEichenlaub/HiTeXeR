import graph;
size(7cm);

real f(real y){return ((4-y^3)/y^2);}
real g(real y){return (3);}

draw(reflect((0,0),(1,1))*graph(f,-5,-0.1),black+1bp);
draw(reflect((0,0),(1,1))*graph(f,0.1,5),black+1bp);
draw(reflect((0,0),(1,1))*graph(g,-5,5),blue);
xlimits( -3, 10, crop=Crop);
ylimits( -5, 5, crop=Crop);
xaxis(NoTicks,Arrows);
yaxis(NoTicks,Arrows);
dot("$(3,-2)$",(3,-2),W);