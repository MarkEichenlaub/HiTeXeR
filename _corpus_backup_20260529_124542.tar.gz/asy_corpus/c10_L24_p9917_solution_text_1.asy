unitsize(6 cm);

real func (real x) {
  return ((x*sqrt(x) - 3*sqrt(x) + 2)/3);
}

real funcprime (real x) {
  return ((x - 1)/(2*sqrt(x)));
}

real a = 0.4;

draw(graph(func,0,1),red);
draw((0,0)--(1,0));
draw((0,0)--(0,2/3));

dot("$(1,0)$", (1,0), S);
dot("$(0,\frac{2}{3})$", (0,2/3), W);