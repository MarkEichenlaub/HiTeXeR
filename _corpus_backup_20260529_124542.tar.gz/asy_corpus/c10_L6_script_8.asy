import graph;
size(6cm);
real f(real x){return (x^4);}
xlimits( -2, 2);
ylimits(-1,10);
draw(graph(f,-2,2),black+1bp);
xaxis(Label("$x$",position=EndPoint, align=SE), Arrow);
yaxis(Label("$y$",position=EndPoint, align=NW), Arrow);

//label("$y = x^4$", (2,1));

//labelx(1,2S);
//labely(1,2W);
// end