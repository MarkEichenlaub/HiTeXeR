unitsize(2 cm);

real r, t, x, y;
path foo = (1,0);
pair P = (1/2 + 1/sqrt(2), 1/2 + 1/sqrt(2));

for (t = 0; t <= 2*pi; t = t + 0.01) {
  r = 1 + sin(t);
  x = r*cos(t);
  y = r*sin(t);
  foo = foo--(x,y);
}

draw(foo,red);
draw((P + 0.6*(1,-1 - sqrt(2)))--(P - 0.6*(1,-1 - sqrt(2))),blue);
draw((-2,0)--(2,0));
draw((0,-0.5)--(0,2.5));

dot("$(\frac{2 + \sqrt{2}}{2},0)$", ((2 + sqrt(2))/2,0), NE);