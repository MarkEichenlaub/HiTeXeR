import graph;
size(5cm, IgnoreAspect);

real f(real x) {return x^3+x+16;}
real g(real x) {return 13x;}
pair F(real x) {return (x,f(x));}

draw(graph(f,-2,5,operator ..),red);
draw(graph(g,-2,5,operator ..),black);
xlimits(-2,2);
ylimits(-2,10);

xaxis("$x$");
yaxis("$y$");

// label("$f(n) = 1 - \frac{1}{2^n}$",F(1),SE);