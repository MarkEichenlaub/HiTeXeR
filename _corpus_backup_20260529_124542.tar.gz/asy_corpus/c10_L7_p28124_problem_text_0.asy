size( 200 ) ;

filldraw( circle( (0,0),1 ) , lightblue+white , black ) ;
dot(Label( "$X$" , dir(180) , W )) ;
dot(Label( "$Y$" , dir(0) , E )) ;
dot(Label( "$Z$" , dir(50) , NE )) ;