size( 100 ) ;
 pair center = (0,0) ;
 pair minute_tip = 8*dir(90) ; 
 pair hour_tip = 4*dir(30) ;
 draw( center--minute_tip ) ; label( "$8$" , center--minute_tip , W ) ;
 draw( center--hour_tip ) ; label( "$4$" , center--hour_tip , S ) ;
 draw( minute_tip--hour_tip , dotted ) ; label( "$D$" , minute_tip--hour_tip , NE ) ;
 label( "$	heta$" , center , 3dir(60) ) ;