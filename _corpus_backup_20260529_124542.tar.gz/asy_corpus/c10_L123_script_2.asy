unitsize(2 cm);

real func (real x) {
  return(1/(1 - 1/2*exp(-x)));
}

draw(graph(func,0,5),red);
draw((-0.2,0)--(5,0));
draw((0,1)--(5,1),dashed);
draw((0,-0.2)--(0,2.2));

label("$y = \frac{1}{1 - \frac{1}{2} e^{-x}}$", (5,1), E, red);
label("$x$", (5,0), E);
label("$y$", (0,2.2), N);