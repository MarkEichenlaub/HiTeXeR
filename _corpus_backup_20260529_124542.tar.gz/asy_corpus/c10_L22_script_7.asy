import graph;
size(6cm);
real f(real x, real y) {return (x-y);}
int i,j,n;
n = 6;
path p=(-0.2,0)--(0.2,0);
pen sf=gray+0.75bp;
for (i=-n; i<=n; ++i) {
for (j=-n; j<=n; ++j) {
draw(shift(i,j)*rotate(degrees(atan(f(i,j))))*p,sf);
}}
xaxis(Arrow); 
yaxis(Arrow);