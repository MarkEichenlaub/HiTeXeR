pair A = (0,0);
pair B = (0, 20);
pair C = (11,0);
pair D = (11,6);
pair E = (15.8,0);

draw("$20$", A--B);
draw(B--E);
draw("$x$", C--E);
draw("$y$", C--A);
draw("$6$", C--D);
label("$A$", A, S);
label("$B$", B, N);
label("$C$", C, S);
label("$D$", D, N);
label("$E$", E, S);