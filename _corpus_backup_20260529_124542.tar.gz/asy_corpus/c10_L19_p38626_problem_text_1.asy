unitsize(0.5 cm);

real t;

path cycloid = (0,0);
path strin = (0,0);
pair A, B;

for (t = -2*pi; t <= 2*pi; t = t + 0.1) {
  cycloid = cycloid--(t - sin(t),1 - cos(t));
}

for (t = 0; t <= pi; t = t + 0.1) {
  strin = strin--(t - sin(t),1 - cos(t));
}

draw(cycloid,red);
draw(strin,red + linewidth(2*bp));
draw((-2*pi,0)--(2*pi,0));

A = (0,0);
B = (pi,2);

dot(A,red + linewidth(5*bp));
dot(B,blue + linewidth(5*bp));
label("$A$", A, S);
label("$B$", B, N);