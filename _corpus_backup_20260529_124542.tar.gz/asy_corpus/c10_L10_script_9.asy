// intro area under curve pic
import graph;
size(7cm);
real f(real x){return (5 - 2*x);}
path bdry=(0,f(0))--(0,0)--(3,0)--(3,f(3));
fill(buildcycle(bdry,graph(f,0,3)),rgb(.8,.8,.8));
draw(graph(f,-0.5,3.5),black+1bp);
draw(bdry,black+1bp+dashed);
xaxis(Label("$x$",position=EndPoint, align=SE),NoTicks, Arrow);
yaxis(Label("$y$",position=EndPoint, align=NW),NoTicks, Arrow);
label("$0$",(0,0),NW);
label("$\frac52$",(2.5,0),NE);
label("$3$",(3,0),NE);
// end