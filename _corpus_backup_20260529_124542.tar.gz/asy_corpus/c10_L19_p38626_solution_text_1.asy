unitsize(1 cm);

pair B, U, P;

B = (3,2);
U = (0,0);
P = (3,0);

draw(B--U--P--cycle);

label("$BU$", (B + U)/2, NW);
label("$BU \cos \frac{u}{2}$", (B + P)/2, E);
label("$BU \sin \frac{u}{2}$", (U + P)/2, S);
label("$B$", B, N);
label("$U$", U, W);