// generic function with tgt line approx
import graph;
size(7cm);
real h = 0.8;
real f(real x){return (0.1*x^3 + 0.1*x^2 + 0.15*x + 0.5);}
real d(real x){return (0.3*x^2 + 0.2*x + 0.15);}
real m = d(1);
real g(real x){return (m*x + (f(1)-m));}
real r = 0.2;
pair P,Q,R,S;
P = (1,f(1));
Q = (1+h,f(1+h));
R = (1+h,g(1+h));
S = (1+h,f(1));
xlimits( -0.25, 2.25);
draw(graph(f,-0.25,2.25),black+1bp);
draw(graph(g,0,2.25),blue+0.75bp);
xaxis(Label("$x$",position=EndPoint, align=SE),Arrow);
yaxis(Label("$y$",position=EndPoint, align=NW),Arrow);
dot("$(x_0,y_0)$",P,NW);
dot("$(x_1,y_1)$",Q,NW);
dot(R,blue);
draw(P--S--Q,black+0.5bp+dashed);
draw(P-(0,r)--S-(0,r),black+0.5bp,Arrows(2mm));
draw(S+(r,0)--Q+(r,0),black+0.5bp,Arrows(2mm));

label("$\Delta x$",(P+S)/2-(0,1.5*r));
label("$\Delta y$",(S+Q)/2+(1.75*r,0));
// end