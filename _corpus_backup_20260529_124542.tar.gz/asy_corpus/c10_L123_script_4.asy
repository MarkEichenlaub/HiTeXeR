unitsize(0.4 cm);

real func (real x) {
  return(2*cos(x) + 3*sin(x));
}

draw(graph(func,0,12),red);
draw((0,-4)--(0,4));
draw((0,0)--(12,0));

label("$t$", (12,0), E);
label("$s$", (0,4), N);