import graph;
size(8cm);

real f(real x){return (sin(x));}
real g(real x){return (sin(3x));}

real end = 7;

xlimits( -end, end);
ylimits(-2,2);
draw(graph(f,-end,end));
draw(graph(g,-end,end),red);
xaxis(NoTicks,Arrows);
yaxis(NoTicks,Arrows);