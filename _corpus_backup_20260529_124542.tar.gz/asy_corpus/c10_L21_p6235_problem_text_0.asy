import graph;
size(4.5cm,0);
real f(real x) {return (cos(2*x));}
draw(polargraph(f,radians(-45),radians(45)));
draw(polargraph(f,0,radians(360)),blue+1bp);
xaxis(Label("$x$",position=EndPoint, align=SE),Arrow(2mm));
yaxis(Label("$y$",position=EndPoint, align=NW),Arrow(2mm));