import graph;
size(10cm,0);
real f(real x) {return (2*(1/x));}
int n=6;
int i;
path p;
for (i=1; i<=n; ++i) {
	p = (i,0)--(i,f(i))--(i+1,f(i))--(i+1,0)--cycle;
	fill(p,rgb(.7,.7,.7));
	draw(p,black+1bp);
	label(string(i),(i,0),S);
}
label(string(i),(i,0),S);
draw(graph(f,0.5,n+1.5),black+1bp);
xaxis(Label("$x$",position=EndPoint, align=SE),Arrow);
yaxis(Label("$y$",position=EndPoint, align=NW),Arrow);