// curve with tangent lines drawn to show concavity
import graph;
size(6cm);
real f(real x){return (x^3 - 3*x^2 + 1);}
real g(real x){return (3*x^2 - 6*x);}
xlimits( -1.5, 3.5);
ylimits(-4,3);
draw(graph(f,-1,3),black+0.5bp);
xaxis(Label("$x$",position=EndPoint, align=SE),Ticks("%"), Arrow);
yaxis(Label("$y$",position=EndPoint, align=NW),Ticks("%"), Arrow);
labelx(1,2S);
labely(1,2W);
real m;
pair P,Q;
for (real i=1; i<=3; i=i+0.5) {
  m = g(i);
  P = (i,f(i));
  Q = (0.15,0.15*m);
  draw((P-Q)--(P+Q),blue+1bp);
}
// end