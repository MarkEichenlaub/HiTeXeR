// generic fcn with local max
import graph;
size(8cm);
real a,b,c;
a = 0.5;
b = 4;
c = 2;
real f(real x){return (2*x-(x^2)/2 + 0.5);}
xlimits(0, 5);
draw(graph(f,a,b),black+0.75bp);
xaxis(Label("$x$",position=EndPoint, align=SE),Arrow);
yaxis(Label("$y$",position=EndPoint, align=NW),Arrow);
dot((a,f(a)));
dot((b,f(b)));
dot((c,f(c)));
draw((a,0)--(a,f(a)),black+dashed);
draw((b,0)--(b,f(b)),black+dashed);
draw((c,0)--(c,f(c)),black+dashed);
label("$a$",(a,0),S);
label("$b$",(b,0),S);
label("$c$",(c,0),S);
// end