import three;

size(180);

// calculate intersection of line and plane
// p = point on line
// d = direction of line
// q = point in plane
// n = normal to plane
triple lineintersectplan(triple p, triple d, triple q, triple n)
{
  return (p + dot(n,q - p)/dot(n,d)*d);
}

currentprojection=perspective(2,1,1);

triple A, B, C, D, P, Q, R, S, X;

A = (-1,-5,0);
B = (4,0,0);
C = (-3,4,0);
D = (0,0,6);
P = (2*A + B)/3;
Q = (2*B + C)/3;
R = (C + 4*D)/5;
S = lineintersectplan(A, A - D, P, cross(P - Q, P - R));
X = lineintersectplan(A, A - C, P, cross(P - Q, P - R));

draw(A--B);
draw(A--C,dashed);
draw(A--D);
draw(B--C);
draw(B--D);
draw(C--D);
draw(P--Q,dashed);
draw(Q--R);
draw(R--S,dashed);
draw(S--P);
draw(X--A);
draw(X--P);

dot("$A$", A, NW);
dot("$B$", B, dir(270));
dot("$C$", C, E);
dot("$D$", D, N);
dot("$P$", P, SW);
dot("$Q$", Q, SE);
dot("$R$", R, NE);
dot("$S$", S, NW);
dot("$X$", X, W);