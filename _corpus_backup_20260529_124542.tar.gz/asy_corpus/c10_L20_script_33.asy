import graph;
size(7cm);
real pi=3.14159;
real i;
real f(real t) {return (cos(2*t));}
draw(polargraph(f,0,2*pi),blue+1bp);
pair P = (-1/4, -sqrt(3)/4);
dot(P,black+5bp);
real r = 7*sqrt(3)/3;
draw((P-(0.25,0.25*r))--(P+(0.5,0.5*r)),black+1bp);
xaxis(Arrow);
yaxis(Arrow);