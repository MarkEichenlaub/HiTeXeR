import graph;
size(4cm);
real f(real t) {return (t);}
draw(polargraph(f,0,radians(360)),blue+1bp);
xaxis(Arrow); yaxis(Arrow);