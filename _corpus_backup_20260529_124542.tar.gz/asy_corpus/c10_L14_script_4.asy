// cylinder
import graph;
size(5cm);
real a,b,xn, xm;
a=1; b=3;

xn = 1; xm = 1+1/3;

real f(real x){return (17/6);}
real g(real x){return (-1*f(x));}
real h(real x){return ((1/3)*x^3 - (3/2)*x^2 + 2*x + 2);}
draw(graph(h,0,3.5),black+1bp);
path rc = xscale(.3)*yscale(f(xm))*unitcircle;
path lc = xscale(.3)*yscale(f(xn))*unitcircle;
draw(shift(xn,0)*lc,black+0.75bp);
fill(buildcycle((xn,g(xn))--(xn,f(xn)),(xn, f(xn)) --(xm, f(xn)),(xm,f(xm))--(xm,g(xm)), (xm, g(xm))--(xn,g(xn))),rgb(.8,.8,.8));
fill(shift(xm,0)*rc,white);
fill(shift(xn,0)*lc,rgb(.8,.8,.8));
draw(graph(f,xn,xm),black+1bp);
draw(graph(g,xn,xm),black+1bp);
draw(shift(xm,0)*rc,black+0.75bp);

xn = 1+1/3; xm = 1 + 2/3;
real f(real x){return (226/81);}
real g(real x){return (-1*f(x));}
real h(real x){return ((1/3)*x^3 - (3/2)*x^2 + 2*x + 2);}
draw((a,0)--(a,h(a)),black+0.75bp+dashed);
draw((b,0)--(b,h(b)),black+0.75bp+dashed);
draw(graph(h,0,3.5),black+1bp);
path rc = xscale(.3)*yscale(f(xm))*unitcircle;
path lc = xscale(.3)*yscale(f(xn))*unitcircle;
draw(shift(xn,0)*lc,black+0.75bp);
fill(buildcycle((xn,g(xn))--(xn,f(xn)),(xn, f(xn)) --(xm, f(xn)),(xm,f(xm))--(xm,g(xm)), (xm, g(xm))--(xn,g(xn))),rgb(.8,.8,.8));
fill(shift(xm,0)*rc,white);
fill(shift(xn,0)*lc,rgb(.8,.8,.8));
draw(graph(f,xn,xm),black+1bp);
draw(graph(g,xn,xm),black+1bp);
draw(shift(xm,0)*rc,black+0.75bp);

xn = 1+2/3; xm = 2;
real f(real x){return (291/81 -5/6);}
real g(real x){return (-1*f(x));}
real h(real x){return ((1/3)*x^3 - (3/2)*x^2 + 2*x + 2);}
draw((a,0)--(a,h(a)),black+0.75bp+dashed);
draw((b,0)--(b,h(b)),black+0.75bp+dashed);
draw(graph(h,0,3.5),black+1bp);
path rc = xscale(.3)*yscale(f(xm))*unitcircle;
path lc = xscale(.3)*yscale(f(xn))*unitcircle;
draw(shift(xn,0)*lc,black+0.75bp);
fill(buildcycle((xn,g(xn))--(xn,f(xn)),(xn, f(xn)) --(xm, f(xn)),(xm,f(xm))--(xm,g(xm)), (xm, g(xm))--(xn,g(xn))),rgb(.8,.8,.8));
fill(shift(xm,0)*rc,white);
fill(shift(xn,0)*lc,rgb(.8,.8,.8));
draw(graph(f,xn,xm),black+1bp);
draw(graph(g,xn,xm),black+1bp);
draw(shift(xm,0)*rc,black+0.75bp);

xn = 2; xm = 2+1/3;
real f(real x){return (8/3);}
real g(real x){return (-1*f(x));}
real h(real x){return ((1/3)*x^3 - (3/2)*x^2 + 2*x + 2);}
draw((a,0)--(a,h(a)),black+0.75bp+dashed);
draw((b,0)--(b,h(b)),black+0.75bp+dashed);
draw(graph(h,0,3.5),black+1bp);
path rc = xscale(.3)*yscale(f(xm))*unitcircle;
path lc = xscale(.3)*yscale(f(xn))*unitcircle;
draw(shift(xn,0)*lc,black+0.75bp);
fill(buildcycle((xn,g(xn))--(xn,f(xn)),(xn, f(xn)) --(xm, f(xn)),(xm,f(xm))--(xm,g(xm)), (xm, g(xm))--(xn,g(xn))),rgb(.8,.8,.8));
fill(shift(xm,0)*rc,white);
fill(shift(xn,0)*lc,rgb(.8,.8,.8));
draw(graph(f,xn,xm),black+1bp);
draw(graph(g,xn,xm),black+1bp);
draw(shift(xm,0)*rc,black+0.75bp);

xn = 2+1/3; xm = 2+2/3;
real f(real x){return (343/81-9/6);}
real g(real x){return (-1*f(x));}
real h(real x){return ((1/3)*x^3 - (3/2)*x^2 + 2*x + 2);}
draw((a,0)--(a,h(a)),black+0.75bp+dashed);
draw((b,0)--(b,h(b)),black+0.75bp+dashed);
draw(graph(h,0,3.5),black+1bp);
path rc = xscale(.3)*yscale(f(xm))*unitcircle;
path lc = xscale(.3)*yscale(f(xn))*unitcircle;
draw(shift(xn,0)*lc,black+0.75bp);
fill(buildcycle((xn,g(xn))--(xn,f(xn)),(xn, f(xn)) --(xm, f(xn)),(xm,f(xm))--(xm,g(xm)), (xm, g(xm))--(xn,g(xn))),rgb(.8,.8,.8));
fill(shift(xm,0)*rc,white);
fill(shift(xn,0)*lc,rgb(.8,.8,.8));
draw(graph(f,xn,xm),black+1bp);
draw(graph(g,xn,xm),black+1bp);
draw(shift(xm,0)*rc,black+0.75bp);

xn = 2+2/3; xm = 3;
real f(real x){return (512/81-20/6);}
real g(real x){return (-1*f(x));}
real h(real x){return ((1/3)*x^3 - (3/2)*x^2 + 2*x + 2);}
draw((a,0)--(a,h(a)),black+0.75bp+dashed);
draw((b,0)--(b,h(b)),black+0.75bp+dashed);
draw(graph(h,0,3.5),black+1bp);
path rc = xscale(.3)*yscale(f(xm))*unitcircle;
path lc = xscale(.3)*yscale(f(xn))*unitcircle;
draw(shift(xn,0)*lc,black+0.75bp);
fill(buildcycle((xn,g(xn))--(xn,f(xn)),(xn, f(xn)) --(xm, f(xn)),(xm,f(xm))--(xm,g(xm)), (xm, g(xm))--(xn,g(xn))),rgb(.8,.8,.8));
fill(shift(xm,0)*rc,white);
fill(shift(xn,0)*lc,rgb(.8,.8,.8));
draw(graph(f,xn,xm),black+1bp);
draw(graph(g,xn,xm),black+1bp);
draw(shift(xm,0)*rc,black+0.75bp);

draw((0.5,0)--(3,0),dotted);
draw((-2,0)--(0.5,0));
draw((3,0)--(4,0));
xaxis(Label("$x$",position=EndPoint, align=SE),dashed,Arrow);
yaxis(Label("$y$",position=EndPoint, align=NW),Arrow);
label("$a$",(a,0),1.5*S);

label("$b$",(b,0),S);