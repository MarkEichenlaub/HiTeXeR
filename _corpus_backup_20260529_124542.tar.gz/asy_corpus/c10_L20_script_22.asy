// r = 2*cos(3theta); 3-leaf rose
import graph;
size(7cm);
real pi=3.14159;
real i;
real f(real t) {return (2*cos(3*t));}
draw(polargraph(f,0,2*pi),blue+1bp);
for(i=15; i<360; i=i+15) {
  draw(rotate(i)*((0,0)--(2,0)),black+0.5bp);
}
for(i=0;i<2.25;i=i+0.25) {
  draw(scale(i)*unitcircle,black+0.5bp);
}
xaxis(Arrow(2mm));
yaxis(Arrow(2mm));