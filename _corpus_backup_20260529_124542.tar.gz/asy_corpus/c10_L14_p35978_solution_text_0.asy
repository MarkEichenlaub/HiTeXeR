unitsize(3 cm);

pair A, B, O;

A = dir(70);
B = dir(110);
O = (0,0);

draw(arc(O,1,0,180));
draw(A--O--B--cycle);
draw((-1,0)--(1,0));
draw(O--(0,1));
draw(A--(Cos(70),0));
draw(B--(-Cos(70),0));
draw(arc(O,1,70,110),red + linewidth(2*bp));

label("$A$", A, A);
label("$B$", B, B);
label("$\alpha$", (0.05,0.3));
label("$\alpha$", (-0.05,0.3));
label("$R$", (O + A)/2, NW);
label("$R \sin \alpha$", (0.5*Cos(70),0), S);
label("$R \cos \alpha$", (Cos(70),0.5*Sin(70)), E);