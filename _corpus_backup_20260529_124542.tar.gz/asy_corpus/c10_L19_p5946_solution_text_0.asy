// 3 periods of cycloid
import graph;
size(10cm,0);
real pi=3.14159;
real f(real t) {return(4*pi*t - sin(2*pi*t));}
real g(real t) {return(2 - cos(2*pi*t));}
draw(graph(f,g,0,3),blue+1bp);
draw(shift(0,2)*scale(2)*unitcircle,black+1bp);
draw(shift(12*pi,2)*scale(2)*unitcircle,black+1bp);
xaxis(Label("$x$",position=EndPoint, align=SE),Arrow);
yaxis(Label("$y$",position=EndPoint, align=NW),Arrow);
//