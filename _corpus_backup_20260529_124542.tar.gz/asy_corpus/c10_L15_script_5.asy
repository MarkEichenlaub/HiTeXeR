// lim x->a = infty
import graph;
size(7cm);
real f(real x){return (.1*(1/(1-x)));}
real g(real x){return (.1*(1/(x-1)));}
draw(graph(f,0,0.95),black+1bp);
draw(graph(g,1.05,2),black+1bp);
xaxis(Label("$x$",position=EndPoint, align=SE), Arrow);
yaxis(Label("$y$",position=EndPoint, align=NW), Arrow);
real d = 0.175;
real N = 0.5;
draw ((0,N)--(2,N),blue);
label("$N$",(2,N),NE);
draw ((1-d,0)--(1-d,2),red);
draw ((1+d,0)--(1+d,2),red);
label("$a-\delta$",(1-d,2),W);
label("$a+\delta$",(1+d,2),E);