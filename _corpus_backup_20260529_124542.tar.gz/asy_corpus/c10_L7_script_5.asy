import graph;
ticks stdticks=Ticks("%",Size=2,n=1,begin=false,end=false);
size(7cm);
real f(real x){return (x^3 - 3*x + 1);}
xlimits( -1,3);
draw(graph(f,0,2),black+1bp);
xaxis(Label("$x$",position=EndPoint, align=SE), stdticks,Arrow);
yaxis(Label("$y$",position=EndPoint, align=NW), stdticks,Arrow);
//dot((sqrt(5/3),-(5/3)*sqrt(5/3)));
//label("$(\sqrt{\frac53},-\frac{10}{3}\sqrt{\frac53})$",(sqrt(5/3),-(5/3)*sqrt(5/3)),S);