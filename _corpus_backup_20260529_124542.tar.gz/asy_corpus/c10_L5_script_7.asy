// implicit curve and tangent
size(6cm);
import contour;
import graph;
xlimits( -3, 3);
ylimits( -3, 3);
yaxis( "$y$" , Ticks("%"));
xaxis( "$x$", Ticks("%"));
real f(real x, real y) {return (3*x^3 + 4*x^2*y - x*y^2 + 2*y^3);}
draw(contour(f,(-3,-3),(3,3),new real[] {4}),black+1bp);
pair P = (-1,1);
draw((P+(-2,0))--(P+(2,0)),blue+1bp);
// end