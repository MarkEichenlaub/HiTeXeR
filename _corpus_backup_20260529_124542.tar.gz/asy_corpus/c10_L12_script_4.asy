unitsize(5cm);

pair A = origin;
pair B = dir(40);
pair C = foot(B,A,(1,0));

draw(A--B--C--cycle);
draw(rightanglemark(A,C,B,2));

label("$1$", A--B, NW);
label("$x$", B--C, E);
label("$\sqrt{1-x^2}$", C--A, S);
label("$	heta$", A, 4ENE);