// squeeze theorem
import graph;
size(8cm);
real f(real x){return ((x-1)^2+2);}
real h(real x){return (-.75(x-1)^2+2);}
real s(real x){return (abs(sin((x-1)*5)));}
real g(real x){return ((s(x)*f(x)) + ((1-s(x))*h(x)));}
xlimits( -2, 2);
ylimits( -5, 5);
draw(graph(f,-2,2),deepgreen+1.5);
draw(graph(g,-2,2),blue);
draw(graph(h,-2,2),deepgreen+1.5);
xaxis(Label("$x$",position=EndPoint, align=SE),Arrow);
yaxis(Label("$y$",position=EndPoint, align=NW),Arrow);
//end