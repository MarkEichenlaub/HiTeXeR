size(7cm);
real f, g, df, dg, s;
f=2.5;
g=1.5;
df=0.3;
dg=0.4;
s= -0.05;

pair O, F, G, FG, DG, DF, FDG, GDF, DFDG;
O=origin;
F= (f, 0);
G= (0,g);
FG=(f,g);
DG = (0, g+dg);
DF= (f+df, 0);
FDG = (f, g+dg);
GDF = (f+df, g);
DFDG=(f+df, g+dg);

filldraw(O--DF--DFDG--DG--cycle, lightgray);

draw(F--FDG, gray);
draw(G--GDF, gray);

draw("$f(x+h)$", shift(0, s)*brace(DF,O), S, red);
draw("$g(x+h)$", shift(s, 0)*brace(O, DG), W, blue);