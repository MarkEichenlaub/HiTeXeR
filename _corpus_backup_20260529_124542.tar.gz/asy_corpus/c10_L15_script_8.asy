size(175);

// set variables
real xmin = -1.8, xmax = 4, ymin = -2.5, ymax = 3.7;
real f (real x) {return (x^3/4 - x^2/3 - x/2+3*cos(x));}
real a = -1.373;

//shaded regions
path p = graph(f, a, 0)--origin--cycle;
fill(p, lightblue);
label("$R$", (-0.5, 1.5));

// draw your graph
draw(graph(f,xmin,xmax),blue);
limits((xmin,ymin),(xmax,ymax),Crop);

// draw axes
ticks taxes = Ticks(Label(fontsize(8)), NoZeroFormat, Step = 1, Size = 0.1pt);
xaxis(xmin, xmax, taxes, above=true);
yaxis(ymin, ymax, taxes, above=true);