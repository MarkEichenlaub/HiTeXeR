// secant line to parametric curve
import graph;
size(9cm);
real pi=3.14159;
real a=1.2;
real h=-0.8;
real f(real t) {return((3+1.5*cos(t)-sin(t))/sqrt(2));}
real g(real t) {return((2+1.5*cos(t)+sin(t))/sqrt(2));}
draw(graph(f,g,0,pi),black+1bp);
dot((f(a),g(a)));
dot((f(a+h),g(a+h)));
draw((f(a),g(a))--(f(a+h),g(a+h)),blue+1bp);
label("$(u(a),v(a))$",(f(a),g(a)),2W);
label("$(u(a+h),v(a+h))$",(f(a+h),g(a+h)),NE);
xaxis(Label("$x$",position=EndPoint, align=SE),Arrow);
yaxis(Label("$y$",position=EndPoint, align=NW),Arrow);
//