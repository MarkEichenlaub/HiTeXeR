unitsize(2 cm);

pair A, B, C, D, P, X, Y;

X = (0,0);
A = 3*dir(160);
B = dir(-20);
D = 0.8*dir(30);
C = 3/0.8*dir(210);
Y = circumcenter(A,C,X);
P = extension(Y,X,B,D);

draw(A--B);
draw(C--D);
draw(B--D);
draw(Y--P);
draw(Y--A);
draw(Y--C);

dot("$A$", A, NW);
dot("$B$", B, SE);
dot("$C$", C, SW);
dot("$D$", D, NE);
dot("$X$", X, S);
dot("$Y'$", Y, W);
dot("$P$", P, E);

label("$x$", X + (-0.25,0), red);
label("$x$", X + (0.25,0), red);
label("$x$", A + (0.3,-0.2), red);
label("$180^\circ - 2x$", Y + (0.25,0.35), red);