// limit x->infty
import graph;
size(7cm);
real f(real x){return (1/(x^(1/3)));}
xlimits( 1, 10);
ylimits( -1, 2);
draw(graph(f,0.8,10),black+1bp);
xaxis(Label("$x$",position=EndPoint, align=SE), Arrow);
yaxis(Label("$y$",position=EndPoint, align=NW), Arrow);
real d;
d= 1.0;
draw((1,0)--(1,1), dashed);
draw((1,-0.1)--(1,0.1));
label("$1$",(1,0),2S);
draw((10,-0.1)--(10,0.1));
label("$10$",(10,0),2S);
label("$f(x) = \frac 1{\sqrt[3]{x}}$", (4,2)); 
fill(buildcycle((d,0)--(d, f(d)),graph(f,d,10),(10,f(10))--(10,0), (10,0)--(1,0)), rgb(.8,.8,.8));