import graph;
unitsize(.25cm);
real f(real x){return ((1/3)*x^3 - (3/2)*x^2 + 2*x);}
real a,b;
a = 1; b = 3;
int i,n;
n = 3;
path bdry=(a,f(a))--(a,0)--(b,0)--(b,f(b));
fill(buildcycle(bdry,graph(f,a,b)),.8white);
draw ((a,0)--(a,f(a)),black+0.75bp);
draw ((b,0)--(b,f(b)),black+0.75bp);
path rect;
draw(graph(f,0.5,3.25),black+1bp);
for (i=0; i<(2*n); ++i) {
  if (i>2) {
    rect = (1+i/n,0)--(1+i/n,f(1+(i+1)/n))--(1+(i+1)/n,f(1+(i+1)/n))--(1+(i+1)/n,0)--cycle;
  } else {
    rect = (1+i/n,0)--(1+i/n,f(1+i/n))--(1+(i+1)/n,f(1+i/n))--(1+(i+1)/n,0)--cycle;
  }
  fill(rect,.6white);
  draw(rect,black+0.75bp);
}
draw(graph(f,0.5,3.25),black+0.75bp+dotted);
xaxis(Label("$x$",position=EndPoint, align=SE),Arrow);
yaxis(Label("$y$",position=EndPoint, align=NW),Arrow);
label("$a$",(1,0),S);
label("$b$",(3,0),S);
// end