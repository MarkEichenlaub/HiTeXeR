import graph;
size(200, IgnoreAspect);

real f(real x) {return cos(x);}
real g(real x) {return (-0.5*(x)^2+1);}

draw(graph(f,-2,2,operator ..),red);
draw(graph(g,-2,2,operator ..),blue);

xlimits(-2.5,2.5);
ylimits(-1.5,2);

xaxis("$x$",RightTicks(NoZero));
yaxis("$y$", LeftTicks(NoZero));
label("\footnotesize $y= \cos(x)$",(-2.5, 1.5), E, red);
label("\footnotesize $y=-\frac{1}{2}x^2 + 1$",(0.5, 1.5), 0.5E, blue);