// intermediate value theorem
import graph;
size(6cm);
real f(real x){return 1.5*(x^3 - 2.25*x^2 + 1.5*x);}
real g(real x){return (2*x-1);}
xlimits( -0.25, 2.25);
ylimits( -1, 3);
draw(graph(f,-0.25,1.5));
draw(graph(g,1.5,2.25));
xaxis(Label("$x$",position=EndPoint, align=SE),Ticks("%",Step=1,step=0), Arrow);
yaxis(Label("$y$",position=EndPoint, align=NW),Ticks("%",Step=1,step=0), Arrow);
dot((0,0));
dot((2,3));
filldraw(shift(1.5,g(1.5))*scale(0.05)*unitcircle,black,black);
filldraw(shift(1.5,f(1.5))*scale(0.05)*unitcircle,white,black);
label("$(2,3)$",(2,3),SE);
label("$(0,0)$",(0,0),NW);
draw((-.25,1)--(2.25,1),blue);
//end