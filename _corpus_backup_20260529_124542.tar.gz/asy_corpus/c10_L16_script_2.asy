// int_1^\infty (1/x^3)
size(7cm);
import graph;
real f(real x) {return (4/x^3);}
fill(buildcycle(graph(f,1,5),(5,4/25)--(5,0)--(1,0)--(1,4)),rgb(.8,.8,.8));
draw(Label("$y = \frac{1}{x^3}$", align=NE),graph(f,0.8,5),black+1bp);
draw((1,0)--(1,6),black+0.75bp);
xaxis(Label("$x$",position=EndPoint, align=SE), Arrow);
yaxis(Label("$y$",position=EndPoint, align=NW), Arrow);