import markers;

unitsize (3 cm);

pair A, B, C;
pair[] D;

A = (0,0);
C = (1,0);
B = extension(A, A + dir(40), C, C + dir(100));
D[3] = A + B - C;
D[2] = intersectionpoint(arc(A,abs(A - D[3]),0,-90),arc(C,0.7,180,270));
D[1] = intersectionpoint(arc(B,abs(B - D[3]),0,-90),arc(C,0.7,0,90));

markangle(1, D[2], A, D[3], radius=3mm, red);
markangle(1, D[3], B, D[1], radius=3mm, red);
markangle(1, D[2], C, D[1], radius=3mm, red);
draw(A--B--C--cycle);
draw(D[1]--D[2]--D[3]--cycle);
draw(A--D[2], StickIntervalMarker(1,1,size=2mm));
draw(A--D[3], StickIntervalMarker(1,1,size=2mm));
draw(B--D[1], StickIntervalMarker(1,2,size=2mm));
draw(B--D[3], StickIntervalMarker(1,2,size=2mm));
draw(C--D[1], StickIntervalMarker(1,3,size=2mm));
draw(C--D[2], StickIntervalMarker(1,3,size=2mm));

label("$A$", A, SW);
label("$B$", B, NE);
label("$C$", C, NE);
label("$D_1$", D[1], E);
label("$D_2$", D[2], S);
label("$D_3$", D[3], NW);