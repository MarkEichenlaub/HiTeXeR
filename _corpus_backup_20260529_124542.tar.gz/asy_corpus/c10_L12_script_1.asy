unitsize(2cm);

string ufunctions[] = {"$u$", "$e^x$", "$e^x$", "$e^x$"};
string vfunctions[] = {"$v'$", "$\sin x$", "$-\cos x$", "$-\sin x$"};

pair ucolumn = (0,0); pair vcolumn = (2,0); //location of column headings, establishes horizontal offset between columns
pair vert = (0, -.75); //vertical offset between entries
pair uhoriz = (0.25,0); //distance from centre of u column to right edge
pair vhoriz = (-0.5,0); //distance from centre of v column to left edge

for (int i = 1; i < ufunctions.length; ++i){
	label(ufunctions[i], ucolumn + i*vert);
    label(vfunctions[i], vcolumn + i*vert);

    pair A = ucolumn + i*vert + uhoriz;
    pair B = vcolumn + (i+1)*vert + vhoriz;

	if (vfunctions.length > ufunctions.length || i < ufunctions.length - 1){
    	//connect everything with diagonal lines
        if (i % 2 == 0){
            draw(A--B, red);
            label("$-$", A--B, 2N, red);
        }
        if (i % 2 == 1){
            draw(A--B, blue);
            label("$+$", A--B, 2N, blue);
        }
    }
    else {
    	pair C = B - vert;

        if (i % 2 == 0){
            draw(A--C, red);
            label("$-\int$", A--B, 2N, red);
        }
        if (i % 2 == 1){
            draw(A--C, blue);
            label("$+\int$", A--B, 2N, blue);
        }
	}
}

if (vfunctions.length > ufunctions.length){
	label(vfunctions[vfunctions.length-1], vcolumn + (vfunctions.length-1)*vert); //include final entry in the v column
    }

//column headings
label(ufunctions[0], ucolumn + vert/2 + (0, 0.2));
label(vfunctions[0], vcolumn + vert/2 + (0, 0.2));
draw((ucolumn - uhoriz + vert/2)--(ucolumn + uhoriz + vert/2));
draw((vcolumn - vhoriz + vert/2)--(vcolumn + vhoriz + vert/2));