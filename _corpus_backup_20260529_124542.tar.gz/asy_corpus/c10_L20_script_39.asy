// ellipse in polar
import graph;
size(7cm);
real pi=3.14159;
real a,b,c,e,l;
pair O,F,G,H;
a = 2; e=0.5; l=a*(1-e^2); c=e*a; b=sqrt(a^2-c^2);
real f(real t) {return (l/(1+e*cos(t)));}
O = (0,0); F = (-2*e*a,0); G = (-e*a,b); H= (-e*a,0);
dot(O); dot(F); dot(G);
draw(F--G--H--F, black+0.75bp);
label("$a$",(F+G)/2,NW);
label("$c$",(F+H)/2,S);
label("$b$",(G+H)/2,E);
label("$(-2c,0)$",F,SW);
draw(polargraph(f,0,2*pi),blue+1bp);
xaxis(xmin=-4,xmax=2,Arrow(2mm));
yaxis(ymin=-3,ymax=3,Arrow(2mm));