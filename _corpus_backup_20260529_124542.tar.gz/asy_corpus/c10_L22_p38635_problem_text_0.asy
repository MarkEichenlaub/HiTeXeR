unitsize(1 cm);

real func (real x) {
  return(2*sqrt(x) + 0.1*x);
}

fill(graph(func,0,4)--reverse(graph(sqrt,0,4))--cycle,lightred);
fill(graph(func,0,4)--(0,func(4))--cycle,lightblue);
draw((0,0)--(4.5,0));
draw((0,0)--(0,5));
draw(graph(sqrt,0,4.5));
draw(graph(func,0,4.5));

label("$y = \sqrt{x}$", (4.5,sqrt(4.5)), E);
label("$y = f(x)$", (4.5,func(4.5)), E);
label("$x$", (4.5,0), E);
label("$y$", (0,5), N);