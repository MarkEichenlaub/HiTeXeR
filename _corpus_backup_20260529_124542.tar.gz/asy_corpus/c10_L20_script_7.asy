//start
unitsize(1cm);
import markers;

//variables
real r, t; 
r = 0.6; // positive radius
t = 120; // theta in degrees
pair P, O, N;
P = r*dir(t); // positive radius point
O = origin;
N=r*dir(t+180); //negative radius point, plotted

//axes
xaxis(Arrow(2mm));
yaxis(Arrow(2mm));

//drawing and labeling r and theta
dot ("$(r, 	heta)=(-r, 	heta+\pi)$", N, S, blue); //point in polar coordinates
draw ("$-r$", O -- N, blue); //negative radius
draw ( O -- P); //positive radius
markangle("$\pi$", radius=15, P,O,N,arrow=Arrow(2mm)); 
markangle("$	heta$", radius=15, (r,0),O,P,blue+0.75bp,arrow=Arrow(2mm)); 
//end