import graph;
size(8cm);

real f(real x){return (x^2);}
real g(real x){return (2x-1);}

pair P;
P = (1,f(1));
xlimits( -2, 2);
draw(graph(f,-2,2),black+1bp);
draw(graph(g,-1,2),blue+0.75bp);
xaxis(Label("$x$",position=EndPoint, align=SE),NoTicks, Arrow);
yaxis(Label("$y$",position=EndPoint, align=NW),NoTicks, Arrow);
dot(P);
label("$P$",P,SE);
label("$(1,1)$",P,NW);
label("$y = x^2$", (1.5, 9/4), NW);
label("$y = 2x-1$",(0.25, -0.5), 2*SE);