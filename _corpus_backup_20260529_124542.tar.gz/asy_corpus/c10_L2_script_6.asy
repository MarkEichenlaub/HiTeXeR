unitsize(2cm);

pair offset = (0.25, 0.25); //offset between circle centres
real rA = 0.2; // radius of circle A
real rB = 1.0; // radius of circle B

pair B = origin; pair A = B + offset;
path circleA = circle(A, rA); path circleB = circle(B,rB);

fill(circleB, lightblue); fill(circleA, lightred);

draw(circleB, black+4pt); draw(circleA);

label("$A$", A+1.75*rA*dir(135), red); label("$B$", B+1.25*rB*dir(45), blue); label("$A \cup B$", B+1.25*rB*dir(90), black+4pt);