import graph;
size(7cm);
real f(real x){return ((4/3)*cbrt(x));}
xlimits( -1, 1);
draw(graph(f,-1,1));
xaxis(Label("$x$",position=EndPoint, align=SE),Arrow);
yaxis(Label("$y$",position=EndPoint, align=NW),Arrow);
label("$y' = \frac 43 x^{1/3}$",(0.2,1),2*SE);