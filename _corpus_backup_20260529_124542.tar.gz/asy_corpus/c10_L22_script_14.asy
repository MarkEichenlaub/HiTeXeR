import slopefield;
import graph;

pair P,Q, R, S;
 P=(0,1);
 Q=(0.1,1.1);
real b=0.5;
real e(real x) {return exp(x);}
 draw(graph(e,-0.01,b), blue);
real func(real x, real y) {return y;}
 add(slopefield(func,(0.01,-0.01),(b,e(b)),7,gray(0.5),Arrow)); 
real tang(real x) {return P.y+func(P.x, P.y)*(x-P.x);}
 draw((-0.01, tang(-0.01))--(b,tang(b)));
dot(P);
dot(Q);

xaxis(Label("$x$",position=EndPoint, align=SE));
yaxis(Label("$y$",position=EndPoint, align=NW));