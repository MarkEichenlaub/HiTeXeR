// intro area under curve pic
import graph;
size(7cm);
real f(real x){return (-1*((1/3)*x^3 - (3/2)*x^2 + 2*x + 2));}
path bdry=(3,f(3))--(3,0)--(1,0)--(1,f(1));
fill(buildcycle(bdry,graph(f,1,3)),rgb(.8,.8,.8));
draw(graph(f,-0.5,3.5),black+1bp);
draw(bdry,black+1bp+dashed);
xaxis(Label("$x$",position=EndPoint, align=SE),NoTicks, Arrow);
yaxis(Label("$y$",position=EndPoint, align=NW),NoTicks, Arrow);
label("$a$",(1,0.35));
label("$b$",(3,0.35));
// end