size(8cm);
//variables
real d, s; 
d = 55; // angle in degrees
s = 0.24; //scale of angle mark
pair xy, O, A;
xy = dir(d); // point on unit circle 
O = origin;
A= dir(180-d);//pi - y

//axes
draw((-1.5,0)--(1.5,0),Arrow);
draw((0,-1.5)--(0,1.5),Arrow);

//drawing
draw(circle((0,0),1),linewidth(1)); //unit circle

draw((-1.5,xy.y)--(1.5,xy.y), dashed, Arrows);

dot (xy);
draw (O -- xy); 
draw(arc(O, s, 0, d), blue);

dot (A);
draw (O -- A); 
draw(arc(O, s+.1, 0, 180), red); 
draw(arc(O, s, 180-d, 180), blue);

label ("$y$",(s-.1)*dir(d/2), blue);
label ("$y$",(s-.1)*dir(180-d/2), blue);
label ("$\pi$", (s+.15)*dir (110), red);