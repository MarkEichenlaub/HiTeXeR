unitsize(0.8 cm);

for(real x = -1.25; x <= 1.25; x = x + 0.01) {
  draw((x,2*x^2)--(x + 0.01, 2*(x + 0.01)^2),red);
  draw((x,-2*x^2)--(x + 0.01, -2*(x + 0.01)^2),red);
}

for(real x = -2.9; x <= 2.9; x = x + 0.01) {
  draw((x,0.3*x^2)--(x + 0.01, 0.3*(x + 0.01)^2),red);
  draw((x,-0.3*x^2)--(x + 0.01, -0.3*(x + 0.01)^2),red);
}

for(real x = -4; x <= 4; x = x + 0.01) {
  draw((x,0.1*x^2)--(x + 0.01, 0.1*(x + 0.01)^2),red);
  draw((x,-0.1*x^2)--(x + 0.01, -0.1*(x + 0.01)^2),red);
}

draw((-4.5,0)--(4.5,0),red);
draw(xscale(sqrt(2))*(Circle((0,0),1)),blue);
draw(yscale(2)*xscale(2*sqrt(2))*(Circle((0,0),1)),blue);
draw(yscale(3)*xscale(3*sqrt(2))*(Circle((0,0),1)),blue);