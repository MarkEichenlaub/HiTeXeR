size(4cm);
draw((-2,0)--(2,0)--(3,-1)--(-3,-1)--cycle,black+1bp);
draw((-2,0.25)--(0,0.25),black+0.5bp,Arrows(2mm));
draw((-3,-1.25)--(0,-1.25),black+0.5bp,Arrows(2mm));
label("$r_1$",(-1,0.25),N);
label("$r_2$",(-1.5,-1.25),S);
draw((2.25,0)--(3.25,-1),black+0.5bp,Arrows(1mm));
label("$\ell$",(2.75,-0.5),NE);