// rect-polar conversion
import graph;
import markers;
size(5cm);
draw((0,0)--(-2,2)--(-2,0)--(0,0),black+1bp);
markangle((2,0),(0,0),(-2,2),black+0.5bp,arrow=Arrow(2mm));
label("$	heta$",(0,0),2N+2E);
label("$r$",(-1,1.25),NW);
dot((-2,2));
label("$(-1,1)$",(-2.5,2),NE);
label("$1$",(-1.15,0),S);
label("$1$",(-2.3,1),E);
xaxis(Arrow(2mm));
yaxis(Arrow(2mm));