// sign chart of x^3 - 3x^2 + 1
size(8cm);
import graph;
xlimits(-4,4);
xaxis(Ticks("%",begin=false,end=false),Arrows);
draw((0,-0.2)--(0,0.2),black+1bp);
draw((2,-0.2)--(2,0.2),black+1bp);
labelx("0",0,S);
labelx("2",2,S);
for (int i=-8; i<0; ++i) {
  labelx("$+$",(i/2),N);
}
for (int i=1; i<4; ++i) {
  labelx("$-$",(i/2),N);
}
for (int i=5; i<9; ++i) {
  labelx("$+$",(i/2),N);
}
// end