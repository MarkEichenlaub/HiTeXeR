import graph;
size(7cm);
real f(real x){return (x^2 - 4*x+ 3);}
xlimits( -1,4);
draw(graph(f,0,3),black+1bp);
xaxis(Label("$x$",position=EndPoint, align=SE),Ticks("%"), Arrow);
yaxis(Label("$y$",position=EndPoint, align=NW),Ticks("%"), Arrow);
labelx(1,2S);
labely(1,2W);
dot((0,3));
dot((2,-1));
dot((3,0));
label("$(2,-1)$",(2,-1),S);
label("$(0,3)$",(0,3),W);
label("$(3,0)$",(3,0),NE);