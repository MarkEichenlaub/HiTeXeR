// limit x->infty
import graph;
size(5cm);
real f(real x){return (exp(x));}
xlimits( -0.5, 2);
ylimits( -1, 10);
draw(graph(f,-0.5,2),black+1bp);
xaxis(Label("$x$",position=EndPoint, align=SE), Arrow);
yaxis(Label("$y$",position=EndPoint, align=NW), Arrow);

label("$f(x) = e^{ax} \quad (a >0)$", (1.2,8));
label("$\dots$", (2.5, 3)); 
fill(buildcycle((0,0)--(0, f(0)),graph(f,0,2),(2,f(2))--(2,0), (2,0)--(0,0)), rgb(.8,.8,.8));