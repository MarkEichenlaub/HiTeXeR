import three;
import graph;
import graph3;

currentprojection=
  perspective(camera=(0.321466584011636,4.32372696463823,10.859859454474),
              up=(-0.000309786109517288,0.0194076227244724,-0.00495831491944889),
              target=(0.368514831188579,1.55105301452055,0.00423900080347295),
              zoom=0.753532633836886,
              angle=41.395863980478,
              autoadjust=false);

size(250);
real a = 1;
real b = 3;
real f(real x){
  return ((1/3)*(4-x)^3 - (3/2)*(4-x)^2 + 2*(4-x) + 2);
}

path3 curve = path3(graph(f,a,b));
path3 innerBase =  path3(unitcircle,new triple(pair xy){return (xy.x,0,xy.y);});
path3 outerBase =  path3(scale(3)*unitcircle,new triple(pair xy){return (xy.x,0,xy.y);});

surface theGuy = surface(O,curve,Y);
surface innerCyl = extrude(innerBase,shift(f(a)*Y)*innerBase);
surface outerCyl = extrude(outerBase,shift(f(b)*Y)*outerBase);

draw(outerCyl,surfacepen=palegreen);
draw(theGuy,surfacepen=palegreen,meshpen=darkgreen);
draw(innerCyl,surfacepen=invisible,meshpen=darkgreen+dashed);
draw(curve,blue);

label("$a$",(a,0,0),X-Y);
label("$b$",(b,0,0),-X-Y);

xaxis3("$x$",xmax=3.35,arrow=Arrow3,dotted,above=true);
yaxis3("$y$",ymax=f(a)+1,arrow=Arrow3);