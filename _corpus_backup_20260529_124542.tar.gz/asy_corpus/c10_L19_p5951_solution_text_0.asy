unitsize(0.2cm);
real R,r;
real f(real t) {return (R*cos(t)+r*cos(4*t));}
real g(real t) {return (R*sin(t)+r*sin(4*t));}
R = 1;
r = 1/2;
draw(graph(f,g,0,radians(360)),blue+1bp);
draw(unitcircle,black+0.75);
label("$\frac{r}{R} = \frac12$",(1.25,-1.25));
xaxis(Arrow);
yaxis(Arrow);