// delta-epsilon def
import graph;
size(7cm);

xlimits( -3, 3);
ylimits( -3, 3);

xaxis(Label("$x$",position=EndPoint, align=SE),Ticks("%",Step=1,step=0), Arrow);
yaxis(Label("$y$",position=EndPoint, align=NW),Ticks("%",Step=1,step=0), Arrow);

for (int i=-3; i<3; ++i) {
draw((i,i)--(i+1,i));
unfill(shift(i+1,i)*scale(.05)*unitcircle);
draw(shift(i+1,i)*scale(.05)*unitcircle);
fill(shift(i,i)*scale(.05)*unitcircle);
}
fill(shift(3,3)*scale(.05)*unitcircle);

real d,e;
e = 1.2;
d = 0.2;
draw((-3,1-e)--(3,1-e),blue);
draw((-3,1+e)--(3,1+e),blue);
label("$1 - \epsilon$",(3,1-e),E);
label("$1 + \epsilon$",(3,1+e),E);
draw((1-d,-3)--(1-d,3),red);
draw((1+d,-3)--(1+d,3),red);
label("$1 - \delta$",(1-d,3),NW);
label("$1 + \delta$",(1+d,3),NE);
// end