size(10cm,0);

real s(real x) {return (sin(x));}

real c(real x) {return (cos(x));}

draw(graph(c,-7,7),blue+1bp);

draw(graph(s,-7,7),red+1bp);

xaxis(Label("$x$",position=EndPoint,align=NE),Ticks("%",Step=1),Arrow(2mm));

yaxis(Label("$y$",position=EndPoint,align=NE),Ticks("%",Step=1),Arrow(2mm));