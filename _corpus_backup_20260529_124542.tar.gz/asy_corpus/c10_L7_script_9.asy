import graph;
picture pic2;
real xsize=200, ysize=140;
size(pic2,xsize,ysize,IgnoreAspect);
real g(real x){return 2x;}
xlimits(pic2,  -2, 2);
ylimits(pic2, -4,4);
draw(pic2, graph(g,-2, 2),black+1bp);
xaxis(pic2, Label("$x$",position=EndPoint, align=SE),Ticks("%"), Arrow);
yaxis(pic2, Label("$y$",position=EndPoint, align=NW),Ticks("%"), Arrow);
labelx(pic2, 1,2S);
labely(pic2, 1,2W);
label(pic2, "\scriptsize $y = f'(x)= 2x$", (1,4));
real margin = 5mm;
add(pic2.fit(),(0,0), margin*S);