size( 200 ) ;
 draw( (-0.5,0)--(3.5,0) , arrow=Arrows ) ;
 draw( (0,-1.5)--(0,1.5) , arrow=Arrows ) ;
 real thing( real x ){ return cos(3x) ; }
 fill( graph( thing , 0 , pi )--(pi,0)--(0,0)--cycle , lightblue ) ;
 draw( graph( thing , 0 , pi ) , blue ) ;