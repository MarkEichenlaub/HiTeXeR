import graph;
size(8cm);
real f(real x){return (.05*(3*x^3-4*x+3));}
draw(graph(f,-3,3),black+1bp);
xaxis(Label("$x$",position=EndPoint, align=SE),Ticks("%"), Arrow);
yaxis(Label("$y$",position=EndPoint, align=NW),NoTicks, Arrow);
label("$1$",(1,0),S);