size(300);

pair L,R,O,A,B;
real s,r,t;

s = 7;
r = 3;
t = 0.5;

L = (-s,0);
R = (s,0);

O = origin;
A = (-r,0);
B = (r,0);

draw(A--L,red,Arrow);
draw(A--B,blue);
draw(B--R,red,Arrow);
draw(circle(O,r));
draw((O+(0,t))--(O+(0,-t)));
draw((A+(0,t))--(A+(0,-t)));
draw((B+(0,t))--(B+(0,-t)));

label("$a$", O, 4S);
label("$a-R$", A, 4SSW);
label("$a+R$", B, 4SSE);