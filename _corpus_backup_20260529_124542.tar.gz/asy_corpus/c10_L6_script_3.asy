unitsize(1cm);

/* Code to draw stacked number lines for determining signs of compound expressions.
Editable lines (i.e. those that will get changed to create plots for different expressions) are marked with a star (*) in their comments. */

// DRAW NUMBER LINES

int xstart = -2; //*starting x-value of each number line
int xend = 4; //*ending x-value of each number line

string[] exps = {"$3x$", "$x - 2$", "$3x(x-2)$"}; //*expressions to plot sign of, last entry is the product/quotient of all prior ones
int nexps = exps.length; //number of expressions

real vlen = 2; //spacing between number lines
real tlen = 0.2; //length of each tick mark

for (int i = 0; i < nexps; ++i){
	draw((xstart - 1,i*vlen)--(xend + 1,i*vlen), Arrows); //draw number line
    label(exps[nexps - 1 - i], (xend + 1,i*vlen), E); //label number line

    for (int j = xstart; j < xend + 1; ++j){
    	draw((j, i*vlen - tlen/2)--(j, i*vlen + tlen/2)); //draw ticks
        label(string(j), (j, i*vlen + tlen/2), N); //label ticks
    }
}

// DRAW CUTOFF LINES

real[] cutoffs = {0, 2}; //*x-values where at least one term switches sign

for (real k : cutoffs){
	draw((k, 0*vlen - vlen/2)--(k, (nexps-1)*vlen + vlen/2), dashed); //draw vertical dashed lines
}

// LABEL POSITIVE/NEGATIVE INTERVALS

real[] signpos; //holds the coordinates where we'll write plus/minus signs
real[] cutoffs2 = {xstart - 1}; //will contain cutoffs along with start and end points
cutoffs2.append(cutoffs);
cutoffs2.push(xend + 1);

for (int p = 0; p < cutoffs2.length - 1; ++p){
	signpos.push( (cutoffs2[p] + cutoffs2[p+1])/2 ); // averages of threshold values
}

string[][] signs = {{"$-$", "$+$", "$+$"}, {"$-$", "$-$", "$+$"}, {"$+$", "$-$", "$+$"}}; //*signs of each expression in each interval

for (int line = 0; line < signs.length; ++line){
	for (int erval = 0; erval < signs[line].length; ++erval){ //sacrificed variable clarity for a silly pun (i'm not sorry)
    	string symbol = signs[line][erval];

        if (symbol == "$+$"){
        	draw((cutoffs2[erval], vlen*(nexps - line - 1))--(cutoffs2[erval+1], vlen*(nexps - line - 1)), blue); //colour interval blue
        	label(symbol, (signpos[erval], vlen*(nexps - line - 1 + 0.5)), blue); //add a blue +
        }
        else {
            draw((cutoffs2[erval], vlen*(nexps - line - 1))--(cutoffs2[erval+1], vlen*(nexps - line - 1)), red); //colour interval red
            label(symbol, (signpos[erval], vlen*(nexps - line - 1 + 0.5)), red); //add a red -
        }
    }
}