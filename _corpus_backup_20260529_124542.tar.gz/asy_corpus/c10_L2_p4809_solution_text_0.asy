size(5cm);
import graph;
real f (real x) {return (x-2)*x;}
xlimits(-1,3);
path p = graph(f,-1,3);
draw(p,black+1bp,Arrows(2mm));
draw(shift(2,3)*p,blue+1bp,Arrows(2mm));
xaxis(Label("$x$",position=EndPoint, align=SE),Arrow);
yaxis(Label("$y$",position=EndPoint, align=NW),Arrow);