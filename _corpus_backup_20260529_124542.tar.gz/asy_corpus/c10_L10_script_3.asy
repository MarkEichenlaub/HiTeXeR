// intro area under curve pic
import graph;
size(7cm);
real f(real x){return (5-2*x);}
path bdry=(0,f(0))--(0,0)--(2,0)--(2,f(2));
fill(buildcycle(bdry,graph(f,0,2)),rgb(.8,.8,.8));
draw(graph(f,-0.5,2.5),black+1bp);
draw(bdry,black+1bp+dashed);
xaxis(Label("$x$",position=EndPoint, align=SE),NoTicks, Arrow);
yaxis(Label("$y$",position=EndPoint, align=NW),NoTicks, Arrow);
label("$(0,5)$",(0,5),W);
label("$(2,1)$",(2,1),E);
// end