size(5cm);
import graph;
real g (real x) {return (1-x)^0.5;}
real h (real x) {return 4*g(2*x);}
real k (real x) {return -1*g(-3*x+1);}
xlimits(-3,3);
path p = graph(g,1,-3);
draw(p,black+1bp,Arrow(2mm));
draw(graph(h,0.5,-2),blue+1bp,Arrow(2mm));
draw(graph(k,0,2),green+1bp,Arrow(2mm));
xaxis(Label("$x$",position=EndPoint, align=SE),Arrow);
yaxis(Label("$y$",position=EndPoint, align=NW),Arrow);