// y=sin(x)

import graph;

size(7cm);

real f(real x){return (sin(x));}

real g(real x){return (1);}

xlimits( -0.25, 2.5);

draw(graph(f,-0.25,2.5),black+1bp);

xaxis(Label("$x$",position=EndPoint, align=SE),Ticks("%"), Arrow);

yaxis(Label("$y$",position=EndPoint, align=NW), Arrow);

dot((pi/2,f(pi/2)));

label("$(\frac{\pi}{2}, 1)$",(pi/2,f(pi/2)),NW);

// end