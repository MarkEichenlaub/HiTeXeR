/// floor function
import graph;
size(7cm);
xlimits( -3, 3);
ylimits( -3, 3);
xaxis(Label("$x$",position=EndPoint, align=SE),Ticks("%",Step=1,step=0), Arrow);
yaxis(Label("$y$",position=EndPoint, align=NW),Ticks("%",Step=1,step=0), Arrow);
for (int i=-3; i<3; ++i) {
draw((i,i)--(i+1,i));
unfill(shift(i+1,i)*scale(.05)*unitcircle);
draw(shift(i+1,i)*scale(.05)*unitcircle);
fill(shift(i,i)*scale(.05)*unitcircle);
}
fill(shift(3,3)*scale(.05)*unitcircle);
// end