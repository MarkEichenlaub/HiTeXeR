// Lissajous with 1,5
import graph;
size(6cm);
real pi=3.14159;
real f(real t) {return(cos(pi*t));}
real g(real t) {return(sin(2pi*t));}
draw(graph(f,g,0,2*pi,Spline),blue+1bp);
xaxis(Label("$x$",position=EndPoint, align=SE),Arrow);
yaxis(Label("$y$",position=EndPoint, align=NW),Arrow);
//