// Riemann sum of circular sectors
import graph;
size(7cm);
real f(real t) {return (1+cos(t));}
pair A,B;
pair P,Q;
real a,b;
real pi=3.14159;
a= pi/6; b=pi/3;
A = f(a)*expi(a);
B = f(b)*expi(b);
dot(A); dot(B); dot((0,0));
real r;
int n=5;
int i;
path p;
for (i=0; i<n; ++i) {
r = a + (i/n)*(b-a);
p = arc((0,0),f(r),(180/pi)*r,(180/pi)*(r+(b-a)/n));
P = f(r)*expi(r);
Q = f(r)*expi(r+(b-a)/n);
fill(buildcycle((0,0)--point(p,0),p,point(p,length(p))--(0,0)),rgb(.8,.8,.8));
draw(Q--(0,0)--P); draw(p);
}
draw(A--(0,0)--B,dashed+0.75bp);
draw(rotate(180*a/pi)*Label("$	heta=a$"),A/2,SE);
draw(rotate(180*b/pi)*Label("$	heta=b$"),B/2,NW);
draw(polargraph(f,pi/12,5*pi/12),black+1bp);
xaxis(Arrow(2mm));
yaxis(Arrow(2mm));