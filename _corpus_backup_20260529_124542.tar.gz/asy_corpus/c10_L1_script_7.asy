// y=sin(x) with tgt at (pi/2, 1)

import graph;

size(7cm);

real f(real x){return (sin(x));}

real g(real x){return (1);}

xlimits( -0.25, 2.5);

draw(graph(f,-0.25,2.5),black+1bp);

draw(graph(g,-0.25,2.5),blue+1bp);

xaxis(Label("$x$",position=EndPoint, align=SE),NoTicks, Arrow);

yaxis(Label("$y$",position=EndPoint, align=NW), NoTicks, Arrow);

dot((pi/2,f(pi/2)));

label("$(\frac{\pi}{2}, 1)$",(pi/2,f(pi/2)),NW);

// end