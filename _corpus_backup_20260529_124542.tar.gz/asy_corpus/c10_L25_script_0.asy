import graph;
size(7cm);
real f(real x){return ((cbrt(x))^4);}
xlimits( -1, 1);
ylimits( -1, 1.5);
draw(graph(f,-1,1));
xaxis(Label("$x$",position=EndPoint, align=SE),Arrow);
yaxis(Label("$y$",position=EndPoint, align=NW),Arrow);
label("$y = x^{4/3}$",(0.2,1),NE);