size( 200 ) ;

pair X = dir(180) ;
pair Y = dir(0) ;
pair Z = dir(50) ;

filldraw( circle( (0,0),1 ) , lightblue+white , black ) ;
draw( Y--X--Z--cycle ) ;
draw(rightanglemark( X,Z,Y,5 )) ;
draw( (0,0)--Z , dashed ) ;
label( "$	heta$" , dir(180) , 6dir(10) ) ;
label( "$2	heta$" , (0,0) , 3dir(20) ) ;
dot(Label( "$X$" , X , W )) ;
dot(Label( "$Y$" , Y , E )) ;
dot(Label( "$Z$" , Z , NE )) ;