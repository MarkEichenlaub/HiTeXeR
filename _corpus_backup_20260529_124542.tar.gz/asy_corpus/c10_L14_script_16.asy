// graph of y = x^(2/3)
import graph;
size(7cm);
real a,b;
a=1; b=8;
real f(real x){return (x^(2/3));}
draw(graph(f,1,8),black+1bp);
xaxis(Label("$x$",position=EndPoint, align=SE),Arrow);
yaxis(Label("$y$",position=EndPoint, align=NW),Arrow);
dot(Label("$(1,1)$"),(1,1), SE);
dot(Label("$(8,4)$"),(8,4));