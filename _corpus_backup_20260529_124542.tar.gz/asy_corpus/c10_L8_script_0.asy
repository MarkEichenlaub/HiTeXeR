import graph;
size(8cm);
real f(real x){return (x^(1/2));}
xlimits(0,10);
draw("$y=\sqrt{x}$",graph(f,0,10),black+1bp);
xaxis(Label("$x$",position=EndPoint, align=SE),Ticks("%"), Arrow);
yaxis(Label("$y$",position=EndPoint, align=NW),Ticks("%"), Arrow);
label("$1$",(1,0),S);
label("$9$",(9,0),S);
dot("$(9,3)$",(9,3),N);
draw((0,1.5)--(12,3.5),blue+0.75bp);