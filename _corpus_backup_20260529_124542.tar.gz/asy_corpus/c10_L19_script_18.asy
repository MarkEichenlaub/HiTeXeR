size(5cm);
draw((0,0)--(2,0)--(2,1)--cycle);
label("$u'(a)$",(1,0),S);
label("$v'(a)$",(2,0.5),E);
label("$(u(a),v(a))$",(0,0),SW);
dot((0,0));