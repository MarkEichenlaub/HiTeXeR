unitsize(0.75inch);
pair A, B, P;
A = (2, 0);
B = (-sqrt(3), 0);
P = (3/2, sqrt(3)/2);

draw(arc((0, 0), sqrt(3), 0, 180));
draw(arc((0, 0), 2, 0, 180));
draw((-2, 0)--(-sqrt(3), 0));
draw((2, 0)--(sqrt(3), 0));
draw(A--P, red);
draw(arc((0, 0), sqrt(3), 30, 180), red);
dot(B);
dot(A);

label("$A$", A, E);
label("$B$", B, E);