unitsize(2 cm);

pair A, B;

real func (real x) {
  return(1 - x^2/4);
}

A = (1,func(1));
B = (5/2,0);

draw(graph(func,0.2,1.8),red);
draw((-0.5,0)--(3,0));
draw((0,3/4 + 1/2)--B);

label("$y = f(x)$", (0,0.7), red);
dot("$(a,f(a))$", A, NE);
dot("$(b,0)$", B, NE);