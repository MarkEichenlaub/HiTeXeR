size(4cm);
path p = arc((0,0),1,-45,225)--(0,0)--cycle;
fill(p,.8white);
draw(p,black+1bp);
label("$\ell$",rotate(225)*(0.5,0),SE);