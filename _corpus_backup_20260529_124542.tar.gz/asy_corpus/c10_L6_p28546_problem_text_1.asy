size( 200 ) ;
draw( (-2,0)--(2,0) , arrow=Arrows ) ;
draw( (0,-2)--(0,2) , arrow=Arrows ) ;

real cubic( real x ){ return -x^3+3x ; }
draw( graph( cubic , -2 , 2 ) , arrow=Arrows , red ) ;

dot( (1,cubic(1)) , purple ) ;
dot( (0.8,cubic(0.8)) , purple) ;
draw( (1,cubic(1))--(0.8,cubic(0.8)) , purple ) ;
label( "positive slope" , (1,cubic(1))--(0.8,cubic(0.8)) , SE , purple ) ;