// graph of x^3 - 3x^2 + 1
import graph;
size(6cm);
real f(real x){return (x^3 - 3*x^2 + 1);}
xlimits( -1, 3.5);
ylimits(-3.5,1.5);
draw(graph(f,-1,3),black+1bp);
xaxis(Label("$x$",position=EndPoint, align=SE),Ticks("%"), Arrow);
yaxis(Label("$y$",position=EndPoint, align=NW),Ticks("%"), Arrow);
labelx(1,2S);
labely(1,2W);
dot((0,1));
dot((2,-3));
label("$(0,1)$",(0,1),NE);
label("$(2,-3)$",(2,-3),S);
// end