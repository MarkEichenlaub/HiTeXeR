// surface of revolution
import graph;
size(7cm);
real a,b;
a=1; b=3;
real f(real x){return ((1/3)*x^3 - (3/2)*x^2 + 2*x + 2);}
real g(real x){return (-1*f(x));}
path rc = xscale(.3)*yscale(f(b))*unitcircle;
path lc = xscale(.3)*yscale(f(a))*unitcircle;
draw(shift(a,0)*lc,black+0.75bp);
fill(buildcycle((a,g(a))--(a,f(a)),graph(f,a,b),(b,f(b))--(b,g(b)),graph(g,a,b)),rgb(.8,.8,.8));
fill(shift(b,0)*rc,white);
fill(shift(a,0)*lc,rgb(.8,.8,.8));
draw(graph(f,0,3.5),black+0.75bp+dashed);
draw(graph(f,a,b),black+1bp);
draw(graph(g,a,b),black+1bp);
draw(shift(b,0)*rc,black+0.75bp);
draw((b,0)--(4,0));
draw((1/2,0)--(b,0), dashed);
draw((-2,0)--(1/2,0));
xaxis(Label("$x$",position=EndPoint, align=SE),dashed,Arrow);
yaxis(Label("$y$",position=EndPoint, align=NW),Arrow);