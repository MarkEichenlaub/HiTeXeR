import slopefield;
real func(real x, real y) {return y/x;}
 add(slopefield(func,(-3,-3),(-0.1,3),5,Arrow));
 add(slopefield(func,(0.1,-3),(3,3),5,Arrow));
xaxis(Label("$x$",position=EndPoint, align=SE), Arrow);
yaxis(Label("$y$",position=EndPoint, align=NW), Arrow);