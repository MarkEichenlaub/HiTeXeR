// "random" graph
import graph;
size(7cm);
real a,b, xn, xm;
a=1; b=3;
xn = 2.0;
xm = 2.5;

real f(real x){return ((1/3)*x^3 - (3/2)*x^2 + 2*x + 2);}
real g(real x){return (-1*f(x));}
draw(graph(f,0,3.5),black+1bp);
draw((a,0)--(a,f(a)),black+0.75bp+dashed);
draw((b,0)--(b,f(b)),black+0.75bp+dashed);
draw((xn,0)--(xn,f(xn)),black+0.75bp+dashed);
draw((xm,0)--(xm,f(xm)),black+0.75bp+dashed);
fill((xn,f(xn))--(xn,0) --(xm,0)--(xm,f(xn))--cycle,rgb(.8,.8,.8));
xaxis(Label("$x$",position=EndPoint, align=SE),Arrow);
yaxis(Label("$y$",position=EndPoint, align=NW),Arrow);
label("$a$",(a,0),1.5*S);
label("$x_i$", (xn,0),S);
label("$x_{i+1}$", (xm,0),S);
label("$b$",(b,0),S);