size(5cm);
import graph;
real c = 1.8;
real d = sqrt(1/(c+1));
real g (real x) {return c*x^2;}
xlimits(0,1);
path q = graph(g,0,1);
real f (real x) {return (1-x^2);}
path p = graph(f,0,1);
xaxis(Label("$x$",position=EndPoint, align=SE),Arrow);
yaxis(Label("$y$",position=EndPoint, align=NW),Arrow);
draw ((1,g(1))--(1,0),black+dashed+0.5bp);
label("$(1,0)$",(1,0),S);
fill(buildcycle(graph(g,0,d),graph(f,d,0), (0,1)--(0,0)),rgb(.8,.8,.8));
fill(buildcycle(graph(g,1,d),graph(f,d,1), (1,0)--(1,g(1))),rgb(.8,.8,.8));
draw(q,black+1bp);
draw(p,black+1bp);
dot((d,f(d)));
dot((1,0));
dot((1,g(1)));
label("$(1,c)$",(1,g(1)),E);