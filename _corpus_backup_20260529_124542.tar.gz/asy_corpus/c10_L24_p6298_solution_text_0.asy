import graph;
size(5cm);
real f(real x) {return(sqrt(x));}
real fn(real x) {return(-1*f(x));}
real g(real x) {return(sqrt((3-x)/2));}
real gn(real x) {return(-1*g(x));}
draw(graph(f,0,3.5),black+1bp);
draw(graph(fn,0,3.5),black+1bp);
draw(graph(g,-0.5,3),blue+1bp);
draw(graph(gn,-0.5,3),blue+1bp);
xaxis(Arrow(2mm)); yaxis(Arrow(2mm));