import graph;
import contour;
size(6cm);
real f(real x, real y) {return (x-y);}
real g(real x, real y) {return (exp(x)*(y-x+1));}
int i,j,n;
n = 6;
path p=(-0.2,0)--(0.2,0);
pen sf=gray+0.75bp;
for (i=-n; i<=n; ++i) {
for (j=-n; j<=n; ++j) {
draw(shift(i,j)*rotate(degrees(atan(f(i,j))))*p,sf);
}}
draw(contour(g,(-n,-n),(n,n),new real[] {-4,-1,-0.25,0,0.25,1,4}),blue+1bp);
xaxis(Arrow); 
yaxis(Arrow);