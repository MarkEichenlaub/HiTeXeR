size(150,170);
pair L = (0,0), R = (0, 5), Ob = (10,0);
draw(L--Ob);
draw(L--R--Ob, dotted);
real Rswidth = 0.2, Rsheight = 0.4; // semi width and semi height
draw((R+(-Rswidth, -Rsheight))--(R+(Rswidth, -Rsheight))--(R+(Rswidth, Rsheight))--(R+(-Rswidth,Rsheight))--cycle);
draw((R+(-Rswidth, Rsheight))--(R+(0, 1.7*Rsheight))--(R+(Rswidth, Rsheight)));
dot("\scriptsize \begin{tabular}{c}Launch \pad \end{tabular}", L, SSE);
dot("\scriptsize Observer", Ob, NE);
label("\small 250", .5*(L+R), W);
label("\small $	heta$", Ob+ .2*(R-Ob), WSW);
label("\small 1000", .5*(L+Ob), S);