import three;

size(150);

currentprojection = perspective(6,3,2);

triple A, B, C, D;

A = (0,0,0);
B = (-1,0.8,0);
C = (0,1,0);
D = (0.5,0.8,1);

draw(A--C--B--D--cycle);
draw(C--D);
draw(A--B,dashed);

dot("$A$", A, W);
dot("$B$", B, E);
dot("$C$", C, S);
dot("$D$", D, N);