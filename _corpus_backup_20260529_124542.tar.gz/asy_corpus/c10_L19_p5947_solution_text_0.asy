import graph;
size(6cm);

real f(real t) {return(2*cos(t)+cos(2*t));}
real g(real t) {return(2*sin(t)-sin(2*t));}
draw(graph(f,g,0,2*pi,Spline),blue+1bp);
draw(Circle((0,0),3));
draw(Circle((2,0),1));
dot((2,0));
dot((3,0),red);
draw(Circle(2*dir(70),1));
draw(2*dir(70)--(2*dir(70) + dir(-140)));
dot(2*dir(70));
dot(2*dir(70) + dir(-140),red);

xaxis(Label("$x$",position=EndPoint, align=SE),Arrow);
yaxis(Label("$y$",position=EndPoint, align=NW),Arrow);
//