size( 200 ) ;

real fn( real t ){ return sin(t) ; }

fill( graph( fn , 0 , pi/2 )--foot((pi/2,fn(pi/2)),origin,dir(0))--cycle , lightblue ) ;
draw( graph( fn , 0 , pi/2 ) , blue ) ;

draw( (0,-0.5)--(0,1.5) , arrow=Arrows ) ;
draw( (-2,0)--(2,0) , arrow=Arrows ) ;
add(pathticks( (0,0)--(0,1) , 1 , 1 , s=4 )) ; label( "$1$" , (0,1) , 2W ) ;
add(pathticks( (0,0)--(pi/2,0) , 1 , 1 , s=4 )) ; label( "$\frac{\pi}{2}$" , (pi/2,0) , 2S ) ;

real y = 0.6 ; 
transform scaling = scale(1,0.2) ;

draw( shift(0,y)*scaling*circle(origin,pi/2) , red ) ;
draw( shift(0,y)*scaling*circle(origin,asin(y)) , red ) ;
draw( (asin(y),y)--(pi/2,y) , red ) ;
add(pathticks( (0,0)--(0,y) , 1 , 1 , s=4 )) ; label( "$y$" , (0,y) , 2W ) ;
draw( (0,y)--(asin(y),y) , dotted ) ;