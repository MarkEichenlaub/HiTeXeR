// polar area between a and b
import graph;
size(7cm);
real f(real t) {return (1+cos(t));}
pair A,B;
real a,b;
real pi=3.14159;
a= pi/6; b=pi/3;
A = f(a)*expi(a);
B = f(b)*expi(b);
dot(A); dot(B); dot((0,0));
fill(buildcycle((0,0)--A,polargraph(f,a,b),B--(0,0)),rgb(.8,.8,.8));
draw(A--(0,0)--B,dashed+0.75bp);
draw(rotate(180*a/pi)*Label("$	heta=a$"),A/2,SE);
draw(rotate(180*b/pi)*Label("$	heta=b$"),B/2,NW);
draw(polargraph(f,pi/12,5*pi/12),black+1bp);
xaxis(Arrow(2mm));
yaxis(Arrow(2mm));