unitsize(2 cm);

real r, t, x, y;
path foo = (0,0), bar = (0,0);

for (t = 0; t <= 2*pi; t = t + 0.01) {
  r = 1 - cos(t);
  x = r*cos(t);
  y = r*sin(t);
  foo = foo--(x,y);
}

for (t = 0; t <= pi/3; t = t + 0.01) {
  r = 1 - cos(t);
  x = r*cos(t);
  y = r*sin(t);
  bar = bar--(x,y);
}

bar = bar--arc((0,0),1/2,60,300);

for (t = 5*pi/3; t <= 2*pi; t = t + 0.01) {
  r = 1 - cos(t);
  x = r*cos(t);
  y = r*sin(t);
  bar = bar--(x,y);
}

bar = bar--cycle;
fill(bar,gray(0.7));

draw(foo,red);
draw(Circle((0,0),1/2),blue);

t = pi/3;
r = 1 - cos(t);
x = r*cos(t);
y = r*sin(t);
dot((x,y));
draw((0,0)--(x,y));

t = 5*pi/3;
r = 1 - cos(t);
x = r*cos(t);
y = r*sin(t);
dot((x,y));
draw((0,0)--(x,y));

draw((-2.5,0)--(1,0));
draw((0,-1.5)--(0,1.5));