size(175);

// set bounds of the grid
real xmin = 300, xmax = 360, ymin = -10, ymax = 10;

// draw your graph
real f (real x) {return (1/(x-333));}
draw(graph(f,xmin,332.999),red);
draw(graph(f,333.001,xmax),red);
limits((xmin,ymin),(xmax,ymax),Crop);

// x-axis
ticks taxes = Ticks(Label(fontsize(8)), NoZeroFormat, Step = 10, Size = 0.1pt);
xaxis(xmin, xmax, taxes, Arrows(6));
label("$x$", (xmax,0), E, fontsize(10));