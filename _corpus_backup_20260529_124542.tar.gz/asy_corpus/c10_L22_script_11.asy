import slopefield;
import graph;

pair P,Q;
 P=(0,1);
 Q=(0.1,1);
real b=1.1;
real func(real x, real y) {return -x/y;}
 add(slopefield(func,(0.01,-0.01),(b,b),5,gray(0.5),Arrow)); 
 //add(slopefield(func,(-b,-b),(-0.1,b),5,gray(0.5),Arrow));
 //add(slopefield(func,(0.1,-b),(b,b),5,gray(0.5),Arrow));

draw(arc((0,0), 1, 0, 90), blue); 
draw((-0.1, 1)--(b,1));
dot(P);
dot(Q);

xaxis(Label("$x$",position=EndPoint, align=SE));
yaxis(Label("$y$",position=EndPoint, align=NW));