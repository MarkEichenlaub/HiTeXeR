size( 300 ) ;

draw( (-5.5,0)--(5.5,0) , arrow=Arrows(TeXHead) ) ;
draw( (0,-0.5)--(0,5.5) , arrow=Arrows(TeXHead) ) ;

real fn( real x ){ return 1/x ; }
for( int i=-5 ; i<5 ; ++i ){
 draw( (i,-0.25)--(i,5.25) , dotted ) ;
 draw( shift(i,0)*graph( fn , .2 , .99 ) , blue ) ;
 dot( (i+1,1) , blue ) ;
}