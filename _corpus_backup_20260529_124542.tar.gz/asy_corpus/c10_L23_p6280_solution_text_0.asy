draw(unitcircle);
draw((-1.3,0)--(1.3,0));
draw((0,-1.3)--(0,1.3));
label("$j$",(1.2,0),N);
label("$r$",(0,1.2),E);