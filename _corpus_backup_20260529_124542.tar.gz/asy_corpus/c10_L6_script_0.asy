// graph of (x - .5)^3 - .5 x + 1
import graph;
size(6cm);
real f(real x){return ((x - .5)^3 - .5 x + 1);}
xlimits( -.5, 2);
ylimits(-1,2);
draw(graph(f,-.5,2),black+1bp);
xaxis(Label("$x$",position=EndPoint, align=SE),Ticks("%"), Arrow);
yaxis(Label("$y$",position=EndPoint, align=NW),Ticks("%"), Arrow);
labelx(1,2S);
labely(1,2W);
label("$y = g(x)$", (2.2,1));
// end