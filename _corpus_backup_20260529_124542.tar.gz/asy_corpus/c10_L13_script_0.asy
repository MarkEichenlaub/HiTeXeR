unitsize(2cm);

pair A = (0,0);
pair B = (2,0);
pair C = (2,1);

draw(A--B--C--cycle);

label("$	heta$", A, 7*dir(15));
label("$1$", A--B, S);
label("$x$", B--C, E);
label("$\sqrt{x^2 + 1}$", C--A, NW);