size(175);

// set variables
real xmin = -1.8, xmax = 4, ymin = -2.5, ymax = 3.7;
real f (real x) {return (x^3/4 - x^2/3 - x/2+3*cos(x));}
real b = 3.3899;
real l (real x) {return (-x/2+3);}
path s = graph(f, 0, b);
path ll = graph(l, b, 0);

//shaded regions
fill(ll--s--cycle, lightblue);
label("$S$", (1.8, 0.9));

// draw your graph
draw(graph(f,xmin,xmax),blue);
draw(graph(l,xmin,xmax),red+bp);
label("$L$", (3.6, 0.9));
limits((xmin,ymin),(xmax,ymax),Crop);

// draw axes
ticks taxes = Ticks(Label(fontsize(8)), NoZeroFormat, Step = 1, Size = 0.1pt);
xaxis(xmin, xmax, taxes, above=true);
yaxis(ymin, ymax, taxes, above=true);