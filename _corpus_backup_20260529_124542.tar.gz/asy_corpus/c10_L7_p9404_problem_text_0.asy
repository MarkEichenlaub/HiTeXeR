fill(arc((0,0), 1, 90, 270)--cycle, white);
draw(arc((0,0), 1, 90, 270), black+1.5bp); 
draw("$r$", (0,0)--(0,1), red+0.5bp);

pair A, B;
A = (-2.2,-1);
B = (-2.2,1);

draw(A--(0,-1), black+1.5bp);
draw(B--(0,1), black+1.5bp);
draw(B--A, black+1.5bp);

fill(A--B--arc((0,0), 1, 90, 270)--cycle, 0.7*lightgreen);