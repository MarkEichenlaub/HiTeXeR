size(10cm,0);

real s(real x) {return (sin(x));}

draw(graph(s,-7,7),lightgrey);

draw(graph(s,-pi/2,pi/2),red+1bp);

xaxis(Label("$x$",position=EndPoint,align=NE),Ticks("%",Step=1),Arrow(2mm));

yaxis(Label("$y$",position=EndPoint,align=NE),Ticks("%",Step=1),Arrow(2mm));