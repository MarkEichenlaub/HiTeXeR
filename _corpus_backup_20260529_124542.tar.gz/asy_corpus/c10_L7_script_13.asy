// damped spring e^(-t) * cos(t)
import graph;
size(7cm);
real f(real x){return (5*exp(-x)*cos(x));}
xlimits(0,8);
draw(graph(f,0,8),black+1bp);
xaxis(Label("$t$",position=EndPoint, align=SE),Ticks("%"), Arrow);
yaxis(Label("$y$",position=EndPoint, align=NW),Ticks("%"), Arrow);
label("$1$",(0,5),2W);
label("$1$",(1,0),2S);
// end