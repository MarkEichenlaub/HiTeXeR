import graph;
import contour;
size(4cm);
real a,b;
real f(real x,real y) {return ((x^2+y^2+a^2)^2 - 4*a^2*x^2);}
a=1; b=sqrt(2);
draw(contour(f,(-2,-2),(2,2),new real[] {b^4}),green+1bp);
b=sqrt(0.5);
draw(contour(f,(-2,-2),(2,2),new real[] {b^4}),red+1bp);
dot((a,0),black+2bp);
dot((-a,0),black+2bp);
xaxis(Arrow); yaxis(Arrow);