// approximation of MVTh (want to clean up) with dotted line
import graph;
size(6cm);
real a,b,c;
a = 1;
b = 4;
c = 2;
real f(real x){return (-1*(x-2)*(x-4)*exp(-x/2) + 1);}
xlimits(0, 5);
draw(graph(f,a,b),black+0.75bp);
xaxis(Label("$x$",position=EndPoint, align=SE),Arrow);
yaxis(Label("$y$",position=EndPoint, align=NW),Arrow);
dot((a,f(a)));
dot((b,f(b)));
//draw((a,f(a))--(b,f(b)),black+dashed);
real m = (f(b)-f(a))/(b-a);
pair P = (2.05,f(2.05));
pair Q = (1,m);
//draw((P-Q)--(P+Q),blue+1bp);
//dot(P,blue+2bp);
label("$(a,f(a))$",(a,f(a)),E);
label("$(b,f(b))$",(b,f(b)),E);
draw((a,f(a))--(b,f(b)), dashed);
// end