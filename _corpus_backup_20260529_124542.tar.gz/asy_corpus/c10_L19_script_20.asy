// Lissajous with 3,5
import graph;
size(6cm);
real pi=3.14159;
real f(real t) {return(cos(3*t));}
real g(real t) {return(sin(5*t));}
draw(graph(f,g,0,2*pi,Spline),blue+1bp);
xaxis(Label("$x$",position=EndPoint, align=SE),Arrow);
yaxis(Label("$y$",position=EndPoint, align=NW),Arrow);
//