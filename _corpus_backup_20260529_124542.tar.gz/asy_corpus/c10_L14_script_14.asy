pair A,B,C;
A = origin;
B = (0,1);
C = (2,0);

draw(A--B--C--cycle);
draw(rightanglemark(C,A,B,6));

label("$dx$", A--C, S);
label("$dy$", A--B, W);
label("$\sqrt{(dx)^2 + (dy)^2}$", B--C, NE);