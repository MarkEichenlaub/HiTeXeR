size(200);
//initializing variable types
int n;

// function
real f(real x){return (5*log(n));}

//plot points
for (n=1; n<22; ++n) {
  dot((n-1, f(n)));
  }

draw((0,f(24)+1)--(20,f(24)+1),dashed);
draw((18,11.5)--(19.7,f(21)-1),Arrow);
label(scale(0.7)*"Monotonically increasing, bounded sequence", (10,f(24)+1),N);
label("$(n,a_n)$",(18,10),N);

//axes 
xaxis();
yaxis();
//end