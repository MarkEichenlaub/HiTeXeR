import graph;
size(4cm);
real a,b;
real f(real t) {return (a+b*sin(t));}
a=2; b=3;
draw(polargraph(f,0,radians(360)),blue+1bp);
xaxis(Arrow); yaxis(Arrow);