// int_0^1 1/sqrt(x)
size(7cm);
import graph;
real f(real x) {return (1/sqrt(x));}
fill(buildcycle(graph(f,0.1,2),(0.1,f(0.1))--(0,f(0.1))--(0,0)--(2,0)--(2,f(2))),rgb(.8,.8,.8));
draw(Label("$y = \frac{1}{\sqrt{x}}$", align=NE),graph(f,0.1,2),black+1bp);
draw((2,0)--(2,f(2)),black+0.75bp);
xaxis(Label("$x$",position=EndPoint, align=SE), Arrow);
yaxis(Label("$y$",position=EndPoint, align=NW), Arrow);
label("$1$",(2,0),S);
label ("$\vdots$", (0.07,3.4));