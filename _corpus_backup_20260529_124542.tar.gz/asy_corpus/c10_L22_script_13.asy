import slopefield;
import graph;

pair P,Q, R, S;
 P=(0,1);
 Q=(0.1,1);
 R=(0.2, 0.99);
 S=(0.3, 0.9698);
real b=1.1;
real func(real x, real y) {return -x/y;}
 add(slopefield(func,(0.01,-0.01),(b,b),5,gray(0.5),Arrow)); 
real tang(real x) {return R.y+func(R.x, R.y)*(x-R.x);}

draw(arc((0,0), 1, 0, 90), blue); 
draw((-0.1, tang(-0.1))--(b,tang(b)));
dot(P);
dot(Q);
dot(R);
dot(S);

xaxis(Label("$x$",position=EndPoint, align=SE));
yaxis(Label("$y$",position=EndPoint, align=NW));