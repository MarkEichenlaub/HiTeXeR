// limit x->infty
import graph;
size(7cm);
real f(real x){return (10*(1+(1/x)*sin(x)));}
draw(graph(f,0.5,20.5),black+1bp);
xaxis(Label("$x$",position=EndPoint, align=SE), Arrow);
yaxis(Label("$y$",position=EndPoint, align=NW), Arrow);
real d,e;
e = 0.9;
d = 0.1;
draw((0,10-e)--(21,10-e),blue);
draw((0,10+e)--(21,10+e),blue);
label("$L - \epsilon$",(21,10-e),SE);
label("$L + \epsilon$",(21,10+e),NE);
draw((13,0)--(13,15),red);
label("$N$",(13,15),NE);