// graph of (x^2-1)/(x-1)

import graph;

size(7cm);

real f(real x){return (x+1);}

xlimits( -3, 3);

ylimits( -3, 6);

draw(graph(f,-3,3));

xaxis(Label("$x$",position=EndPoint, align=SE),Ticks("%"), Arrow);

yaxis(Label("$y$",position=EndPoint, align=NW),Ticks("%"), Arrow);

labelx(1,2S);

labely(1,2W);

dot((0,0));
dot((1,5));

unfill(shift(1,2)*scale(.1)*unitcircle);

draw(shift(1,2)*scale(.1)*unitcircle);

// end