unitsize(1 cm);

pair A, B, O;

A = (4,1);
B = (1.5,4);
O = (0,0);

draw(A--B--O--cycle);

draw((-1,0)--(4,0),Arrows(8));
draw((0,-1)--(0,4),Arrows(8));

label("$(r_1,	heta_1)$", A, E);
label("$(r_2,	heta_2)$", B, N);
label("$r_1$", A/2, S);
label("$r_2$", B/2, W);
label("$	heta_2 - 	heta_1$", (1,0.7));