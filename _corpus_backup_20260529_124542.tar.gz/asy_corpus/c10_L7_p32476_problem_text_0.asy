unitsize(5cm);

pair A = (0, 0);
pair B = (0, 1);
pair C = (1, 1);
pair D = (1, 0);
pair E = (0.3, 1);
pair F = (1, 0.6);

draw(A--B--C--D--cycle);
D(E--A--F--cycle);
draw(MA("\alpha", 12, red, F, A, E, 0.1, 1, red));
draw(MA("	heta", 12, black, D, A, F, 0.1, 1, black));

label("$A$", A, SW);
label("$B$", B, NW);
label("$C$", C, NE);
label("$D$", D, SE);
label("$E$", E, N);
label("$F$", F, NE);