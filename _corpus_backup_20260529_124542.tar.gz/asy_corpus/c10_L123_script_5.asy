unitsize(2 cm);

draw(Circle((0,0),1),red);
draw((0,0)--dir(120));
draw((-1.2,0)--(1.2,0));
draw((0,-1.2)--(0,1.2));
draw(arc((0,0),0.15,0,120));
draw(dir(120)--(-0.5,0),dashed);

label("$	heta$", (0.15,0.25), UnFill);
label("$1$", 0.6*dir(120), NE);
label("$\cos 	heta$", (-0.25,0), S);
label("$\sin 	heta$", (-0.5,sqrt(3)/4), W, UnFill);
dot("$\left( \frac{c_2}{\sqrt{c_1^2 + c_2^2}}, \frac{c_1}{\sqrt{c_1^2 + c_2^2}} \right)$", dir(120), NW);