// limit x->infty
import graph;
size(7cm);
real f(real x){return (1/(x^3));}
xlimits( 1, 5);
ylimits( -1, 2);
draw(graph(f,0.8,5),black+1bp);
xaxis(Label("$x$",position=EndPoint, align=SE), Arrow);
yaxis(Label("$y$",position=EndPoint, align=NW), Arrow);
real d;
d= 1.0;
draw((1,0)--(1,1), dashed);
draw((1,-0.1)--(1,0.1));
label("$1$",(1,0),2S);
draw((5,-0.1)--(5,0.1));
label("$5$",(5,0),2S);
label("$f(x) = \frac 1{x^3}$", (4,2)); 
fill(buildcycle((d,0)--(d, f(d)),graph(f,d,5),(5,f(5))--(5,0), (5,0)--(1,0)), rgb(.8,.8,.8));