size(6cm);

// ladder sliding
pair B=(-20,0);
pair T=(0,20);

draw ((-20,0)--(0,0)--(0,20),black+1bp);
draw ("6 ft",(-10,0)--(0,15),blue+1.5bp);
draw ("2 in/sec",(-15,-1)--(-10,-1),black,BeginArrow);

label("$x(t)$",0.25*B,S);
label("$h(t)$", 0.4*T,E);

// end