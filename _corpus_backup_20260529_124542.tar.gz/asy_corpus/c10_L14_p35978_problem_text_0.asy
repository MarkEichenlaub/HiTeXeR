unitsize(3 cm);

pair A, B, O;

A = dir(70);
B = dir(110);
O = (0,0);

draw(Circle(O,1));
draw(A--O--B--cycle);
draw(arc(O,1,70,110),red + linewidth(2*bp));

label("$A$", A, A);
label("$B$", B, B);
label("$O$", O, S);
label("$2 \alpha$", (0,0.3));
label("$R$", (O + A)/2, SE);