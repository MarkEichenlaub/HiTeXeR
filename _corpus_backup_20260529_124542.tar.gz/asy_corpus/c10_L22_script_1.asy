import slopefield;
real func(real x, real y) {return y;}
 add(slopefield(func,(-3,-3),(3,3),8,Arrow));
xaxis(Label("$x$",position=EndPoint, align=SE), Arrow);
yaxis(Label("$y$",position=EndPoint, align=NW), Arrow);
draw(curve((1,1),func,(-3,-3),(3,3)),blue);
draw(curve((-2,2),func,(-3,-3),(3,3)),blue);
draw(curve((-1,-1),func,(-3,-3),(3,3)),blue);