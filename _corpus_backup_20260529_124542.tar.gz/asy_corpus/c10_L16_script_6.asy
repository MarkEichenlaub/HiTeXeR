// limit x->infty
import graph;
size(5cm);
real f(real x){return (exp(-x));}
xlimits( -0.5, 4);
ylimits( -1, 3);
draw(graph(f,-0.5,4),black+1bp);
xaxis(Label("$x$",position=EndPoint, align=SE), Arrow);
yaxis(Label("$y$",position=EndPoint, align=NW), Arrow);

label("$f(x) = e^{ax} \quad (a <0)$", (1,2));

fill(buildcycle((0,0)--(0, f(0)),graph(f,0,4),(4,f(4))--(4,0), (4,0)--(0,0)), rgb(.8,.8,.8));