import graph;
size(7cm);
real pi=3.14159;
real i;
real f(real t) {return (1+2*sin(t));}
draw(polargraph(f,0,pi/2),blue+1bp);
for(i=30; i<360; i=i+30) {
  draw(rotate(i)*((0,0)--(3,0)),black+0.5bp);
}
for(i=0;i<3.25;i=i+0.5) {
  draw(scale(i)*unitcircle,black+0.5bp);
}
xaxis(Arrow(2mm));
yaxis(Arrow(2mm));