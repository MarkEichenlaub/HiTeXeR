unitsize(1.5 cm);

pair A, B, M, O;

O = (0,0);
A = (1,0);
B = dir(130);
M = (A + B)/2;

draw(Circle(O,1));
draw(O--A);
draw(O--B);
draw(A--B);
draw(O--M);

dot("$A$", A, A);
dot("$B$", B, B);
dot("$M$", M, NE);
dot("$O$", O, SW);