// impossibility of two distinct limits
import graph;
size(6cm);
real f(real x){return ((1/3)*x^3 - 2*x^2 + 3*x + 2);}
xlimits( -0.5, 3.5);
ylimits( -1, 3);
xaxis(Label("$x$",position=EndPoint, align=SE),Arrow);
yaxis(Label("$y$",position=EndPoint, align=NW),Arrow);
dot((0,0));
unfill(shift(2,f(2))*scale(.05)*unitcircle);
draw(shift(2,f(2))*scale(.05)*unitcircle);
unfill(shift(2,1.6)*scale(.05)*unitcircle);
draw(shift(2,1.6)*scale(.05)*unitcircle);
real e;
e = 0.15;
draw((0,f(2)-e)--(3,f(2)-e),blue);
draw((0,f(2)+e)--(3,f(2)+e),blue);
label("$L - \epsilon$",(3,f(2)-e),E);
label("$L + \epsilon$",(3,f(2)+e),E);
draw((0,1.6-e)--(3,1.6-e),blue);
draw((0,1.6+e)--(3,1.6+e),blue);
label("$L' - \epsilon$",(3,1.6-e),E);
label("$L' + \epsilon$",(3,1.6+e),E);
draw((2,0)--(2,4));
label("$a$",(2,0),S);
// end