size(170);
draw(circle((0,0),1),linewidth(1));
draw((-1.5,0)--(1.5,0),Arrow);
draw((0,-1.5)--(0,1.5),Arrow);

label("$y$",(0,1.4),E);
label("$x$",(1.4,0),S);
label("$	heta$",.5*dir(30),S);
label("$	heta+\pi$", .3*dir(-150), WNW);

draw((-sqrt(3)/2,-1/2)--(sqrt(3)/2,1/2));
dot((sqrt(3)/2,1/2));
dot((-sqrt(3)/2,-1/2));