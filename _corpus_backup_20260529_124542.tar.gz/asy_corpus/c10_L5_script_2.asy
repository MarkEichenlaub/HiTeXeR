size(6cm);
draw((0,0)--(2,0)--(2,1)--cycle,black+1bp);
label("$	heta$",(0.3,0.075));
label("$1$",(1,0),S);
label("$x$",(2,0.5),E);
//label("$\sqrt{x^2+1}$",(1,0.5),NW);