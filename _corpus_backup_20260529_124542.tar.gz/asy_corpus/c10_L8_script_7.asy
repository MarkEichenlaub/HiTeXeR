size(300);
import graph;
real f(real x){return (sin(x));}
real g(real x){return (Sin(x));}
draw(graph(f,0,10),black+1bp);
draw(graph(g,0,10),blue+1bp);
xaxis(Label("$x$",position=EndPoint, align=SE),Ticks("%"), Arrow);
yaxis(Label("$y$",position=EndPoint, align=NW), Arrow);