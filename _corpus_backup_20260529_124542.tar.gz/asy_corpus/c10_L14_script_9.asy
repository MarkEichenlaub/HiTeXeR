// cylindrical shell
import graph;
size(5cm);
real a,b;
a=2; b=2.5;
real f(real x){return (8/3);}
real g(real x){return (8/3);}
path rc = yscale(.2)*xscale(b)*unitcircle;
path lc = yscale(.1)*xscale(a)*unitcircle;
path p = buildcycle(graph(g,-b,-a),(-a,g(-a))--(a,f(a)),graph(f,a,b),(b,f(b))--(b,0)--(-b,0)--(-b,g(-b)));
fill(p,rgb(.8,.8,.8));
fill(shift(0,f(a))*lc,white);
fill(rc,rgb(.8,.8,.8));
draw(shift(0,f(a))*lc,black+0.75bp);
draw(shift(0,f(b))*rc,black+0.75bp);
draw(rc,black+0.75bp);
draw(graph(f,a,b),blue+1.5bp);
draw(graph(g,-1*b,-1*a),black+1.5bp);
xaxis(Label("$x$",position=EndPoint, align=SE),Arrow);
yaxis(Label("$y$",position=EndPoint, align=NW),Arrow);
draw((0,-.25)--(0,8/3), dotted);
draw((0,8/3-0.1)--(0,8/3+1));
draw((-b,0)--(b,0),dotted);
draw((-0.5-b,0)--(-b,0));
draw((b,0)--(b+0.5,0));

draw((a,0)--(a,f(a)),black+0.75bp+dashed);
draw((b,0)--(b,f(b)),black+0.75bp);
draw((-a,0)--(-a,g(-a)),black+0.75bp+dashed);
draw((-b,0)--(-b,g(-b)),black+0.75bp);
draw(shift(0,0)*lc,black+0.75bp+dashed);

label("$x_i$",(a,0),1.5*S);
label("$-x_i$",(-a,0),2.5*S + .25E);

label("$x_{i+1}$",(b,0),S+.5E);
label("$-x_{i+1}$",(-b,0),S+.75*W);