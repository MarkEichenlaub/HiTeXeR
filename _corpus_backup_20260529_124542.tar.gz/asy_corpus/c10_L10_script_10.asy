// int of x^2 on [1,2]
import graph;
size(8cm);
real f(real x){return (x^2);}
real a,b;
a = 1; b = 2;
path bdry=(b,f(b))--(b,0)--(a,0)--(a,f(a));
fill(buildcycle(bdry,graph(f,a,b)),.8white);
picture otherstuff;
draw(otherstuff,graph(f,0,2.1),black+1bp);
draw(otherstuff,bdry,black+1bp+dashed);
xaxis(otherstuff,Label("$x$",position=EndPoint, align=SE),Arrow);
yaxis(otherstuff,Label("$y$",position=EndPoint, align=NW),Arrow);
add(otherstuff);
label("$1$",(1,0),S);
label("$2$",(2,0),S);
// end