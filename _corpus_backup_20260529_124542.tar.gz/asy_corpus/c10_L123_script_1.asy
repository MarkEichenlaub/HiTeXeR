unitsize(2 cm);

real func (real x) {
  return(1/(1 + exp(-2*x)));
}

draw(graph(func,0,5),red);
draw((-0.2,0)--(5,0));
draw((0,1)--(5,1),dashed);
draw((0,-0.2)--(0,1.2));

label("$y = \frac{1}{1 + e^{-2x}}$", (5,1), E, red);
label("$x$", (5,0), E);
label("$y$", (0,1.2), N);