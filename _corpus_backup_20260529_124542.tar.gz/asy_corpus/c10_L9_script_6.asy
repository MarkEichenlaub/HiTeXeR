// coffee filter frustum
size(6cm);
draw ((1,0)--(4,6)--(-4,6)--(-1,0)--cycle,black+1bp);
draw ("4",(4,6.5)--(0,6.5),Arrows);
draw ("1",(0,-0.5)--(1,-0.5),Arrows);
draw ("6",(0,0)--(0,6),Arrows);
// draw ((1,0)--(0,-2)--(-1,0),black+1bp+dotted);
// end