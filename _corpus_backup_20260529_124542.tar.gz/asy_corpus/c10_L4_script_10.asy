// deriv of |x|
import graph;
size(7cm);
real f(real x){return (abs(x));}
xlimits( -2.5,2.5);
draw((-2.5,-1)--(0,-1),black+0.75bp);
draw((0,1)--(2.5,1),black+0.75bp);
xaxis(Label("$x$",position=EndPoint, align=SE),Ticks("%"), Arrows);
yaxis(Label("$y$",position=EndPoint, align=NW), Arrow);
unfill(shift(0,-1)*scale(.05)*unitcircle);
draw(shift(0,-1)*scale(.05)*unitcircle);
unfill(shift(0,1)*scale(.05)*unitcircle);
draw(shift(0,1)*scale(.05)*unitcircle);
label("$y = \frac{|h|}{h}$", (2,1.5));
// end