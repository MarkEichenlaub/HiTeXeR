unitsize(6 cm);

real func (real x) {
  return ((x*sqrt(x) - 3*sqrt(x) + 2)/3);
}

real funcprime (real x) {
  return ((x - 1)/(2*sqrt(x)));
}

real a = 0.4;
pair D = (a,func(a)), R = (0,func(a) - a*funcprime(a));

draw(D--R);
draw(graph(func,1,0.1),red,Arrow(6));
draw((0,0)--(1,0));
draw((0,0)--(0,0.5));

dot("$(a,f(a))$", D, NE);