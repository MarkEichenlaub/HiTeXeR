unitsize(1.5 cm);

real a = 0.8;
pair O, P, Q;

O = (0,0);
P = (1,1.5) + dir(20);
Q = 2*dir(110);

draw(arc((1,1.5),1,80,-40),red);
draw(O--interp(O,P,1.5));
draw(O--(2,0));
draw((P + dir(-70))--(P + dir(110)));
draw(O--Q);

label("$r = f(	heta)$", (1,1.5) + dir(80), W, red);
label("$	heta$", (0.5,0.2));
label("$\alpha$", P + (0.1,0.3));
label("$\alpha$", O + (0.1,0.3));
dot("$O$", O, SW);
dot("$P = (f(	heta), 	heta)$", P, E);
label("$Q$", Q, NW);