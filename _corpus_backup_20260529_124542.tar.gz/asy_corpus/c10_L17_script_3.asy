// alternating series
size(8cm,0);
real r=0;
real s;
int i;
draw((-0.25,0)--(1.25,0),black+1bp,Arrow);
draw((0,-0.1)--(0,0.1),black+0.5bp);
label("$0$",(0,-0.1),S);
draw((1,-0.1)--(1,0.1),black+0.5bp);
label("$1$",(1,-0.1),S);
for (i=1;i<7;++i) {
s = r + ((-1)^(i+1))/i;
draw((r,0)..((r+2*s)/3,(7-i)*0.05)..(s,0),black+0.75bp,Arrow(3mm));
r = s;
}
label("\small $\frac12$",(1/2,0),S);
label("\small$\frac56$",(5/6,0),S);
label("\small $\frac{7}{12}$",(7/12,0),S+.5W);
label("\small$\frac{47}{60}$",(47/60,0),S);
label("\small $\frac{37}{60}$",(37/60,0),S);
//