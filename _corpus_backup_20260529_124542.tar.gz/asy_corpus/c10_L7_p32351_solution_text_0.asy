unitsize(0.75inch);
pair A, B, P, Q;

Q = (3/2, 0);

A = (2, 0);
B = (-sqrt(3), 0);
P = (3/2, sqrt(3)/2);

draw(arc((0, 0), sqrt(3), 0, 180));
draw(arc((0, 0), 2, 0, 180));
draw((-2, 0)--(-sqrt(3), 0));
draw((2, 0)--(sqrt(3), 0));
draw(A--P, red);
draw(arc((0, 0), sqrt(3), 30, 180), red);
dot(B);
dot(A);
dot(P);
draw(P--Q, dashed);
draw(B--(sqrt(3), 0), dashed);
draw((0, 0)--P, dashed);

label("$A$", A, E);
label("$B$", B, E);
label("$P$", P, NE);
label("$	heta$", (0, 0), NE);
label("$O$", (0, 0), S);
label("$Q$", Q, S);