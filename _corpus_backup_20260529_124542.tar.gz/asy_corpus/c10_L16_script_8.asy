// int_-inf^inf 1/(1+x^2)
size(7cm);
import graph;
real f(real x) {return (3/(1+x^2));}
fill(buildcycle(graph(f,0,5),(0,f(0))--(0,0)--(5,0)--(5,f(5))),rgb(.8,.8,.8));
draw(graph(f,0,5),black+1bp);
xaxis(Label("$x$",position=EndPoint, align=SE), Arrow);
yaxis(Label("$y$",position=EndPoint, align=NW), Arrow);

label("$f(x) = \frac{1}{1+x^2}$", (3,2));
//