size(5cm);
import graph;
real g (real x) {return x^2;}
xlimits(-0.5,1.5);
path q = graph(g,-0.5,1.5);
draw(q,black+1bp,Arrows(2mm));
real f (real x) {return x^(1/2);}
path p = graph(f,0,1.5);
draw(p,black+1bp,Arrow(2mm));
xaxis(Label("$x$",position=EndPoint, align=SE),Arrow);
yaxis(Label("$y$",position=EndPoint, align=NW),Arrow);

dot((0,f(0)), blue); dot((1,f(1)), blue);

draw ((1,f(1))--(1,0),black+dashed+0.5bp);

label("$x=1$",(1,0),S);