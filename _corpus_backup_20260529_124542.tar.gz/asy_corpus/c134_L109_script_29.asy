import three;

size(150);

currentprojection = perspective(6,3,2);

triple A, B, C, D, E, F, G, H, P, X;

A = (0,0,0);
B = (4,0,0);
C = (4,5,0);
D = (0,5,0);
E = (0,0,3);
F = (4,0,3);
G = (4,5,3);
H = (0,5,3);
P = (3,4,5);
X = (2,3,3);

draw(B--C--D--H--E--F--cycle);
draw(G--C);
draw(G--F);
draw(G--H);
draw(A--B,dashed);
draw(A--D,dashed);
draw(A--E,dashed);
draw(P--X);

dot("$P$", P, N);
dot("$X$", X, W);