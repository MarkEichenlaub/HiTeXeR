unitsize(1.5 cm);

real f(real x) {
  return (x^3/4);
}

fill(graph(f,0,2)--(2,0)--cycle,gray(0.7));

draw((0,0)--(2,0));
draw((0,0)--(0,2));
draw((2,0)--(2,f(2)));
draw(graph(f,0,2));
draw((1.6,0)--(1.6,f(1.6)),dashed);
draw(shift((1.6,0))*xscale(0.2)*Circle((0,0),f(1.6)));