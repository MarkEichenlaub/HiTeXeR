unitsize(1 cm);

real r = 1, s = 2;
pair A, B, O, P, R;

A = (0,0);
B = (2*sqrt(r*s),0);
O = A + (0,r);
P = B + (0,s);
R = (B.x,O.y);

draw(A--O--P--B,red);
draw(Circle(O,r));
draw(Circle(P,s));
draw((-r,0)--(2*sqrt(r*s) + s,0));
draw(O--R,red);

dot("$A$", A, S);
dot("$B$", B, S);
dot("$O$", O, NW);
dot("$P$", P, NE);
dot("$R$", R, E);
label("$c$", (A + B)/2, S, red);
label("$r$", (A + O)/2, W, red);
label("$r$", (B + R)/2, E, red);
label("$s - r$", (P + R)/2, E, red);