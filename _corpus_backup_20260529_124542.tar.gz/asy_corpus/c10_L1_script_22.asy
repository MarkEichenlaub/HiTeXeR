size(170);
draw(circle((0,0),1),linewidth(1));
draw((-1.5,0)--(1.5,0),Arrow);
draw((0,-1.5)--(0,1.5),Arrow);
/*dot((1,0));
*dot((0,1));
*dot((-1,0));
*dot((0,-1));
*/

label("$y$",(0,1.4),E);
label("$x$",(1.4,0),S);
label("$t$",(0,0)--(sqrt(3)/2,1/2),SE);

draw((0,0)--(sqrt(3)/2,1/2));
dot((sqrt(3)/2,1/2));
label("$(x,y)$", (sqrt(3)/2, 1/2), NE);