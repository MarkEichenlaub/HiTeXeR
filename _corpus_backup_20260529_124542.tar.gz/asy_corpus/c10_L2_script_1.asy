// generic function and secant line

// change h to get closer approximation

import graph;

size(7cm);

real h = 1;

real f(real x){return (0.1*x^3 + 0.1*x^2 + 0.15*x + 0.5);}

pair P,Q;

P = (1,f(1));

Q = (1+h,f(1+h));

real m = ((f(1+h)-f(1))/h);

real g(real x){return (m*x + (f(1)-m));}

xlimits( -0.25, 2.25);

draw(graph(f,-0.25,2.25),black+1bp);

draw(graph(g,0,2.25),blue+0.75bp);

xaxis(Label("$x$",position=EndPoint, align=SE),NoTicks, Arrow);

yaxis(Label("$y$",position=EndPoint, align=NW),NoTicks, Arrow);

dot(P);

dot(Q);

label("$P$",P,SE);

label("$Q$",Q,SE);

// end