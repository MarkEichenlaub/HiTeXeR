// intro area under curve pic
import graph;
size(7cm);
path bdry=(1,1)--(1,0)--(4,0)--(4,2);
fill(buildcycle(bdry,(1,1)--(2,0)--(4,2)),rgb(.8,.8,.8));
draw((.5,1.5)--(2,0)--(4.5,2.5),black+1bp);
draw(bdry,black+1bp+dashed);
xaxis(Label("$x$",position=EndPoint, align=SE),NoTicks, Arrow);
yaxis(Label("$y$",position=EndPoint, align=NW),NoTicks, Arrow);
label("$1$",(1,0),S);
label("$4$",(4,0),S);
// end