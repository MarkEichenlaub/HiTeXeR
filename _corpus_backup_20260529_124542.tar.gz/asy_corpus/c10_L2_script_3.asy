size(10cm);

int start=0;//Try changing the start value!!
int end=4;//Try changing the end value!!

real startofboldline=1.5;//Try changing the value!!
real endofboldline=2.5;//Try changing the value!!

draw((startofboldline,0)--(endofboldline,0),linewidth(1.75));

for(int i=start;i<end+1;++i)
{
add(pathticks((i+1,0)--(i-1,0),1));
label(string(i),(i,0),2*S);
} 
for(int i=start;i<end;++i)
{
add(pathticks((i+0.5,0)--(i-0.5,0),1));
label(string(i+0.5),(i+0.5,0),2*S);
} 
draw((start-1,0)--(end+1,0),arrow=ArcArrows(HookHead));