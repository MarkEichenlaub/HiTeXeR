// Newton 2nd iteration
import graph;
size(10cm);
real r = 1.8;
real f(real x){return (0.1*x^3 + 0.1*x^2 + 0.15*x - 0.5);}
real d(real x){return (0.3*x^2 + 0.2*x + 0.15);}
real m = d(r);
real g(real x){return (m*(x-r) + f(r));}
pair P;
P = (r,f(r));
xlimits( 0.5, 2.25);
draw(graph(f,0.5,2.25),black+1bp);
draw(graph(g,0.75,2.25),blue+0.75bp);
xaxis(Label("$x$",position=EndPoint, align=SE),Arrow);
yaxis(Label("y",position=EndPoint, align=NW),Arrow);
draw((r,f(r))--(r,0),black+dashed);
label("$r_0$",(r,0),S);
dot((r,f(r)));
real s = r - (f(r)/d(r));
draw((s,0)--(s,f(s)),black+dashed);
label("$r_0 - \frac{f(r_0)}{f'(r_0)}$", (s,0),S);
dot((s,f(s)));
// end