// pumping station
import graph;
size(6cm);
draw((0,0)--(20,0),blue+0.75bp);
draw((0,1)--(20,1),blue+0.75bp);
draw((0,-5)--(5,0)--(20,-20),black+0.75bp);
draw((0,3.5)--(20,3.5),Arrows(2mm)); 
label("$4$ miles",(10,3),N);
draw("$x$",(0,3)--(5,3),Arrows(2mm)); 
draw((0,-5)--(0,0), black+dashed);
label("1 mile",(0,-2.5),W); 
draw((20,0)--(20,-20), black+dashed); 
label("4 miles",(20,-10),E);
label("Draigh",(0,-5),S);
label("Dezertch",(20,-20),S);
// end