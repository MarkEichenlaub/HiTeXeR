// function on [a,b] with max at enpts
import graph;
size(8cm);
real a,b,c;
a = 2;
b = 4;
c = 3;
real f(real x){return ((2/9)*(x-1)^2+1);}
xlimits(0, 5);
draw(graph(f,a,b),black+0.75bp);
xaxis(Label("$x$",position=EndPoint, align=SE),Arrow);
yaxis(Label("$y$",position=EndPoint, align=NW),Arrow);
dot((a,f(a)));
dot((b,f(b)));
draw((a,0)--(a,f(a)),black+dashed);
draw((b,0)--(b,f(b)),black+dashed);
label("$a$",(a,0),S);
label("$b$",(b,0),S);
// end