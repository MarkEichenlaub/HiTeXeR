unitsize(0.6 cm);

draw((0,0)--(4,0)--(4,3)--(0,3)--cycle);

label("$a$", (2,0), S);
label("$b$", (4,3/2), E);