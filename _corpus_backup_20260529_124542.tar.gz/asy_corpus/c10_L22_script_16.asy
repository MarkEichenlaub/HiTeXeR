import slopefield;
import graph;

pair P,Q, R, S;
 P=(0,1);
 Q=(0.1,1.1);
 R=(0.2, 1.21);
 S=(0.3, 1.331);
real b=0.5;
real e(real x) {return exp(x);}
 draw(graph(e,-0.01,b), blue);
real func(real x, real y) {return y;}
 add(slopefield(func,(0.01,-0.01),(b,e(b)),7,gray(0.5),Arrow)); 
real tang(real x) {return R.y+func(R.x, R.y)*(x-R.x);}
 draw((-0.01, tang(-0.01))--(b,tang(b)));
dot(P);
dot(Q);
dot(R);
dot(S);

xaxis(Label("$x$",position=EndPoint, align=SE));
yaxis(Label("$y$",position=EndPoint, align=NW));