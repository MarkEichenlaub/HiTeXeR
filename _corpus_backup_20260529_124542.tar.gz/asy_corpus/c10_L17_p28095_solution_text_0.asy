size( 200 ) ;

real reciprocal( real x ){ return 1/x ; }
fill( graph( reciprocal , 1 , 2 )--(2,0)--(1,0)--cycle , gray ) ;
draw( (0.75,0)--(2.25,0) , linewidth(2) ) ;
draw( graph( reciprocal , 0.75 , 2.25 ) ) ;
draw( box( (1,reciprocal(1)) , (2,reciprocal(2)) ) , dashed ) ;
dot(Label( "$\left(i,\frac{1}{i}\right)$" , (1,1) , NE )) ;
dot(Label( "$\left(i+1,\frac{1}{i+1}\right)$" , (2,1/2) , NE )) ;