// annotated secant in terms of h
import graph;
size(8cm);
real h = 1;
real f(real x){return (0.1*x^3 + 0.1*x^2 + 0.15*x + 0.5);}
pair P,Q,R;
P = (1,f(1));
Q = (1+h,f(1+h));
R = (1+h,f(1));
real m = ((f(1+h)-f(1))/h);
real g(real x){return (m*x + (f(1)-m));}
xlimits( -0.25, 2.25);
draw(graph(f,-0.25,2.25),black+1bp);
draw(graph(g,0,2.25),blue+0.75bp);
xaxis(Label("$x$",position=EndPoint, align=SE),NoTicks, Arrow);
yaxis(Label("$y$",position=EndPoint, align=NW),NoTicks, Arrow);
dot(P);
dot(Q);
label("$P$",P,SE);
label("$(a,f(a))$",P,NW);
label("$Q$",Q,SE);
label("$(a+h,f(a+h))$",Q,NW);
draw(P--R--Q);
label("$h$",(P+R)/2,0.5S);
label("$f(a+h)-f(a)$",(Q+R)/2,E);
// end