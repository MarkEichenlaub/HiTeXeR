unitsize(0.6 cm);

int i;

for (i = 1; i <= 4; ++i) {
  draw(Circle((0,0),i), gray(0.7));
}

for (i = 0; i <= 11; ++i) {
  draw(4.2*dir(15*i)--4.2*dir(15*i + 180), gray(0.7));
}

draw((-4.5,0)--(4.5,0), Arrows(6));
draw((0,-4.5)--(0,4.5), Arrows(6));
draw(4.2*dir(25)--4.2*dir(25 + 180), green + linewidth(2*bp));
draw(shift(1.5*dir(25 + 90))*(4.2*dir(25)--4.2*dir(25 + 180)), linewidth(2*bp));