size(5cm);
draw((0,4)--(0,0),black+1bp);
draw((0,0)--(2,0),gray+1bp);
draw((-1,6)--(2,0),black+1bp+dashed,Arrow(2mm));
fill(shift(-1,6)*scale(0.5)*unitcircle,yellow);
label("Sun",(0,6));
label("$	heta$",(1.5,0.25));
label("$s$",(1,-0.5),gray);
label("$h$", (0,2), W);