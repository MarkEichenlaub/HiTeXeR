import graph;
real xsize=200, ysize=140;
picture pic3;
size(pic3,xsize,ysize,IgnoreAspect);
real h(real x){return 2;}
xlimits(pic3,  -2, 2);
ylimits(pic3, -4,4);
draw(pic3, graph(h,-2, 2),black+1bp);
xaxis(pic3, Label("$x$",position=EndPoint, align=SE),Ticks("%"), Arrow);
yaxis(pic3, Label("$y$",position=EndPoint, align=NW),Ticks("%"), Arrow);
labelx(pic3, 1,2S);
labely(pic3, 1,2W);
label(pic3, "\scriptsize $y = f''(x)=2$", (1,3));
real margin = 5mm;
add(pic3.fit(),(0,0), 12*margin*S);