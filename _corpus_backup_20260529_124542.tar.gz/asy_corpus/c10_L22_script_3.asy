import slopefield;
real func(real x, real y) {return y/x;}
 add(slopefield(func,(-3,-3),(-0.01,3),5,Arrow));
 add(slopefield(func,(0.01,-3),(3,3),5,Arrow));
xaxis(Label("$x$",position=EndPoint, align=SE), Arrow);
yaxis(Label("$y$",position=EndPoint, align=NW), Arrow);
draw(curve((-1,-1),func,(-3,-3),(3,3)),red);
draw(curve((-1,-2),func,(-3,-3),(3,3)),green);
draw(curve((-1,-3),func,(-3,-3),(3,3)),blue);
draw(curve((-1,.25),func,(-3,-3),(3,3)),purple);
draw(curve((-1,1.5),func,(-3,-3),(3,3)),orange);
draw(curve((-1,2.5),func,(-3,-3),(3,3)),yellow);