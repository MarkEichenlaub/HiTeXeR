// geometric reason for inverse function
import graph;
size(8cm);
real f(real x){return (exp(x));}
real g(real x){return (log(x));}
real h(real x){return (x);}
xlimits( -1, 8);
ylimits( -1.5, 8);
draw(graph(f,-1,2),red+1bp);
draw(graph(g,0.5,7),blue+1bp);
draw(graph(h,-1,6),black+dashed);
xaxis(Label("$x$",position=EndPoint, align=SE),Ticks("%"), Arrow);
yaxis(Label("$y$",position=EndPoint, align=NW),Ticks("%"), Arrow);
labelx(1,2S);
labely(1,2W);
pair P,Q,R,S;
P = (1.5, g(1.5));
Q = (g(1.5),1.5);
real m = 1.5;
R = (1,m);
S = (m,1);
draw((Q-R)--Q--(Q+2*R),black+0.75bp);
draw((P-S)--P--(P+2*S),black+0.75bp);
dot(P); dot(Q);
// end