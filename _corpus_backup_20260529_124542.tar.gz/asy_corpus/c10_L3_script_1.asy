size(125);
real ticklen=3;
real tickspace=2;

real ticklength=0.1cm;
real axisarrowsize=0.14cm;
pen axispen=black+1.3bp;
real vectorarrowsize=0.2cm;
real tickdown=-0.5;
real tickdownlength=-0.15inch;
real tickdownbase=0.3;
real wholetickdown=tickdown;
void rr_cartesian_axes(real xleft, real xright, real ybottom, real ytop, real xstep=1, real ystep=1, bool useticks=false, bool complexplane=false, bool usegrid=true) {
    import graph;
    real i;
    if(complexplane) {
        label("$	extnormal{Re}$",(xright,0),SE);
        label("$	extnormal{Im}$",(0,ytop),NW);
    } else {
        label("$x$",(xright+0.4,-0.5));
        label("$y$",(-0.5,ytop+0.2));   
    }

    ylimits(ybottom,ytop);
    xlimits( xleft, xright);
    real[] TicksArrx,TicksArry;

    for(i=xleft+xstep; i<xright; i+=xstep) {
        if(abs(i) >0.1) {
            TicksArrx.push(i);
        }
    }
    for(i=ybottom+ystep; i<ytop; i+=ystep) {
        if(abs(i) >0.1) {
            TicksArry.push(i);
        }
    }

    if(usegrid) {
        xaxis(BottomTop(extend=false), Ticks("%", TicksArrx ,pTick=gray(0.72),extend=true),p=invisible);//,above=true);
        yaxis(LeftRight(extend=false),Ticks("%", TicksArry ,pTick=gray(0.72),extend=true), p=invisible);//,Arrows);
    }
    if(useticks) {
        xequals(0, ymin=ybottom, ymax=ytop, p=axispen, Ticks("%",TicksArry ,  pTick=black+0.8bp,Size=ticklength), above=true,  Arrows(size=axisarrowsize));
        yequals(0, xmin=xleft, xmax=xright, p=axispen, Ticks("%",TicksArrx ,  pTick=black+0.8bp,Size=ticklength), above=true,  Arrows(size=axisarrowsize));

    } else {
        xequals(0, ymin=ybottom, ymax=ytop, p=axispen,  above=true,  Arrows(size=axisarrowsize));
        yequals(0, xmin=xleft, xmax=xright, p=axispen,  above=true,  Arrows(size=axisarrowsize));
    }
};
rr_cartesian_axes(-5,5,-1,1.5);
real f(real x) {return sin(x)/x;}
draw(graph(f,-5,-0.01,operator ..), red );
draw(graph(f,0.1,5, operator ..), red)