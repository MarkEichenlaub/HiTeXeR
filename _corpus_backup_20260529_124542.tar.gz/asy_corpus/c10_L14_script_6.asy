// low quality picture of rotation around y-axis.
import graph;
size(7cm);
real a,b;
a=1; b=3;
real f(real x){return ((1/3)*(4-x)^3 - (3/2)*(4-x)^2 + 2*(4-x) + 2);}
real g(real x){return (f(-1*x));}
path rc = yscale(.2)*xscale(b)*unitcircle;
path lc = yscale(.2)*xscale(a)*unitcircle;
path p = buildcycle(graph(g,-b,-a),(-a,g(-a))--(a,f(a)),graph(f,a,b),(b,f(b))--(b,0)--(-b,0)--(-b,g(-b)));
fill(p,rgb(.8,.8,.8));
fill(shift(0,f(a))*lc,white);
fill(rc,rgb(.8,.8,.8));
draw(shift(0,f(a))*lc,black+0.75bp);
draw(shift(0,f(b))*rc,black+0.75bp);
draw(rc,black+0.75bp);
draw(graph(f,a,b),blue+1.5bp);
draw(graph(g,-1*b,-1*a),black+1.5bp);
xaxis(Label("$x$",position=EndPoint, align=SE),dashed,Arrow);
yaxis(Label("$y$",position=EndPoint, align=NW),Arrow);
draw((0,-1)--(0,22/3), dotted);
draw((0,3.5)--(0,4));
draw((-3,0)--(3,0), dotted);

draw((a,0)--(a,f(a)),black+0.75bp+dashed);
draw((b,0)--(b,f(b)),black+0.75bp);
draw((-a,0)--(-a,g(-a)),black+0.75bp+dashed);
draw((-b,0)--(-b,g(-b)),black+0.75bp);
draw(shift(0,0)*lc,black+0.75bp+dashed);

label("$a$",(a,0),1.5*S);
label("$-a$",(-a,0),1.5*S);

label("$b$",(b,0),S);
label("$-b$",(-b,0),S);