// unit circle
size(3cm);
real f(real t) {return(cos(t));}
real g(real t) {return(sin(t));}
draw(graph(f,g,0,pi,Spline),red);
draw(graph(f,g,pi,3*pi/2,Spline),blue+1bp);
xaxis(Label("$x$",position=EndPoint, align=SE),Arrow);
yaxis(Label("$y$",position=EndPoint, align=NW),Arrow);
//