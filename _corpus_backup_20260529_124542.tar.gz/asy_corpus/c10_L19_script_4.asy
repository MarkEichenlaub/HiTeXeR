// spiral
size(6cm);
real f(real t) {return(t*cos(t));}
real g(real t) {return(t*sin(t));}
draw(graph(f,g,0,17*pi/6,Spline),blue+1bp);
xaxis(Label("$x$",position=EndPoint, align=SE),Arrow);
yaxis(Label("$y$",position=EndPoint, align=NW),Arrow);
//