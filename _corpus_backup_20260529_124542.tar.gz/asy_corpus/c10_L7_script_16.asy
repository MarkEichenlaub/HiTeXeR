// ladder problem with more stuff
import graph;
size(6cm);
real a,b;
a = 5; b = 8;
draw((0,-20)--(0,0)--(20,0),black+0.75bp);
draw((a,-20)--(a,-b)--(20,-b),black+0.75bp);
draw("$a$",(0,-18)--(a,-18),Arrows(2mm)); 
draw("$b$",(18,0)--(18,-b),Arrows(2mm)); 
pair C = (a,-b);
real m;
m = .8;
draw((0,-a*m-b)--C--((b/m)+a,0),blue+1bp);
label("$	heta$",C,4ENE);
draw((0,-a*m-b)--(a,-a*m-b),black+1bp+dashed);
draw(((b/m)+a,0)--((b/m)+a,-b),black+1bp+dashed);
label("$m$",((0,-a*m-b)+C)/2,NW);
label("$n$",((b/m+a,0)+C)/2,NW);
// end