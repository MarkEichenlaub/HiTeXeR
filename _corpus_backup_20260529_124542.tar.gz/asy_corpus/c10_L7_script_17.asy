size(8cm);
real a,b,d;
a = 3; b = 5; d = 9;
pair A,B;
A = (0,a);
B = (d,-b);
fill((0,0)--(0,1.2*a)--(1.2*d,1.2*a)--(1.2*d,0)--cycle,.8*white);
fill((0,0)--(0,-1.2*b)--(1.2*d,-1.2*b)--(1.2*d,0)--cycle,.9*white);
draw((0,1.2*a)--(0,-1.2*b),black+0.75bp);
draw((0,0)--(1.2*d,0),black+0.75bp);
pair C; 
C = (6,0);
draw(A--C--B,black+1bp+dotted);
draw((6,-2)--(6,2),black+0.75bp+dashed);
dot(A); dot(C); dot(B);
label("$A$",A,W);
label("$B$",B,E);
label("$X$",C,NE);
label("Speed of light $c_1$",(1.2*d,1.2*a),SW);
label("Speed of light $c_2$",(0,-1.2*b),NE);
label("$	heta_1$",C,N+NW);
label("$	heta_2$",C,2SE+4S);