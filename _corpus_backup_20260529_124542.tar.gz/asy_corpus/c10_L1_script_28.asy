size(10cm,0);

real s(real x) {return (sin(x));}

draw(graph(s,-7,7),red);

xaxis(Label("$x$",position=EndPoint,align=NE),Ticks("%",Step=1),Arrow(2mm));

yaxis(Label("$y$",position=EndPoint,align=NE),Ticks("%",Step=1),Arrow(2mm));