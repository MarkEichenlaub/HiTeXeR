//initializing variable types
unitsize(.5cm);
real a,b,h;
int i,n,k;
path rect, bdry;

// function
real f(real x){return ((1/3)*x^3 - (3/2)*x^2 + 2*x);}
//anitderivative
real F(real x){return ((1/12)*x^4 - (1/2)*x^3 + x^2);}
// limits of integration
a = 1; b = 3;
// width 1/n
n = 3; 
// index of rectangle under consideration, 0 through (b-a)*n-1, inclusive
k=4;

//area under curve
bdry= (b,f(b))--(b,0)--(a,0)--(a,f(a))--graph(f,a,b)--cycle;
fill(bdry,lightgray);

//labels
label("$f(x)$",(a,f(a)),N);
label("$a$",(a,0),S);
label("$b$",(b,0),S);

//partition
for (i=0; i<((b-a)*n); ++i) {
  //mean value theorem
  h = (F(a+(i+1)/n)-F(a+i/n))*n;
  rect = (a+i/n,0)--(a+i/n,h)--(a+(i+1)/n,h)--(a+(i+1)/n,0)--cycle;
  draw(rect,mediumgray+0.75bp);
  if (i == k) 
  	{
	//rectangle fill and height label
	fill(rect,gray(0.75));
    draw("$f(c_"+ (string) k + ")$",brace((a+k/n,0),(a+k/n,h)),W,blue);
	//rectangle widths    
      //leftmost
      if (k==0) 
      	{
        draw("$x_"+ (string) (k+1) + "-a$",shift((0,-.02))*brace((a+(k+1)/n,0),(a+k/n,0)),S,blue);
        }
      //rightmost
      else if (k == (b-a)*n-1) 
      	{
        draw("$b-x_"+ (string) k + "$",shift((0,-.02))*brace((a+(k+1)/n,0),(a+k/n,0)),S,blue);
        }
      //inner
      else 
      	{
        draw("$x_"+ (string) (k+1) + "-x_"+ (string) k + "$",shift((0,-.02))*brace((a+(k+1)/n,0),(a+k/n,0)),S,blue);
        }
     }
}

//function graph, axes 
draw(graph(f,a-0.5,b+0.25),black+1bp);
xaxis(Label("$x$",position=EndPoint, align=SE),Arrow,above=true);
yaxis(Label("$y$",position=EndPoint, align=NW),Arrow);

//end