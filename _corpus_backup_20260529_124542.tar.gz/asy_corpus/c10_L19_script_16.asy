pair A,B,C;
real r, theta, x, y;

r = 2;
theta = pi/3;
x = r*cos(theta);
y = r*sin(theta);

A = origin;
B = (x,0);
C = (x,y);

draw(A--B,Arrow(7));
draw(B--C,Arrow(7));
draw(A--C,Arrow(7));
//draw(rightanglemark(C,B,A,5));

label("$u'(t)$", A--B, S);
label("$v'(t)$", B--C, E);
label(Label("$\sqrt{(u'(t))^2 + (v'(t))^2}$",Rotate(C-A)), A--C, NW);