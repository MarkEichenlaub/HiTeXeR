unitsize(0.8 cm);

draw((-3.5,0)--(3.5,0),red);
draw((0,-3.5)--(0,3.5),red);
draw(3.5*dir(30)--(-3.5*dir(30)),red);
draw(3.5*dir(60)--(-3.5*dir(60)),red);
draw(3.5*dir(120)--(-3.5*dir(120)),red);
draw(3.5*dir(150)--(-3.5*dir(150)),red);
draw(Circle((0,0),1),blue);
draw(Circle((0,0),2),blue);
draw(Circle((0,0),3),blue);