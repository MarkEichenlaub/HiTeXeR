unitsize(0.3 cm);

draw((0,0)--(15,10)--(15,0));
draw((-2,0)--(17,0));

label("$10$", (15,5), E);
//label("$15$", (15/2,5), NW);
label("$x$", (15/2,0), S);
label("$	heta$", (3,1));

dot("plane", (15,10), NE);
dot("camera", (0,0), S);