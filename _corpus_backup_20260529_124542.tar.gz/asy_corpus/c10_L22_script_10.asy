import slopefield;
import graph;

pair P,Q;
 P=(0,1);
 Q=(0.3,1);
real b=1.3;
real func(real x, real y) {return -x/y;}
 add(slopefield(func,(-b,-b),(-0.1,b),5,gray(0.5),Arrow));
 add(slopefield(func,(0.1,-b),(b,b),5,gray(0.5),Arrow));

draw(arc((0,0), 1, 0, 180), blue); 
draw((-b, 1)--(b,1));
dot((string) P,P, NW);
dot((string) Q,Q,NE);

xaxis(Label("$x$",position=EndPoint, align=SE), Arrow);
yaxis(Label("$y$",position=EndPoint, align=NW), Arrow);