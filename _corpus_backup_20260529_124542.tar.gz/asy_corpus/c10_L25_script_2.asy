size(300,0);
real f(real t) {return((10*pi*cos(pi*t/2)-(5/3)*pi*sin(pi*t/6))/(4*pi));}
draw(graph(f,0,8.5),red+1bp);
xaxis("$t$"); yaxis("$y$",-3,3.7);
xtick("$2.017$", 2.017);
xtick("$4.018$", 4.018);
xtick("$5.965$", 5.965);
xtick("$8$", 8);
ytick("$12\pi$", 3);
ytick("$8\pi$", 2);
ytick("$4\pi$", 1);
ytick("$-4\pi$", -1);
ytick("$-8\pi$", -2);
ytick("$-12\pi$", -3);

real g(real t) {return f(2.017);}
real h(real t) {return f(5.965);}
draw(graph(g,0,8),1bp+dashed);
draw(graph(h,0,8),1bp+dashed);

label("$y = g'(t)$", (4,3.6));