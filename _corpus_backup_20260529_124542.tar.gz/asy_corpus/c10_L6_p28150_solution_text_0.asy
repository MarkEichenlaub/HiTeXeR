size( 200 ) ;

real quartic( real x ){ return x^4 ; }

draw( (-1.5,0)--(1.5,0) , arrow=Arrows ) ;
draw( (0,-0.5)--(0,2) , arrow=Arrows ) ;
draw( graph( quartic , -2^(1/4) , 2^(1/4) ) , arrow=Arrows , blue ) ;