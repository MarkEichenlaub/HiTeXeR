size(8 cm);
//variables
real d, s; 
d = 40; // angle in degrees
s = 0.24; //scale of angle mark
pair xy, O, P;
xy = dir(d); // point on unit circle 
O = origin;
P=(xy.x,0); //projection to x-axis

//axes
draw((-1.5,0)--(1.5,0),Arrow);
draw((0,-1.5)--(0,1.5),Arrow);

//drawing
draw(circle((0,0),1),linewidth(1)); //unit circle
dot (xy);
draw (O -- xy); //origin to point on unit circle
draw(arc(O, s, 0, d), blue); 
draw(rightanglemark(O,P,xy, 5), blue); //angle marks 
draw (P--xy); //altitude

//labels
label("$(\cos 	heta, \sin 	heta)$", xy, NE); // point on unit circle 
label("$\cos 	heta$", (O+P)/2, S); // base
label("$\sin 	heta$", (xy+P)/2, W); // height
label("$1$", (O+xy)/2, NW); // hypotenuse
label ("$	heta$",s*dir(d/4), NE); // angle