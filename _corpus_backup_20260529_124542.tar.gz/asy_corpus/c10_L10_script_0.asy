// intro tangent pic
import graph;
size(7cm);
real f(real x){return ((1/3)*x^3 - (3/2)*x^2 + 2*x + 2);}
real g(real x){return (2*x-(5/2));}
xlimits( -0.5, 3.5);
ylimits( -0.1, 4);
draw(graph(f,-0.5,3.5),black+1bp);
draw(graph(g,2,4),blue+1bp);
xaxis(Label("$x$",position=EndPoint, align=SE),Ticks("%"), Arrow);
yaxis(Label("$y$",position=EndPoint, align=NW),Ticks("%"), Arrow);
dot((3,f(3)));
// end