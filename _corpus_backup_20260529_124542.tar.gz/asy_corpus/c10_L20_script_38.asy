// area common to two cardioids
import graph;
size(5cm);
real pi=3.14159;
real f(real t) {return (2*(1+cos(t)));}
real g(real t) {return (2*(1-cos(t)));}
fill(buildcycle(polargraph(g,radians(-90),radians(90)),polargraph(f,radians(90),radians(270))),rgb(.8,.8,.8));
draw(polargraph(f,0,2*pi),blue+1bp);
draw(polargraph(g,0,2*pi),red+1bp);
xaxis(Arrow(2mm));
yaxis(Arrow(2mm));