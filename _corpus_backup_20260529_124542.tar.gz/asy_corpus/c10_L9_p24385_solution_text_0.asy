size( 150 ) ;
pair bottom = (-20,0) ; 
pair junction = (0,0) ;
pair top = (0,15) ;
draw( bottom--junction--top--cycle );
draw(rightanglemark(bottom,junction,top,30));
label( "$x$" , bottom--junction , S ) ;
label( "$y$" , top--junction , E ) ;
label( "$25$" , bottom--top , NW ) ;