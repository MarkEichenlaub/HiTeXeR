size(10cm);
real h(real x){return (6(x - .5));}
xlimits(-1, 2);
ylimits( -1,2);
draw(graph(h,-0.25,1.25),black+1bp);
xaxis(Label("$x$",position=EndPoint, align=SE),Ticks("%"), Arrow);
yaxis(Label("$y$",position=EndPoint, align=NW),Ticks("%"), Arrow);
labelx(1,2S);
labely(1,2W);
label("\scriptsize $y = g''(x)$", (2.2,1));