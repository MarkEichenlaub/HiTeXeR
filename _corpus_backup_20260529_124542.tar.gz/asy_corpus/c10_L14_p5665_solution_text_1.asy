unitsize(1.5 cm);

real f(real x) {
  return (x^3/4);
}

fill(graph(f,0,2)--(0,2)--cycle,gray(0.7));

draw((0,0)--(2,0));
draw((0,0)--(0,2));
draw((0,2)--(2,f(2)));
draw(graph(f,0,2));
draw((1.2,f(1.2))--(1.2,f(2)),dashed);

dot("$(x,x^3)$", (1.2,f(1.2)), SE);
dot("$(x,8)$", (1.2,f(2)), N);