unitsize(3 cm);

draw(Circle((0,0),1));
draw((0,0)--(1,0));
draw((0,0)--(Cos(45), Sin(45)));
label("$	heta$", (0,0) + (0.2,0.1));
dot((0,0));
label("p", (1,0) + (0.05,0));
dot((1,0));
label("q", (Cos(45), Sin(45)) + (0.05,0.05));
dot((Cos(45), Sin(45)));

label("$r$", (0.5,0) +(0,-0.1));