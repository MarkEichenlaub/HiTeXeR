unitsize (5 cm);

real g, t, theta, v;
path arch;

g = 1;
v = 1;

theta = 50;
arch = (0,0);

for (t = 0; t <= 2*v*Sin(theta)/g; t = t + 0.01) {
  arch = arch--(v*t*Cos(theta),v*t*Sin(theta) - 1/2*g*t^2);
}

draw(arch,red,Arrow(6));
draw((-0.2,0)--(1.2,0));

label("$	heta$", (0.1,0.05));

dot((0,0));