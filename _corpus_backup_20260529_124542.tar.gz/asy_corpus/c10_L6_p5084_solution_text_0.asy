import graph;
size(6cm);
real f(real x){return (x);}
draw(graph(f,0,3),black+1bp);
xaxis(Label("$t$",position=EndPoint, align=SE), Arrow);
yaxis(Label("$y$",position=EndPoint, align=NW), Arrow);