// y = x^(1/3)
import graph;
size(7cm);
real f(real x){return (x**(1/3));}
real g(real x){return (-(-x)**(1/3));}
xlimits(-2.5,2.5);
draw(graph(f,0,2.5),black+0.75bp);
draw(graph(g,-2.5,0),black+0.75bp);
xaxis(Label("$x$",position=EndPoint, align=SE),Ticks("%"), Arrow);
yaxis(Label("$y$",position=EndPoint, align=NW), Arrow);
draw((0,-1.5)--(0,1.5),blue+1bp);
// end