// more general lower Darboux sum
import graph;
unitsize(.4cm);
real f(real x){return ((1/3)*x^3 - (3/2)*x^2 + 2*x);}
real a,b;
a = 1; b = 3;
int i,n;
n = 5;
real p[] = {1,1.25,1.6,2.3,2.7,3};
path bdry=(b,f(b))--(b,0)--(a,0)--(a,f(a));
fill(buildcycle(bdry,graph(f,a,b)),.8white);
draw ((a,0)--(a,f(a)),black+0.75bp);
draw ((b,0)--(b,f(b)),black+0.75bp);
path rect;
//draw(graph(f,0.5,3.25),black+1bp);
draw(graph(f,0.5,4.0),black+1bp);
for (i=0; i<n; ++i) {
  if (i<2) {
    rect=(p[i],0)--(p[i],f(p[i+1]))--(p[i+1],f(p[i+1]))--(p[i+1],0)--cycle;
  } else if (i<3) {
    rect=(p[i],0)--(p[i],f(2))--(p[i+1],f(2))--(p[i+1],0)--cycle;
  } else {
    rect=(p[i],0)--(p[i],f(p[i]))--(p[i+1],f(p[i]))--(p[i+1],0)--cycle;
  }
  fill(rect,.6white);
  draw(rect,black+0.75bp);
}
draw(graph(f,0.5,3.25),black+0.75bp+dotted);
xaxis(Label("$x$",position=EndPoint, align=SE),Arrow);
yaxis(Label("$y$",position=EndPoint, align=NW),Arrow);
//label("$a=x_0$",(1,0),S);
label("$a=x_0$",(1,0),S+0.5W);
//label("$b=x_5$",(3,0),S);
label("$x_5=b$",(3,0),0.6S+0.5E);
label("$x_1$", (p[1],0), S);
label("$x_2$", (p[2],0), S);
label("$x_3$", (p[3],0), S);
label("$x_4$", (p[4],0), S);
// end