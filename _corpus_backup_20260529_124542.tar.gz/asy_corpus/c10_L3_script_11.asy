// graph of (x^2-1)/(x-1)

size(7cm);

xlimits( -3, 3);

ylimits( -3, 3);

real f(real x){return (x+1);}

draw(graph(f,-3,3),Arrows(.15cm));

//return the nubmer as string iff >0
string tlab (real x){
  if (x > 0) return format("%.4g",x);
  else return "";
}

xaxis(Label("$x$",position=EndPoint, align=SE),Ticks(tlab), Arrow);

yaxis(Label("$y$",position=EndPoint, align=NW),Ticks(tlab), Arrow);

dot((0,0));

unfill(shift(1,2)*scale(.1)*unitcircle);

draw(shift(1,2)*scale(.1)*unitcircle);

// end