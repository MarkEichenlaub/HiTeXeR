import graph;
size(7.0cm);
real f(real x){return (sqrt(9-x^2));}
real a,b;
a = 0; b = 1;
path bdry=(a,f(a))--(a,0)--(b,0)--(b,f(b));
fill(buildcycle(bdry,graph(f,a,b)),.7*white);
draw(graph(f,-3,3),black+1bp);
draw(bdry,black+1bp+dashed);
draw((0,0)--(b,f(b)),black+1bp+dashed);
draw((b,f(b))--(a,f(b)), black+1bp+dashed);
draw(rightanglemark((0,0),(a,f(b)),(b,f(b)),5));
xaxis(Label("$x$",position=EndPoint, align=SE),Arrow);
yaxis(Label("$y$",position=EndPoint, align=NW),Arrow);
label("$1$",(1,0),S);
label("$	heta$", (.15, .6), N);
label("$-3$",(-3,0),S); 
label("$3$",(3,0),S);