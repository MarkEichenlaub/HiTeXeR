size(200);

pair A = (0,0) ;
pair B = (4,0) ;
pair C = (4,3) ;

draw( rightanglemark(C,B,A,10) ) ;
draw( A--B--C--cycle ) ;
label( "$1$" , A--C , NW ) ;
label( "$x$" , B--C , E ) ;
label( "$\sqrt{1-x^2}$" , A--B , S ) ;
label( "$	heta$" , A , 5dir(15) ) ;