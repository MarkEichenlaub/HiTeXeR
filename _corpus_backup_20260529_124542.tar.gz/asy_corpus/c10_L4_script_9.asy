// y = |x|
import graph;
size(7cm);
real h = 1;
real f(real x){return (abs(x));}
xlimits( -2.5,2.5);
draw(graph(f,-2.5,2.5),black+1bp);
xaxis(Label("$x$",position=EndPoint, align=SE),Ticks("%"), Arrow);
yaxis(Label("$y$",position=EndPoint, align=NW),Ticks("%"), Arrow);
// end