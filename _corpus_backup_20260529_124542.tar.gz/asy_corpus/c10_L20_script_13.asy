real i, a, n, t;
pair P, O;
a=2; //fixed positive
n=12; //number of points plotted as theta goes from 0 to pi
O=(0,0);
real r(real x){return a*Cos(x);} //polar function

for(i=0; i<=n/2; i=i+1) {
t=180*i/n; //theta in degrees
P=r(t)* dir(t); //point in rectangular coordinates
draw(O--P);
dot(P, blue);
}

xaxis(xmin=-0.5,xmax=2.5,Arrow(2mm));
yaxis(ymin=-1.5,ymax=1.5,Arrow(2mm));