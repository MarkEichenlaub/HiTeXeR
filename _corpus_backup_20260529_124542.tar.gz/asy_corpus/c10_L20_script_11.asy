// r = a cos(theta)
real a = 2;
dot ((0,0), blue);
dot ("$(a,0)$", (a,0), N, red);
xaxis(xmin=-0.5,xmax=2.5,Arrow(2mm));
yaxis(ymin=-1.5,ymax=1.5,Arrow(2mm));