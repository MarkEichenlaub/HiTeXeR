size(170);
pair A,B,C;
A =(-sqrt(3)/2, -1/2);
B = (0,0);
C = (1,0);

draw(circle((0,0),1),linewidth(1));
draw((-1.5,0)--(1.5,0),Arrow);
draw((0,-1.5)--(0,1.5),Arrow);
//dot((1,0));
//dot((0,1));
//dot((-1,0));
//dot((0,-1));

label("$y$",(0,1.4),E);
label("$x$",(1.4,0),S);
//This way makes a misleading vertical blue line.
//draw(anglemark((1,0),B,A),blue);
//draw(anglemark(C,B,(0,1)),blue);
draw(arc((0,0), 0.24, 0, 180), blue);
label("$\pi$", (0,0.3), E,blue);
//draw(anglemark((-1,0), B, A), red);
draw(arc((0,0), 0.24, 180, degrees(A)), red);
label("$t$", (-0.25,0), SW, red);

draw(B--A);
dot(A);
label("$(-x,-y)$", A, SW);