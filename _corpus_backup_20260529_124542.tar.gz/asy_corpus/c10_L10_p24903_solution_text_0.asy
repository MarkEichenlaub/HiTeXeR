size( 200 ) ; 
 draw( (-1.5,0)--(4.5,0) , arrow=Arrows ) ;
 draw( (0,-4.5)--(0,2.5) , arrow=Arrows ) ;
 fill( (0,0)--(0,-3)--(4,1)--(4,0)--cycle , lightblue ) ;
 draw( (-1,-4)--(4,1) , blue ) ;
 label( "$-3$" , (0,0)--(0,-3) , W ) ;
 label( "$b-3$" , (4,1)--(4,0) , E ) ;
 draw( (0,1)--(4,1) , dotted ) ; label( "$b$" , (0,1)--(4,1) , N ) ;