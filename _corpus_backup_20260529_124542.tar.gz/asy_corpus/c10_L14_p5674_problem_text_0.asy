import graph;
size(7cm,0);
real f(real x) {return (2*x - 3*x^3);}
real c = 4/9;
real d1,d2;
d1 = (-1+sqrt(3))/3;
d2 = 2/3;
fill(buildcycle(graph(f,0,d1),(d1,c)--(0,c)--(0,0)),rgb(.8,.8,.8));
fill(buildcycle((d2,c)--(d1,c),graph(f,d1,d2)),rgb(.8,.8,.8));
draw(graph(f,0,sqrt(2/3)),black+1bp);
draw((0,c)--(sqrt(2/3),c),black+1bp);
xaxis(Label("$x$",position=EndPoint, align=SE),Arrow);
yaxis(Label("$y$",position=EndPoint, align=NW),Arrow);
label("$y = c$",(0,c),W);
label("$y = 2x - 3x^3$",(sqrt(2/3),0),NE);