unitsize(4 cm);

real func (real x) {
  real y;
	
  if (x >= 0 && x <= 0.4) {y = 0.5;}
	if (x >= 0.4 && x <= 0.5) {y = 50*(x - 0.4)^2 + 0.5;}
	if (x >= 0.5 && x <= 1) {y = 1;}
	
	return(y);
}

fill(graph(func,0,1)--(1,0)--(0,0)--cycle,gray(0.7));
draw(graph(func,0,1),red + linewidth(2*bp));
draw((-0.2,0)--(1.2,0),Arrow(6));
draw((0,-0.2)--(0,1.2),Arrow(6));
draw((1,-0.05)--(1,0.05));
draw((-0.05,1)--(0.05,1));
draw((1/2,-0.05)--(1/2,0.05));
draw((-0.05,1/2)--(0.05,1/2));
draw((0,1)--(1/2,1),dashed);
draw((1/2,0)--(1/2,1),dashed);
draw((1,0)--(1,1),dashed);
draw((0.4,0.5)--(1,0.5),dashed);

label("$x$", (1.2,0), E);
label("$y$", (0,1.2), N);
label("$1$", (1,-0.05), S);
label("$1$", (-0.05,1), W);
label("$\frac{1}{2}$", (1/2,-0.05), S);
label("$\frac{1}{2}$", (-0.05,1/2), W);
label("$y = f(x)$", (0.75,1.1),red);