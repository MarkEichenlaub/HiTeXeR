size(200);
draw(circle((0,0),1),linewidth(1));

label("$	heta$ radians",(0.1,0),NE);
draw((0,0)--(1/2, sqrt(3)/2));
label("$1$",(0,0)--(1/2,sqrt(3)/2), NW);
draw((0,0)--(1,0));
label("$1$",(0,0)--(1,0),S);
dot((1/2, sqrt(3)/2));
draw(Arc((0,0),1,0,60),red);
label("$	heta$ units long", (sqrt(3)/2, 1/2), NE);