size(6cm);
real pi=3.14159;
import graph;
draw(unitcircle,black+2bp);
real f(real t) {return(cos(t) + t*sin(t));}
real g(real t) {return(sin(t) - t*cos(t));}
draw(graph(f,g,0,2*pi),blue+1bp);
real v=3*pi/4;
draw((cos(v),sin(v))--(f(v),g(v)),red+1.5bp);
v = 13*pi/12;
draw((cos(v),sin(v))--(f(v),g(v)),red+1.5bp);
v = 3*pi/2;
draw((cos(v),sin(v))--(f(v),g(v)),red+1.5bp);
xaxis(Label("$x$",position=EndPoint, align=SE),Arrow);
yaxis(Label("$y$",position=EndPoint, align=NW),Arrow);