unitsize(1.5 cm);

real r, t, x, y;
path foo = (2,0);

for (t = 0; t <= 2*pi; t = t + 0.01) {
  r = 2 + 2*sqrt(2)*sin(t);
  x = r*cos(t);
  y = r*sin(t);
  foo = foo--(x,y);
}

draw(foo,red);
draw((-3,0)--(3,0));
draw((0,-1)--(0,5.5));

draw((-3,2 + 2*sqrt(2))--(3,2 + 2*sqrt(2)), blue);
draw((-3,2*sqrt(2) - 2)--(3,2*sqrt(2) - 2), blue);
draw((-3,-sqrt(2)/4)--(3,-sqrt(2)/4), blue);

dot("$(0,2 + 2 \sqrt{2})$", (0,2 + 2*sqrt(2)), NE);
dot("$(0,2 \sqrt{2} - 2)$", (0,2*sqrt(2) - 2), NE);
dot("$(-\frac{\sqrt{14}}{4},-\frac{\sqrt{2}}{4})$", (-sqrt(14)/4,-sqrt(2)/4), S);
dot("$(\frac{\sqrt{14}}{4},-\frac{\sqrt{2}}{4})$", (sqrt(14)/4,-sqrt(2)/4), S);