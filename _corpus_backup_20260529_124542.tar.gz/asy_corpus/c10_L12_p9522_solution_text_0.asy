pair A,B,C,D;
A = (0,0);
B = (1,0);
C = (1,0.7);
draw(A--B--C--A);
label("$	heta$", (0.18,0.06));
label("$\sqrt{n}$", (0.5,-0.1));
label("$x$", (0.5, 0.45));
label("$\sqrt{x^2-n}$", (1.3,0.35));