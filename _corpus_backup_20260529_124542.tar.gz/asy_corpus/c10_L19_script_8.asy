// spiral squish
size(6cm);
real f(real t) {return(t*cos(t));}
real g(real t) {return(sin(t));}
draw(graph(f,g,0,3*pi/2,Spline),red);
draw(graph(f,g,3*pi/2,2*pi,Spline),blue+1bp);
xaxis(Label("$x$",position=EndPoint, align=SE),Arrow);
yaxis(Label("$y$",position=EndPoint, align=NW),Arrow);
//