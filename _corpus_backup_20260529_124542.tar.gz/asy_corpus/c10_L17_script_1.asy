size(200);
//initializing variable types
int n;

// function
real f(real x){return (factorial(n)/(n^n));}

//plot points
for (n=1; n<16; ++n) {
  dot((n, f(n)));
  }

//axes 
xaxis(Label("$n$",position=EndPoint, align=SE),above=true);
yaxis();
//end