import graph;
ticks stdticks=Ticks("%",Size=2,n=1,begin=false,end=false);
size(7cm);
real f(real x){return (x^3 - 3*x + 1);}
xlimits( -1,3);
//draw(graph(f,0,2),black+1bp);
dot((0,1));
dot((1,-1));
dot((2,3));
xaxis(Label("$x$",position=EndPoint, align=SE), stdticks,Arrow);
yaxis(Label("$y$",position=EndPoint, align=NW), stdticks,Arrow);