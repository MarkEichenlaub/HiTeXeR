unitsize(1 cm);

pair A, B, C, O;

A = (2,3);
B = (1,4);
C = (-2,2);
O = (0,0);

draw(A--B--C--cycle);
draw(O--A,dashed);
draw(O--B,dashed);
draw(O--C,dashed);

draw((-4,0)--(4,0),Arrows(8));
draw((0,-1)--(0,4),Arrows(8));

label("$A = (r_1,	heta_1)$", A, E);
label("$B = (r_2,	heta_2)$", B, N);
label("$C = (r_3,	heta_3)$", C, W);
label("$O$", (0,0), SE);