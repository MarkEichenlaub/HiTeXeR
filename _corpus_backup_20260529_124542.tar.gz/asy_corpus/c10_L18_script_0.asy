import graph;
size(5cm, IgnoreAspect);

real f(real x) {return x^2;}
real g(real x) {return (x-2)^2;}

draw(graph(f,-2,2,operator ..),red);
draw(graph(g,0,4,operator ..),blue);

xlimits(-4,4);
ylimits(-4,8);

xaxis("$x$",RightTicks(NoZero));
yaxis("$y$", LeftTicks(NoZero));
label("\footnotesize $f(x)=x^2$",(1, 7), 0.5E, red);
label("\footnotesize $f(x)=(x-2)^2$",(1, 6), 0.5E, blue);