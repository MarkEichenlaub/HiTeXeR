// graph interpretation example
import graph;
size(10cm);
pair[] P;
real f(real x){return (4*((x-5)/4-((x-5)/4)^3) + 3);}
real g(real x){return (f(8.5));}
real h(real x){return (-(x-11.5)^3+f(8.5)-1);}
xlimits(0, 13);
draw(graph(f,1,8.5),black+0.75bp);
draw(graph(g,8.5,10.5),black+0.75bp);
draw(graph(h,10.5,12.5),black+0.75bp);
xaxis(Label("$x$",position=EndPoint, align=SE),Arrow);
yaxis(Label("$y$",position=EndPoint, align=NW),Arrow);
dot((1,f(1))); dot((12.5,h(12.5)));
real r = 1/sqrt(3);
real a[];
a[1] = 1.5;
a[2] = 5-4*r;
a[3] = 5;
a[4] = 6.25;
a[5] = 5+4*r;
a[6] = 8.5;
a[7] = 9.5;
a[8] = 10.5;
a[9] = 11.5;
a[10] = 12;
for (int i=1;i<7;++i) {
draw ((a[i],0)--(a[i],f(a[i])),black+dashed+0.5bp);
dot((a[i],f(a[i])));
}
for (int i=7;i<9;++i) {
draw ((a[i],0)--(a[i],g(a[i])),black+dashed+0.5bp);
dot((a[i],g(a[i])));
}
for (int i=9;i<11;++i) {
draw ((a[i],0)--(a[i],h(a[i])),black+dashed+0.5bp);
dot((a[i],h(a[i])));
}
label("$A$",(a[1],0),S);
label("$B$",(a[2],0),S);
label("$C$",(a[3],0),S);
label("$D$",(a[4],0),S);
label("$E$",(a[5],0),S);
label("$F$",(a[6],0),S);
label("$G$",(a[7],0),S);
label("$H$",(a[8],0),S);
label("$I$",(a[9],0),S);
label("$J$",(a[10],0),S);
// end