size( 200 ) ;
 draw( (-0.5,0)--(3.5,0) , arrow=Arrows ) ;
 draw( (0,-0.5)--(0,2.5) , arrow=Arrows ) ;

 fill( (1,0)--(1,1)--(2,1)--(2,2)--(3,2)--(3,0)--cycle , lightblue ) ;
 draw( (0,0)--(1,0) ^^ (1,1)--(2,1) ^^ (2,2)--(3,2) , blue ) ;
 dot( (0,0) , blue ) ; dot ( (1,1) , blue ) ; dot( (2,2) , blue ) ;
 fill( circle( (1,0) , 0.05 ) , white ) ; draw( circle( (1,0) , 0.05 ) , blue ) ;
 fill( circle( (2,1) , 0.05 ) , white ) ; draw( circle( (2,1) , 0.05 ) , blue ) ;
 fill( circle( (3,2) , 0.05 ) , white ) ; draw( circle( (3,2) , 0.05 ) , blue ) ;