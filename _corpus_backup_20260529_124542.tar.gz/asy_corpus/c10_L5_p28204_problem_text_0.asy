size( 200 ) ;

for( int i=1 ; i<=6 ; ++i ){
 draw( (i,-3.75)--(i,4.75) , gray ) ;
}
for( int i=-3 ; i<=4 ; ++i ){
 draw( (-.75,i)--(6.75,i) , gray ) ;
}
draw( (0,-4)--(0,5) , arrow=Arrows , linewidth(1.25) ) ;
draw( (-1,0)--(7,0) , arrow=Arrows , linewidth(1.25) ) ;

draw( (0,-2)--(4,4)--(6,2) , red ) ;
label( "$f$" , (6,2) , E , red ) ;
draw( (0,2)--(1,3)--(4,-3)--(6,-1) , blue ) ;
label( "$g$" , (6,-1) , E , blue ) ;

add(pathticks( (0,0)--(1,0) , 1 , 1 )) ; label( "$1$" , (1,0) , 2N ) ;
add(pathticks( (0,0)--(0,1) , 1 , 1 )) ; label( "$1$" , (0,1) , 2W ) ;