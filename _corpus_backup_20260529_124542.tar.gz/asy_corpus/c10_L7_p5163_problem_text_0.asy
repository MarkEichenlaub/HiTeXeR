size(6cm);
pair A,B,C;
A = (3,0);
B = (8.5,8);
C = (0,5);
fill (A--B--C--cycle,lightgrey);
draw (A--C--B,black+1bp);
draw ((0,0)--A--B--(8.5,11)--(0,11)--cycle,black+1bp);