size(6cm);
draw(circle((2,2),2));
xaxis(Label("$x$",position=EndPoint, align=SE), Arrow);
yaxis(Label("$y$",position=EndPoint, align=NW), Arrow);
pair C = (2,2);
label("$(4\pi t, 2)$", (2,2), N);
dot(C);
real a = sin(pi/6);
real b = cos(pi/6);
pair RD = (2*(1-a),2*(1-b));
label("$(x,y)$", RD, WSW);

label("$	heta$", (2,2), 4*SSW);
label("$2$", 0.5*(C+RD), NW);

dot(RD, red);
draw(C--RD, dotted);
draw(C--(2,0), dotted);
draw(RD--(2,2*(1-b)), dotted);
draw(rightanglemark((0,0), (2,0), C, 4));
draw(rightanglemark(RD, (2,2*(1-b)), C, 4));