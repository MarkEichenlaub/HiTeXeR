unitsize(1.5 cm);

real a = 0.8, thetazero;
pair O, P;

O = (0,0);
P = (1,1.5) + dir(20);
thetazero = degrees(P);

draw(rotate(-thetazero)*arc((1,1.5),1,80,-40),red);
draw(O--rotate(-thetazero)*interp(O,P,1.5));
draw(rotate(-thetazero)*((P + dir(-70))--(P + dir(110))));

label("$r = g(	heta)$", rotate(-thetazero)*((1,1.5) + dir(80)), W, red);
label("$\alpha$", rotate(-thetazero)*(P) + (0.3,0.2));
dot("$O$", O, W);
dot("$(g(0),0)$", rotate(-thetazero)*(P), SE);