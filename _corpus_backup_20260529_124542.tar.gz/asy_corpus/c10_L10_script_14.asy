// lower darboux sum for x^2 on [1,2]
import graph;
size(8cm);
real f(real x){return (x^2);}
real a,b,c,d;
a = 1; b = 2;
int i,n;
// n is the number of rectangles
n = 20;  
path bdry=(b,f(b))--(b,0)--(a,0)--(a,f(a));
fill(buildcycle(bdry,graph(f,a,b)),.9white);
draw ((a,0)--(a,f(a)),black+0.75bp);
draw ((b,0)--(b,f(b)),black+0.75bp);
path rect;
draw(graph(f,0,b+0.1),black+1bp);
for (i=0; i<n; ++i) {
  c = a + (i/n)*(b-a);
  d = a + ((i+1)/n)*(b-a);
  rect = (c,0)--(c,f(c))--(d,f(c))--(d,0)--cycle;
  fill(rect,.6white);
  draw(rect,black+0.75bp);
}
xaxis(Label("$x$",position=EndPoint, align=SE),Arrow);
yaxis(Label("$y$",position=EndPoint, align=NW),Arrow);
label("$1$",(a,0),S);
label("$2$",(b,0),S);
label("$(1,1)$",(a,f(a)),N+0.5W);
// end