// cycloid 
size(10cm,0);
path p = scale(2)*unitcircle;
path q = scale(0.2)*unitcircle;
pair A = (0,-2);
pair B,C;
guide g = (0,0);
real pi=3.14159;
int i;
pen w;
for (i=0;i<9;++i) {
B = (i*pi/2,2);
C = B + rotate(-45*i)*A;
if (i%2 == 0) {
draw(shift(B)*p,black+0.75bp);
} else {
draw(shift(B)*p,heavycyan+0.75bp);
}
draw(arc(B,2,-60-(i*45),-1205-(i*45)),heavygreen+2bp);
fill(shift(C)*q,red);
if (i>0) { g = g..C; }
}
draw(g,blue+1bp);
draw((-3,0)--(3+4*pi,0),black+1.5bp);
draw(arc((0,2),3,-180,-270),black+2bp,Arrow(3mm));
// end