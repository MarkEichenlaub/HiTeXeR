unitsize(2cm);

real cx = 0.5; //offset of centres from origin
real r = 1; // radius of circles

pair A = (-cx,0); pair B = (cx, 0);
path circleA = circle(A, r); path circleB = circle(B,r);

pair[] intpts = intersectionpoints(circleA,circleB);
pair C = intpts[0]; pair D = intpts[1]; // C is the top intersection point, D is the bottom one

path uarc = arc(A,C,D)--arc(B,D,C)--cycle; //outline of union
path iarc = arc(A,D,C)--arc(B,C,D)--cycle; //outline of intersection

fill(circleA, lightred); fill(circleB,lightblue); fill(iarc, 0.8*purple);

draw(circleA); draw(circleB); draw(iarc, black+4pt);

label("$A$", A+1.25*r*dir(135), red); label("$B$", B+1.25*r*dir(45), blue); label("$A \cap B$", origin+1.25*r*dir(90), black+4pt);