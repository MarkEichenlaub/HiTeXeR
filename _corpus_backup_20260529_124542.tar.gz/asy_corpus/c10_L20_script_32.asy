import graph;
size(7cm);
real pi=3.14159;
real i;
real f(real t) {return (cos(2*t));}
draw(polargraph(f,0,2*pi),blue+1bp);
for(i=15; i<360; i=i+15) {
  draw(rotate(i)*((0,0)--(1.25,0)),black+0.5bp);
}
draw(rotate(240)*((0,0)--(1.25,0)),red+1.5bp);
for(i=0;i<1.25;i=i+0.25) {
  draw(scale(i)*unitcircle,black+0.5bp);
}
dot((-1/4,-sqrt(3)/4),black+5bp);
xaxis(Arrow);
yaxis(Arrow);