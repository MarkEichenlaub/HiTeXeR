size(8cm);
//variables
real d, s; 
d = 240; // angle in degrees
s = 0.24; //scale of angle mark
pair xy, O, P;
xy = dir(d); // point on unit circle 
O = origin;
P=(xy.x,0); //projection to x-axis

//axes
draw((-1.5,0)--(1.5,0),Arrow);
draw((0,-1.5)--(0,1.5),Arrow);

//drawing
draw(circle((0,0),1),linewidth(1)); //unit circle
dot (xy);
draw (O -- xy); //origin to point on unit circle
draw(arc(O, s, 0, d), blue); //angle mark 
draw (P--xy); //altitude
draw(rightanglemark(O,P,xy, 5), blue);

//labels
label("$\left(\cos \left(\frac{4\pi}{3}\right), \sin \left(\frac{4\pi}{3}\right) \right)$", xy, SW); // point on unit circle 
label ("$\frac{4\pi}{3}$",s*dir(d/2), N); // angle