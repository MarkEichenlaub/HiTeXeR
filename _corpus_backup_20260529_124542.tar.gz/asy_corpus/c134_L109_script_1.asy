import three;
import solids;

size(250);

currentprojection = perspective(6,3,2);

triple A, B, C, O, P, Q;
real a, b, c;
real[] r;
path3 plate = (-3,-4,0)--(1,-4,0)--(1,2,0)--(-3,2,0)--cycle;

A = (0,0,0);
B = (-1,1,0);
C = (-1,-1.5,0);
a = abs(B - C);
b = abs(A - C);
c = abs(A - B);
r[1] = (b*c)/(2*a);
r[2] = (a*c)/(2*b);
r[3] = (a*b)/(2*c);
O = A + (0,0,r[1]);
P = B + (0,0,r[2]);
Q = C + (0,0,r[3]);

draw(surface(plate),paleyellow,nolight);
draw(plate);
draw(surface(sphere(Q,r[3])), gray(0.8));
draw(surface(sphere(P,r[2])), gray(0.8));
draw(surface(sphere(O,r[1])), gray(0.8));
draw(A--B--C--cycle,red);
draw(O--P--Q--cycle,red);
draw(A--O,red);
draw(B--P,red);
draw(C--Q,red);

dot("$A$", A, S, red);
dot("$B$", B, S, red);
dot("$C$", C, S, red);
dot("$O$", O, O, red);
dot("$P$", P, P, red);
dot("$Q$", Q, Q, red);
label("$r$", (A + O)/2, W, yellow);
label("$s$", (B + P)/2, E, yellow);
label("$t$", (C + Q)/2, W, yellow);