size(175);

// set variables
real xmin = -2, xmax = 1, ymin = -7.5, ymax = 3.5;
real f (real x) {return (x^3/4 - x^2/3 - x/2+3*cos(x));}
real a = -1.373;

//shaded regions
path p = graph(f, a, 0);
fill(p--origin--cycle, lightblue);

real g (real x) {return (-f(x)-4);}
path r = graph(g, a, 0);
fill(r--(0, -4)--cycle, lightblue);

real d=-0.6;
path ri=xscale(0.1)*yscale(2)*unitcircle;
draw(shift(d,-2)*ri,lightblue);
path ro = xscale(0.3)*yscale(f(d)+2)*unitcircle;
draw(shift(d,-2)*ro,blue);

draw((xmin,-2)--(xmax,-2), red+dashed);
limits((xmin,ymin),(xmax,ymax),Crop);

// draw axes
xaxis(xmin, xmax, NoTicks, above=true);
yaxis(ymin, ymax, NoTicks, above=true);