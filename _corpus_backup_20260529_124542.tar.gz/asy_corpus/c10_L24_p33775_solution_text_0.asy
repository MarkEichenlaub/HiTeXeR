unitsize(3 cm);

real func (real x) {
  return(x*exp(x));
}

draw(graph(func,0,0.5),red);
draw((-0.1,0)--(0.5,0));
draw((0,-0.1)--(0,func(0.5)));

label("$y = g(x)$", (0.8,func(0.5)/2));
label("$x$", (0.5,0), E);
label("$y$", (0,func(0.5)), N);