// integral test for harmonic series part I
size(6cm);
import graph;
real f(real x) {return (4/x);}
path b;
int n;
for (n=1;n<6;++n) {
b = (n,0)--(n,f(n+1))--(n+1,f(n+1))--(n+1,0)--cycle;
fill(b,rgb(.8,.8,.8));
draw(b,black+0.8bp);
}
draw((1,0)--(1,f(1)),black+1bp);
draw(graph(f,0.8,6),black+1bp);
xaxis(Label("$x$",position=EndPoint, align=SE), Arrow);
yaxis(Label("$y$",position=EndPoint, align=NW), Arrow);
label("$y = f(x)$",(1,f(1)),NE);
label("$1$",(1,0),S);
label("$1$",(0,f(1)),W);
//