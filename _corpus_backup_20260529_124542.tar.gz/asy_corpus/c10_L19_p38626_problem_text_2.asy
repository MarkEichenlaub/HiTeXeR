unitsize(0.5 cm);

real t, u, xprime, yprime;

path cycloid = (0,0);
path strin = (0,0);
path bluecycloid = (-pi,2);
pair A, B;

for (t = -2*pi; t <= 2*pi; t = t + 0.1) {
  cycloid = cycloid--(t - sin(t),1 - cos(t));
}

u = 1.7;

for (t = 0; t <= u; t = t + 0.1) {
  strin = strin--(t - sin(t),1 - cos(t));
}

xprime = 1 - cos(t);
yprime = sin(t);
A = (0,0);
B = (u - sin(u),1 - cos(u)) + 4*cos(u/2)*(xprime/sqrt(xprime^2 + yprime^2),yprime/sqrt(xprime^2 + yprime^2));
strin = strin--B;

for (t = -pi; t <= pi; t = t + 0.1) {
  bluecycloid = bluecycloid--(t + sin(t),3 + cos(t));
}

draw(bluecycloid,blue);
draw(cycloid,red);
draw(strin,red + linewidth(2*bp));
draw((-2*pi,0)--(2*pi,0));

dot(A,red + linewidth(5*bp));
dot(B,blue + linewidth(5*bp));
label("$A$", A, S);
label("$B$", B, NE);