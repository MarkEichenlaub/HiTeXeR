real f(real x){return (sqrt(4-x^2));};
draw(graph(f,-2,2), red+dashed);
draw(graph(f,1,2), blue+1.8bp);
xaxis(Label("$x$",position=EndPoint, align=SE),xmin=-2.5, xmax=2.5, Ticks("%", Step=1, step=0)); 
labelx(1,2S); 
yaxis(Label("$y$",position=EndPoint, align=NW),ymin=-0.5, ymax=2.5,Ticks("%", Step=1, step=0)); 
labely(1,2W); 
dot((2,0), blue);
dot((1, f(1)), blue);