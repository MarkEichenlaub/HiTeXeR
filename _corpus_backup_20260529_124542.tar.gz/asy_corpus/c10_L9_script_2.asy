// ladder sliding

size(6cm);
draw ((-20,0)--(0,0)--(0,20),black+1bp);
draw ("6 ft",(-10,0)--(0,15),blue+1.5bp);
draw ("2 in/sec",(-15,-1)--(-10,-1),black,BeginArrow);

// end