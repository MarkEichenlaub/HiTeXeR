import graph;
size(5cm, IgnoreAspect);

real f(real x) {return cos(x);}
real g(real x) {return sin(x);}
//pair F(real x) {return (x,f(x));}

draw(graph(f,0,pi/2,operator ..),red);
draw(graph(g,0,pi/2,operator ..),blue);
xlimits(-2,2.5);
ylimits(-1,2);

yaxis(LeftTicks(NoZero));

draw((pi/2, 0)--(pi/2, 1), dashed);

xaxis("$x$");

label("$\pi/2$", pi/2,S);