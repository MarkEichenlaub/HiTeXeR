// graph interpretation example
import graph;
size(10cm);
pair[] P;
real f(real x){return (0.25*x^2*(x-3)^2+3);}
real g(real x){return (1/4*x+6);}
real h(real x){return (9-(x-9)^2);}
xlimits(0, 13);
draw(graph(f,0.5,4),black+0.75bp);
draw(graph(g,4,8),black+0.75bp);
draw(graph(h,8,11.5),black+0.75bp);
xaxis(Label("$x$",position=EndPoint, align=SE),Arrow);
yaxis(Label("$y$",position=EndPoint, align=NW),Arrow);

dot((0.5,f(0.5))); dot((11.5,h(11.5)));

real a[];
a[1]=1;
a[2]=1.5;
a[3]=2;
a[4]=3;
a[5]=3.5;
a[6]=4;
a[7]=6;
a[8]=8;
a[9]=9;
a[10]=10;
a[11]=11;


for (int i=1;i<7;++i) {
draw ((a[i],0)--(a[i],f(a[i])),black+dashed+0.5bp);
dot((a[i],f(a[i])));}

for (int i=7;i<9;++i) {
draw ((a[i],0)--(a[i],g(a[i])),black+dashed+0.5bp);
dot((a[i],g(a[i])));}

for (int i=9;i<12;++i) {
draw ((a[i],0)--(a[i],h(a[i])),black+dashed+0.5bp);
dot((a[i],h(a[i])));}

label("$A$",(a[1],0),S);
label("$B$",(a[2],0),S);
label("$C$",(a[3],0),S);
label("$D$",(a[4],0),S);
label("$E$",(a[5],0),S);
label("$F$",(a[6],0),S);
label("$G$",(a[7],0),S);
label("$H$",(a[8],0),S);
label("$I$",(a[9],0),S);
label("$J$",(a[10],0),S);
label("$K$",(a[11],0),S);

// end