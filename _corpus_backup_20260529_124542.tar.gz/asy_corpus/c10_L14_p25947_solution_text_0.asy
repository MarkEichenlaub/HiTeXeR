size( 200 ) ; 
 draw( (-1.5,0)--(1.5,0) , arrow=Arrows ) ;
 draw( (0,-0.5)--(0,1.5) , arrow=Arrows ) ;

 real par( real x ){ return x^2 ; }
 real lin( real x ){ return 1 ; }
 draw( graph( lin , -1.2 , 1.2 ) , green ) ; label( "$y=1$" , (1.2,lin(1.2)) , E , green ) ;
 draw( graph( par , -1.2 , 1.2 ) , blue ) ; label( "$y=x^2$" , (1.2,par(1.2)) , E , blue ) ;

 real cs = 0.2 ; 
 draw( (cs,par(cs))--(cs,lin(cs)) , red ) ;
 label( "cross-section" , (cs,par(cs))--(cs,lin(cs)) , E , red ) ;