// unit circle with tangent line
import graph;
size(6cm);
real f(real x){return (sqrt(1-x^2));}
real g(real x){return (-1*sqrt(1-x^2));}
xlimits( -1.5, 1.5);
ylimits( -1.5, 1.5);
draw(graph(f,-1,1),black+1bp);
draw(graph(g,-1,1),black+1bp);
pair P = (sqrt(2)/2,sqrt(2)/2);
draw((P+(-1,1))--(P+(1,-1)),blue+0.75bp);
xaxis(Label("$x$",position=EndPoint, align=SE),NoTicks, Arrow);
yaxis(Label("$y$",position=EndPoint, align=NW),NoTicks, Arrow);
labelx(1,2SE);
labely(1,2NW);
// end