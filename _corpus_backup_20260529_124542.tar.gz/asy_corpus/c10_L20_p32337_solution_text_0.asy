unitsize(1 cm);

real func (real x) {
  return (2 + 2*sqrt(2)*sin(x));
}

draw((0,0)--(2*pi,0));
draw((0,-1)--(0,5));
draw(graph(func,0,2*pi),red);

label("$x$", (2*pi,0), E);
label("$y$", (0,5), N);

dot("$(0,2)$", (0,2), W);
dot("$(\frac{\pi}{2}, 2 + 2 \sqrt{2})$", (pi/2,func(pi/2)), N);
dot("$(\pi, 2)$", (pi,func(pi)), NE);
dot("$(\frac{5 \pi}{4}, 0)$", (5*pi/4,func(5*pi/4)), SW);
dot("$(\frac{3 \pi}{2}, 2 - 2 \sqrt{2})$", (3*pi/2,func(3*pi/2)), S);
dot("$(\frac{7 \pi}{4}, 0)$", (7*pi/4,func(5*pi/4)), SE);
dot("$(2 \pi, 2)$", (2*pi,func(2*pi)), E);