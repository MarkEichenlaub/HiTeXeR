// delta-epsilon def
import graph;
size(7cm);
real f(real x){return ((1/3)*x^3 - 2*x^2 + 3*x + 2);}
xlimits( -0.5, 3.5);
ylimits( -1, 3);
draw(graph(f,-0.5,3.5));
xaxis(Label("$x$",position=EndPoint, align=SE),Arrow);
yaxis(Label("$y$",position=EndPoint, align=NW),Arrow);
dot((0,0));
unfill(shift(2,f(2))*scale(.05)*unitcircle);
draw(shift(2,f(2))*scale(.05)*unitcircle);
label("$\displaystyle\lim_{x \rightarrow a} f(x) = L$",(0,0.5),NE);
real d,e;
e = 0.3;
d = 0.2;
draw((0,f(2)-e)--(3,f(2)-e),blue);
draw((0,f(2)+e)--(3,f(2)+e),blue);
label("$L - \epsilon$",(3,f(2)-e),E);
label("$L + \epsilon$",(3,f(2)+e),E);
//draw((2-d,0)--(2-d,4),red);
//draw((2+d,0)--(2+d,4),red);
//label("$a - \delta$",(2-d,4),NW);
//label("$a + \delta$",(2+d,4),NE);
// end