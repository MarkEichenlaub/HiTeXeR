unitsize(3 cm);

fill((0,0.2)--(0,-1.2)--(1,-1.2)--(1,0.2)--cycle,paleblue);
draw((0,0.2)--(0,-1.2));
draw((1,0.2)--(1,-1.2));
draw((0,0)--(1,0),dashed);

label("$1$", (1,-0.5), E);
label("$1$", (0.5,-1.2), S);

dot("Start", (0,0), W);
dot("End", (1,-1), E);