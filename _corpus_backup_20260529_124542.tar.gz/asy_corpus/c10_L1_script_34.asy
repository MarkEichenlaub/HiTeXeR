size(10cm,0);

real s(real x) {return (sin(x));}

real f(real x) {return (x/100);}

yscale(0.25);

draw(graph(s,30*pi,32*pi),red+1bp);

draw(graph(f,30*pi,32*pi),black+1bp);

xaxis(Label("$x$",position=EndPoint,align=NE),Ticks(Step=1),Arrow(2mm));