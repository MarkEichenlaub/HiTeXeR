size(10cm,0);

real s(real x) {return (sin(x));}

real f(real x) {return (x/100);}

yscale(0.25);

draw(graph(s,0,2*pi),red+1bp);

draw(graph(f,0,2*pi),black+1bp);

xaxis(Label("$x$",position=EndPoint,align=NE),Ticks(Step=1),Arrow(2mm));

yaxis(Label("$y$",position=EndPoint,align=NE),Ticks(Step=1),Arrow(2mm));