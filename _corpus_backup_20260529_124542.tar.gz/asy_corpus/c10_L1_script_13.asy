import olympiad; 
size(150); 
pair A, B, C; 
A = (0, 0); 
C = (9, 0); 
B = (9, 12); 
draw(A--B--C--cycle); 
draw(rightanglemark(A, C, B, 15)); 
label("$A$", A, S); 
label("$B$", B, N); 
label("$C$", C, S); 
label("$b$", A--C, S); 
label("$a$", B--C, E); 
label("$c$", A--B, NW);