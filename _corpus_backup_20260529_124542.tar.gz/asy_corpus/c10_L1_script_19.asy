size(8cm);
//variables
real d, s;
d = 420; // angle in degrees
s = 0.24; //scale of angle mark
pair xy, O, P;
xy = dir(d); // point on unit circle
O = origin;
P=(xy.x,0); //projection to x-axis
//axes
draw((-1.5,0)--(1.5,0),Arrow);
draw((0,-1.5)--(0,1.5),Arrow);
//drawing
draw(circle((0,0),1),linewidth(1)); //unit circle
dot (xy);
draw (O -- xy); //origin to point on unit circle
//draw(arc(O, s, 0, 360), blue); //angle mark
draw (P--xy); //altitude
draw(rightanglemark(O,P,xy, 5), blue);
//labels
label("$\left(\cos \left(\frac{7\pi}{3}\right), \sin \left(\frac{7\pi}{3}\right) \right)$", xy, NE); // point on unit circle
label ("$\frac{7\pi}{3}$",s*dir(d/2), W); // angle
real s = 0.2;
real g = 1.05;
path p = s*dir(0) .. g*s*dir(90) .. (g**2)*s*dir(180) .. (g**3)*s*dir(270) .. (g**4)*s*dir(360) .. (g**4)*s*dir(60);
draw(p, arrow=ArcArrow(TeXHead), blue);