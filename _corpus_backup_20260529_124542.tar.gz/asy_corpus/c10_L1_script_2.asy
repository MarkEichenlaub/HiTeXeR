// tgt to y=x^2 at (1,1)

import graph;

size(5cm);

real f(real x){return (x^2);}

real g(real x){return (2*x-1);}

xlimits( -2, 2);

ylimits( -0.1, 4);

draw(graph(f,-2,2),black+1bp);

draw(graph(g,0,2),blue+1bp);

xaxis(Label("$x$",position=EndPoint, align=SE),Ticks("%"), Arrow);

yaxis(Label("$y$",position=EndPoint, align=NW),Ticks("%"), Arrow);

dot((1,f(1)));

label("$(1,1)$",(1,f(1)),NW);

// end