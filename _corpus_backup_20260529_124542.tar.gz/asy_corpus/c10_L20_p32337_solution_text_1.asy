unitsize(1 cm);

real r, t, x, y;
path foo = (2,0);

for (t = 0; t <= 2*pi; t = t + 0.01) {
  r = 2 + 2*sqrt(2)*sin(t);
  x = r*cos(t);
  y = r*sin(t);
  foo = foo--(x,y);
}

draw(foo,red);
draw((-3,0)--(3,0));
draw((0,-1)--(0,5.5));