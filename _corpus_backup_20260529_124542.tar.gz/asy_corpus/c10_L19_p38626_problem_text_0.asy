unitsize(0.5 cm);

real t;

path cycloid = (0,0);

for (t = 0; t <= 6*pi; t = t + 0.1) {
  cycloid = cycloid--(t - sin(t),1 - cos(t));
}

draw(cycloid,red);
draw((0,0)--(6*pi,0));