import graph;
size(6cm,6cm);
real f(real t){return ((t^3 - 6*t^2 + 9*t + 1));}
draw(graph(f,0,4),black+1bp);
xaxis(Label("$t$",position=EndPoint, align=SE),Ticks("%"), Arrow);
yaxis(Label("$s$",position=EndPoint, align=NW),Ticks("%"), Arrow);
labelx(1,2S);
labelx(2,2S);
labelx(3,2S);
labely(1,2W);
labely(5,2W);
draw((1,0)--(1,5.5),black+0.5bp+dashed);
draw((3,0)--(3,5.5),black+0.5bp+dashed);