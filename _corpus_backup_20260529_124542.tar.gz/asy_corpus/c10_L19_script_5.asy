unitsize(1cm);
real f(real t) {return(t*cos(t));}
real g(real t) {return(sin(t));}
draw(graph(f,g,0,pi/2,Spline),blue+1bp);
draw ((-pi,0)--(pi,0));
draw ((0, -1.5)--(0,1.5));