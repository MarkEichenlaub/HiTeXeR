import graph;
size(4cm);
real f(real t) {return (1);}
real g(real t) {return (1-cos(t));}
draw(polargraph(f,0,radians(360)),blue+1bp);
draw(polargraph(g,0,radians(360)),green+1bp);
xaxis(Arrow); yaxis(Arrow);