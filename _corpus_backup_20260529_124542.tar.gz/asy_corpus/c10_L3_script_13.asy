// graph of (x^2-1)/(x-1)

size(7cm);

xlimits( -3, 3);

ylimits( -3, 3);

real f(real x){return (x+1);}

draw(graph(f,-3,3),Arrows(.15cm));

xaxis(Label("$x$",position=EndPoint, align=SE),Ticks('%'), Arrow);

yaxis(Label("$y$",position=EndPoint, align=NW),Ticks('%'), Arrow);

labelx(1,2S);

labely(1,2W);

dot((0,0));

unfill(shift(1,2)*scale(.05)*unitcircle);

draw(shift(1,2)*scale(.05)*unitcircle);

// delta, epsilon

real d,e, ly, lx;
e = 0.1;
d = 0.1;
ly = 2;
lx= 1;
draw((-3,ly-e)--(3,ly-e),blue);
draw((-3,ly+e)--(3,ly+e),blue);
label("$2 - \epsilon$",(3,ly-2*e), SE, blue);
label("$2 + \epsilon$",(3,ly+2*e), NE, blue);
draw((lx-d,-3)--(lx-d,4),red);
draw((lx+d,-3)--(lx+d,4),red);
label("$1 - \delta$",(lx-d,-0.7), W, red);
label("$1 + \delta$",(lx+d, -0.7), E, red);