unitsize(1 cm);

real r = 1, s = 2;
pair A, B, O, P;

A = (0,0);
B = (2*sqrt(r*s),0);
O = A + (0,r);
P = B + (0,s);

draw(A--O--P--B,red);
draw(Circle(O,r));
draw(Circle(P,s));
draw((-r,0)--(2*sqrt(r*s) + s,0));

dot("$A$", A, S);
dot("$B$", B, S);
dot("$O$", O, NW);
dot("$P$", P, NE);
label("$c$", (A + B)/2, S, red);
label("$r$", (A + O)/2, W, red);
label("$s$", (B + P)/2, E, red);