size( 200 );
draw( (-3.5,0)--(3.5,0) , arrow=Arrows ) ;
draw( (0,-2)--(0,2) , arrow=Arrows ) ;

real cosine( real x ){ return cos(x) ; }
real identity( real x ){ return x ; }

draw( graph( cosine , -3.3 , 3.3 ) , blue ) ;
draw( graph( identity , -2 , 2 ) , red ) ;
pair int_pt = intersectionpoint( graph( cosine , -3.3 , 3.3 ) , graph( identity , -2 , 2 ) ) ;
dot( int_pt , purple ) ;