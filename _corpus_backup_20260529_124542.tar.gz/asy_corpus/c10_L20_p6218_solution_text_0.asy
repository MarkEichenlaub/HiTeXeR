import graph;
real a=1;
size(4cm);
real f(real t) {return (sqrt(2*a*a*cos(2(t))));}
real g(real t) {return (-1*sqrt(2*a*a*cos(2(t))));}
draw(polargraph(f,radians(-45),radians(45)),blue+1bp);
draw(polargraph(g,radians(-45),radians(45)),blue+1bp);
dot((a,0),black+2bp);
dot((-a,0),black+2bp);
xaxis(Arrow); yaxis(Arrow);