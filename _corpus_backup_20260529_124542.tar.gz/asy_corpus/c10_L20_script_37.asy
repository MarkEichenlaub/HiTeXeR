// area of one leaf of 3cos(2t)
import graph;
size(5cm);
real pi=3.14159;
real f(real t) {return (3*cos(2*t));}
guide g = polargraph(f,-pi/4,pi/4);
fill(buildcycle((0,0)--point(g,0),g,point(g,length(g))--(0,0)),rgb(.8,.8,.8));
draw(polargraph(f,0,2*pi),blue+1bp);
xaxis(Arrow(2mm));
yaxis(Arrow(2mm));