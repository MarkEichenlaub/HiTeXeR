unitsize(1cm);
real f(real t) {return(t*cos(t));}
real g(real t) {return(sin(t));}
draw(graph(f,g,0,2*pi,Spline),red);
draw(graph(f,g,2*pi,13*pi/3,Spline),blue+1bp);
draw ((-3*pi,0)--(4*pi,0));
draw ((0, -1.5)--(0,1.5));