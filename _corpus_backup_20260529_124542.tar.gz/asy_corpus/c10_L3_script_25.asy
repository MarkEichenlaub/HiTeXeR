// topologist's sine curve
import graph;
size(4cm);
real f(real x){return sin(20/x);}
xlimits( -0.5, 2);
ylimits( -1.2, 1.2);
draw(graph(f,0.01,2,1000));
xaxis(Label("$x$",position=EndPoint, align=SE),Arrow);
yaxis(Label("$y$",position=EndPoint, align=NW),Arrow);