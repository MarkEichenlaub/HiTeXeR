size(10cm,0);

real c(real x) {return (cos(x));}

draw(graph(c,-7,7),blue);

xaxis(Label("$x$",position=EndPoint,align=NE),Ticks("%",Step=1),Arrow(2mm));

yaxis(Label("$y$",position=EndPoint,align=NE),Ticks("%",Step=1),Arrow(2mm));