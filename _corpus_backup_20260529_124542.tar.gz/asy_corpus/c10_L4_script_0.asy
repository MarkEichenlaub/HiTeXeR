import graph;
unitsize(0.5cm);

real f(real x){return (x^0.5);}

xlimits(-2,2);
ylimits(-2,2);
draw(graph(f,0,2.5),black+1bp);
draw((-1,2)--(-1,-2), dashed+gray(0.5));

xaxis(Label("$x$",position=EndPoint, align=SE),Ticks("%"), Arrow);
yaxis(Label("$y$",position=EndPoint, align=NW),Ticks("%"), Arrow);

labelx(1,2S);
labely(1,2W);

label("$x = -1$", (-1,2), 3SW, gray(0.5));
label("$f(x) = \sqrt{x}$", (1,1), 2SE);