// "random" graph
import graph;
size(7cm);
real a,b;
a=1; b=3;
real f(real x){return ((1/3)*x^3 - (3/2)*x^2 + 2*x + 2);}
real g(real x){return (-1*f(x));}
draw(graph(f,0,3.5),black+1bp);
draw((a,0)--(a,f(a)),black+0.75bp+dashed);
draw((b,0)--(b,f(b)),black+0.75bp+dashed);
xaxis(Label("$x$",position=EndPoint, align=SE),Arrow);
yaxis(Label("$y$",position=EndPoint, align=NW),Arrow);
label("$a$",(a,0),S);
label("$b$",(b,0),S);