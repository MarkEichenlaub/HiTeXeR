// hyperbola
import graph;
size(6cm);
real f(real x){return (1/x);}
xlimits( -5, 5);
ylimits( -5, 5);
draw(graph(f,-5,-0.2));
draw(graph(f,0.2,5));
xaxis(Label("$x$",position=EndPoint, align=SE),Arrow);
yaxis(Label("$y$",position=EndPoint, align=NW),Arrow);
dot((0,0));
// end