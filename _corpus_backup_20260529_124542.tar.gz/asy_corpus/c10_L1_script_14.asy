import olympiad; 
size(75); 
pair A, B, C; 
A = (0, 0); 
C = (9, 0); 
B = (9, 12); 
draw(A--B--C--cycle); 
draw(rightanglemark(A, C, B, 30)); 
label("$A$", A, S); 
label("$B$", B, N); 
label("$C$", C, S);