size(7cm);
size(7cm);
real f, g, df, dg, s;
f=2.5;
g=1.5;
df=0.15;
dg=0.2;
s= -0.05;

pair O, F, G, FG, DG, DF, FDG, GDF, DFDG;
O=origin;
F= (f, 0);
G= (0,g);
FG=(f,g);
DG = (0, g+dg);
DF= (f+df, 0);
FDG = (f, g+dg);
GDF = (f+df, g);
DFDG=(f+df, g+dg);

draw(O--DF--DFDG--DG--cycle);
draw(F--FDG, gray);
draw(G--GDF, gray);

pen cbred=RGB(224,109,128);
pen cbblue=RGB(136,204,238);
pen cbgreen=RGB(72,189,107);
pen cbyellow=RGB(236,217,120);

filldraw(F--DF--DFDG--FDG--cycle, cbblue);
filldraw(G--DG--DFDG--GDF--cycle, cbred);
filldraw(DFDG--GDF--FG--FDG--cycle, lightgray);

draw("$f(x)$", brace( DG, FDG), N, red);
draw("$\Delta f$", brace(FDG, DFDG), N, blue);
draw("$g(x)$", brace( GDF, DF), E, blue);
draw("$\Delta g$", brace(DFDG, GDF), E, red);