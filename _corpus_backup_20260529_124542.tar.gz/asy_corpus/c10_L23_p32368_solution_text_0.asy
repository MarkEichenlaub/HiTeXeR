unitsize(1.5 cm);

pair A, B, P;
real a, m;

a = 1.2;
m = -1/a^2;
P = (a,1/a);

real func (real x) {
  return(1/x);
}

A = extension(P, P + (1,m), (0,0), (1,0));
B = extension(P, P + (1,m), (0,0), (0,1));

draw(graph(func,1/2,4),red);
draw(A--B);
draw((-0.5,0)--(4,0));
draw((0,-0.5)--(0,2));

dot("$A$", A, S);
dot("$B$", B, W);
dot("$P$", P, NE);