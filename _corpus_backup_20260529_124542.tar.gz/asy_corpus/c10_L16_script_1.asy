size(175);

// set bounds of the grid
real xmin = 0, xmax = 14, ymin = -3, ymax = 7;

// plot points
dot((2,1));
dot((3,4));
dot((5,-2));
dot((8,3));
dot((13,6));
draw((3,4)--(5,-2), dashed);

// set parameters of the grid lines
ticks tgrid = Ticks(Label("%"), Step = 1, extend = true, rgb(0,0.7,0.7) + 0.4*bp);

// draw axes and grid lines
xaxis(xmin, xmax, Arrow(6), above = true);
yaxis(ymin, ymax, Arrow(6), above = true);
xaxis(BottomTop, xmin, xmax, invisible, tgrid);
yaxis(LeftRight, ymin, ymax, invisible, tgrid);