import three;
import solids;

// calculate intersection of line and plane
// p = point on line
// d = direction of line
// q = point in plane
// n = normal to plane
triple lineintersectplan(triple p, triple d, triple q, triple n)
{
  return (p + dot(n,q - p)/dot(n,d)*d);
}

// projection of point A onto line BC
triple projectionofpointontoline(triple A, triple B, triple C)
{
  return lineintersectplan(B, B - C, A, B - C);
}

// calculate circumcentre of space triangle ABC
triple trianglecircumcentre(triple A, triple B, triple C)
{
  return lineintersectplan((A + C)/2, cross(cross(C - A, B - A), C - A), (A + B)/2, B - A);
}

size(150);

currentprojection = perspective(6,3,2);

triple A, B, C, D, M, N, O, P, T, X, Y, Z;
triple[] R;

O = (0,0,0);
X = (0.2,0.5,0.7);
R[1] = (2,3,-0.5);
M = projectionofpointontoline(O, X, X + R[1]);
A = M - sqrt(1 - abs(M)^2)*R[1]/abs(R[1]);
B = M + sqrt(1 - abs(M)^2)*R[1]/abs(R[1]);

R[2] = (3,-3,-2);
N = projectionofpointontoline(O, X, X + R[2]);
C = N + sqrt(1 - abs(N)^2)*R[2]/abs(R[2]);
D = N - sqrt(1 - abs(N)^2)*R[2]/abs(R[2]);

Z = trianglecircumcentre(A, C, X);
R[3] = cross(A - X,C - X);
P = projectionofpointontoline(O, Z, Z + R[3]);
Y = P + sqrt(1 - abs(P)^2)*R[3]/abs(R[3]);

T = trianglecircumcentre(A,B,C);

draw(surface(sphere(O,1)), gray(0.8), nolight);
draw(circle(T, abs(T - A), T),red);
draw(sphere(O,1).silhouette());
draw(A--B);
draw(C--D);

dot("$A$", A, N);
dot("$B$", B, SE);
dot("$C$", C, SW);
dot("$D$", D, E);
dot("$X$", X, S);