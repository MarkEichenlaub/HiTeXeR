import graph;
size(8cm);

real f(real x){return (x^3 + x);}
real g(real x){return (4x-2);}

pair P;
P = (1,f(1));
xlimits( -1, 1.5);
draw(graph(f,-1,1.5),black+1bp);
draw(graph(g,0,1.5),blue+0.75bp);
xaxis(Label("$x$",position=EndPoint, align=SE),NoTicks, Arrow);
yaxis(Label("$y$",position=EndPoint, align=NW),NoTicks, Arrow);
dot(P);
label("$P$",P,SE);
label("$(1,2)$",P,NW);
label("$y = x^3+x$", (5/4, f(5/4)), W);
label("$y = 4x-2$",(1/2, g(1/2)), 2*SE);