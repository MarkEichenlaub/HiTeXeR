real f(real x){return (3*x+1);};
draw(graph(f,0,3.7), red+dashed+0.8bp, Arrows(5));
draw(graph(f,1,3), blue+1.2bp);
dot((1,4), blue+3bp);
dot((3,10), blue+3bp);
xaxis(Label("$x$",position=EndPoint, align=NE),xmin=0, xmax=3.7, Ticks(NoZeroFormat, step=1)); 
yaxis(Label("$y$",position=EndPoint,  align=NE),ymin=0, ymax=11.7,Ticks(NoZeroFormat));