import graph;
size(200);

real f(real x) {return sin(x);}
real g1(real x) {return (x);}
real g2(real x) {return (x-x^3/6);}
real g3(real x) {return (x-x^3/6+x^5/120);}
real g4(real x) {return (x-x^3/6+x^5/120-x^7/5040);}

draw(graph(f,0,45/7,operator ..),red);
draw(graph(g1,0,2,operator ..),blue+longdashed);
draw(graph(g2,0,3,operator ..),blue+dashdotted);
draw(graph(g3,0,4,operator ..),blue+dashed);
draw(graph(g4,0,4.5,operator ..),blue);

xlimits(-0.5,6.5);
ylimits(-2,2);

xaxis("$x$",RightTicks(NoZero));
yaxis("$y$", LeftTicks(NoZero));
label("\footnotesize $y= \sin(x)$",(2.5, 2.5), E, red);
label("\footnotesize $y=p_n(x)$",(2.5, 1.5), 0.5E, blue);