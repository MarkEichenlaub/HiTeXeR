size(5cm);
draw((0,4)--(0,0),black+1bp);
draw((0,0)--(2,0),gray+1bp);
draw((-1,6)--(2,0),black+1bp+dashed,Arrow(2mm));
fill(shift(-1,6)*scale(0.5)*unitcircle,yellow);
label("Sun",(0,6));
label("$	heta_0$",(1.5,0.25));
label("$80$",(1,-0.5),gray);
label("$160$", (0,2), W);