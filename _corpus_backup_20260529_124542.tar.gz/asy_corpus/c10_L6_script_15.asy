// random function on [a,b]
import graph;
size(8cm);
real f(real x){return (2*x-(x^2)/2 + 0.5);}
xlimits(0, 5);
draw(graph(f,0.5,4),black+0.75bp);
xaxis(Label("$x$",position=EndPoint, align=SE),Arrow);
yaxis(Label("$y$",position=EndPoint, align=NW),Arrow);
dot((0.5,f(0.5))); dot((4,f(4)));
draw((0.5,0)--(0.5,f(0.5)),black+dashed);
draw((4,0)--(4,f(4)),black+dashed);
label("$a$",(0.5,0),S);
label("$b$",(4,0),S);
// end