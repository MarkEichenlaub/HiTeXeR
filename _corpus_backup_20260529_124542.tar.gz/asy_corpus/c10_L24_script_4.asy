real arrowlength = 0.1;
real slope, xc, yc; // to be determined later by func and the for loops
pair direction, point1, point2; // to be determined later by the for loops
real xmax = 3;
real ymax = 3;
real offset = 0.0001; // prevents division by zero
int narrowsx = 12; // number of arrows in each row
int narrowsy = 12; // number of arrows in each column

real func(real x, real y) {return (y-x*y)/(-x+x*y);}

for(int i = 0; i < narrowsx; ++i){
	for(int j = 0; j < narrowsy; ++j){
    	xc = i*xmax/narrowsx + offset;
        yc = j*ymax/narrowsy + offset;

        slope = func(xc,yc);
        direction = (1,slope)/sqrt(1 + slope^2); // unit direction vector
        point1 = (xc,yc) - arrowlength*direction/2;
        point2 = (xc,yc) + arrowlength*direction/2;

        if(-xc + xc*yc < 0){ // checks x'(t) to determine whether arrow should point left or right
        	draw(point1--point2, BeginArrow);
        }
        else{
        	draw(point1--point2, EndArrow);
        }
    }
}

xaxis(Label("$x$",position=EndPoint, align=SE), Arrow);
yaxis(Label("$y$",position=EndPoint, align=NW), Arrow);