unitsize(0.4 cm);

real a, b, t;
path cycloid;

a = 2;
b = 3;
cycloid = (0,a - b);

draw(Circle((0,a),a));
draw(Circle((8*pi,2),a));
draw((0,2)--(0,a - b));
draw((8*pi,2)--(8*pi,a - b));
draw((0,0)--(8*pi,0));

t = 8;
draw(Circle((t,a),a));
draw((t,a)--(t - b*sin(t/a), a - b*cos(t/a)));

for (t = 0; t <= 8*pi; t = t + 0.01) {
  cycloid = cycloid--(t - b*sin(t/a), a - b*cos(t/a));
}

draw(cycloid,red);

dot((0,2));
dot((8*pi,2));
dot((0,-1));
dot((8*pi,-1));

t = 8;
dot((t,a));
dot((t - b*sin(t/a), a - b*cos(t/a)));

t = 2*pi;
dot("$A$", (t - b*sin(t/a), a - b*cos(t/a)), N);

t = 4*pi - 2*acos(2/3);
dot("$B$", (t - b*sin(t/a), a - b*cos(t/a)), SE);