import graph;
size(6cm);
real f(real x, real y) {return (y-3*x*x*y);}
real g(real x) {return (2*exp(x-x^3));}
int n;
real i,j;
n = 4;
path p=(-0.1,0)--(0.1,0);
pen sf=gray+0.75bp;
for (i=-n; i<=n; i=i+0.25) {
for (j=-n; j<=n; j=j+0.25) {
draw(shift(i,j)*rotate(degrees(atan(f(i,j))))*p,sf);
}}
draw(graph(g,-1.25,4),blue+1bp);
dot((1,2),black+5bp);
label("$(1,2)$",(1,2),NE);
xaxis(Arrow); 
yaxis(Arrow);