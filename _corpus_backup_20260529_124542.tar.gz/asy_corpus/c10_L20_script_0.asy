//start
unitsize(1cm);
import markers;

//variables
real r, t; 
r = 1; // radius
t = 55; // theta in degrees
pair P, O, A;
P = r*dir(t); // point in polar coordinates
O = origin;
A=(P.x,0); //projection to x-axis

//axes
xaxis(Arrow(2mm));
yaxis(Arrow(2mm));

//drawing and labeling r and theta
dot ("$P=(r, 	heta)$", P, blue); //point in polar coordinates
draw ("$r$", O -- P, blue); //radius
markangle("$	heta$", radius=15, (r,0),O,P,blue+0.75bp,arrow=Arrow(2mm)); // theta measured counterclockwise from positive x-axis

//rectangular coordinates
draw (A--P); //altitude "$y$", 
//label("$x$", (O+A)/2, S);

//end