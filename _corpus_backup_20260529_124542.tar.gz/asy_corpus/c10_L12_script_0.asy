unitsize(2cm);

string ufunctions[] = {"$u$", "$x^4 - 2x^3 - 10x^2 + 6x + 2$", "$\phantom{0000}4x^3 - 6x^2 - 20x + 6$", "$\phantom{0000000}12x^2 - 12x - 20$", "$\phantom{0000000000000}24x-12$", "$\phantom{000000000000000000}24$", "$\phantom{0000000000000000000}0$"}; //phantom zeros enforce right-alignment of the column

string vfunctions[] = {"$v'$", "$\cos x$", "$\sin x$", "$-\cos x$", "$-\sin x$", "$\cos x$", "$\sin x$", "$-\cos x$"};

pair ucolumn = (0,0); pair vcolumn = (3,0);
pair vert = (0, -1); //vertical offset between entries
pair uhoriz = (1.25,0); //distance from centre of u column to right edge
pair vhoriz = (-0.5,0); //distance from centre of v column to left edge

for (int i = 1; i < ufunctions.length; ++i){
	label(ufunctions[i], ucolumn + i*vert);
    label(vfunctions[i], vcolumn + i*vert);

    pair A = ucolumn + i*vert + uhoriz;
    pair B = vcolumn + (i+1)*vert + vhoriz;

    if (i % 2 == 0){
    	draw(A--B, red);
        label("$-$", A--B, 2N, red);
    }
    if (i % 2 == 1){
    	draw(A--B, blue);
        label("$+$", A--B, 2N, blue);
    }

}

//final entry in the v column
label(vfunctions[vfunctions.length-1], vcolumn + (vfunctions.length-1)*vert);

//column headings
label(ufunctions[0], ucolumn + vert/2 + (0, 0.2));
label(vfunctions[0], vcolumn + vert/2 + (0, 0.2));
draw((ucolumn - uhoriz + vert/2)--(ucolumn + uhoriz + vert/2));
draw((vcolumn - vhoriz + vert/2)--(vcolumn + vhoriz + vert/2));