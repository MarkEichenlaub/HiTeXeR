unitsize(4 cm);

pair A, B, Bp, M, P, Q;

A = (0,0);
B = (1,0);
Bp = (0,0.6);
M = (B + Bp)/2;
P = extension(M, M + rotate(90)*(B - Bp), A, B);
Q = extension(M, M + rotate(90)*(B - Bp), B, B + (0,1));

fill(P--Bp--Q--cycle,gray(0.7));
draw((0,1.5)--A--P--Q--(1,1.5));
draw(P--B--Q,dashed);
draw(P--Bp--Q);

label("$A$", A, SW);
label("$B$", B, SE);
label("$B'$", Bp, W);
label("$P$", P, S);
label("$Q$", Q, E);
label("$x$", (B + P)/2, S, red);
label("$x$", (Bp + P)/2, SW, red);
label("$	heta$", Q + (-0.05,-0.2));
label("$	heta$", Q + (-0.15,-0.15));